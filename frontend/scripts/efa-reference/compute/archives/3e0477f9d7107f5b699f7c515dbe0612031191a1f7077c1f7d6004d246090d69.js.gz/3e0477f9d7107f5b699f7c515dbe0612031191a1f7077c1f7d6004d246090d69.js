// src/lib/efa/fit-cache.ts
var FitInvariantCache = class {
  constructor(budget = 128 * 1024 ** 2, limit = 2) {
    this.budget = budget;
    this.limit = limit;
    this.entries = /* @__PURE__ */ new Map();
    this.bytes = 0;
  }
  acceptsCovariance(parameters) {
    return parameters * parameters * 8 <= this.budget && this.limit > 0;
  }
  get(key) {
    const entry = this.entries.get(key);
    if (!entry) return;
    this.entries.delete(key);
    this.entries.set(key, entry);
    return entry.value;
  }
  put(key, value) {
    const { inference, ...rest } = value;
    const { covariance, ...metadata } = inference ?? {};
    const bytes = 2 * JSON.stringify({ ...rest, inference: metadata }).length + (covariance?.byteLength ?? 0);
    if (bytes > this.budget || this.limit < 1) return false;
    const previous = this.entries.get(key);
    if (previous) {
      this.bytes -= previous.bytes;
      this.entries.delete(key);
    }
    while (this.entries.size >= this.limit || this.bytes + bytes > this.budget) {
      const oldest = this.entries.keys().next().value;
      this.bytes -= this.entries.get(oldest).bytes;
      this.entries.delete(oldest);
    }
    this.entries.set(key, { value, bytes });
    this.bytes += bytes;
    return true;
  }
};

// src/lib/efa/types.ts
var EfaError = class extends Error {
  constructor(code, message, diagnostics = []) {
    super(message);
    this.code = code;
    this.diagnostics = diagnostics;
    this.name = "EfaError";
  }
};
var EFA_ENGINE = "scatter-efa/7";

// src/lib/efa/backends/types.ts
function computeSettings(spec) {
  if (spec.compute !== void 0 && (!spec.compute || typeof spec.compute !== "object" || Array.isArray(spec.compute) || Object.keys(spec.compute).some((key) => !["backend", "blockSize", "memoryMiB"].includes(key)) || !spec.compute.backend))
    throw new EfaError("backend-settings", "Compute settings accept only backend, blockSize and memoryMiB. Pairing is session-only.");
  const settings = spec.compute, backend = settings?.backend ?? "cpu";
  if (!["cpu", "webgpu", "scala"].includes(backend)) throw new EfaError("backend", "Unknown EFA compute backend.");
  if (backend !== "cpu" && spec.extraction !== "wlsmv") throw new EfaError("backend-method", "WebGPU and Scala accelerate WLSMV trace corrections. Select WLSMV or Browser CPU.");
  if (settings?.blockSize !== void 0 && ![32, 64, 128, 256].includes(settings.blockSize) || settings?.memoryMiB !== void 0 && !Number.isInteger(settings.memoryMiB))
    throw new EfaError("backend-budget", "Use integer block and memory settings.");
  const blockSize = settings?.blockSize ?? (backend === "scala" ? 256 : backend === "webgpu" ? 128 : 32);
  const memoryMiB = settings?.memoryMiB ?? (backend === "cpu" ? 1024 : 1536);
  if (![32, 64, 128, 256].includes(blockSize) || !Number.isInteger(memoryMiB) || memoryMiB < 256 || memoryMiB > 4096)
    throw new EfaError("backend-budget", "Choose a supported block size and a memory budget between 256 and 4096 MiB.");
  return { backend, blockSize, budgetBytes: memoryMiB * 1024 ** 2, ...backend === "cpu" ? {} : { space: "cases" } };
}
var COMPANION_PROTOCOL = "scatter-efa-companion/2";
var NATIVE_KERNEL_SHA = "21136cac2832c38efd222afa1da3d4828427590785dca5d270f00543c5554ed9";

// src/lib/efa/backends/companion.ts
function validateConnection(connection) {
  let url;
  try {
    url = new URL(connection.url);
  } catch {
    throw new EfaError("companion", "Enter the local companion URL and pairing token.");
  }
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || !url.port || url.username || url.password || url.pathname !== "/" || url.search || url.hash || !/^[a-f0-9]{64}$/.test(connection.token))
    throw new EfaError("companion", "The companion must use http://127.0.0.1:PORT and its 64-character pairing token.");
  return { url: url.origin, token: connection.token };
}
async function companionRequest(connection, path, method = "GET", body, timeoutMs = 3e4) {
  const verified = validateConnection(connection);
  try {
    const response = await fetch(verified.url + path, {
      method,
      body,
      redirect: "error",
      credentials: "omit",
      cache: "no-store",
      headers: { Authorization: `Bearer ${verified.token}`, ...body ? { "Content-Type": "application/octet-stream" } : {} },
      signal: AbortSignal.timeout(timeoutMs)
    });
    if (!response.ok) {
      const detail = {
        401: "The pairing token was rejected. Reconnect using the token from the running companion.",
        403: "The companion rejected this workbench origin. Restart it with the exact --origin shown in setup.",
        409: "The companion is busy or this session was stopped. Wait for process cleanup and rerun explicitly.",
        413: "The request exceeds the companion transport limits.",
        422: "The companion rejected a source or block, or its native process failed. This run was stopped.",
        503: "The Scala JVM could not start with native BLAS. Check Java and the companion's native BLAS installation."
      };
      throw new EfaError("companion-unavailable", detail[response.status] ?? "The companion request failed. Check the local process and rerun explicitly.");
    }
    return response;
  } catch (error) {
    if (error instanceof EfaError) throw error;
    throw new EfaError("companion-unavailable", "Local Scala companion request failed. Check pairing, allowed origin, browser local-network permission and the companion process. No backend substitution was made.");
  }
}
async function connectCompanion(connection) {
  const verified = validateConnection(connection);
  const identity = await (await companionRequest(verified, "/v1/health")).json();
  if (identity.protocol !== COMPANION_PROTOCOL || identity.kernelSha256 !== NATIVE_KERNEL_SHA)
    throw new EfaError("companion-version", "The Scala companion version does not match this workbench. Restart it using this checkout.");
  return verified;
}
async function createCompanionSession(connection, id = crypto.randomUUID()) {
  const value = await (await companionRequest(connection, `/v1/jobs/${id}`, "POST")).json();
  if (value.id !== id) throw new EfaError("companion-protocol", "Invalid companion session.");
  return { ...connection, id: value.id };
}
async function closeCompanionSession(session) {
  await companionRequest(session, `/v1/jobs/${session.id}`, "DELETE", void 0, 5e3);
}

// src/lib/efa/math.ts
function gaussLegendre(n) {
  const x = [], w = [];
  for (let i = 0; i < n; i++) {
    let z = Math.cos(Math.PI * (i + 0.75) / (n + 0.5)), derivative = 0;
    for (let it = 0; it < 30; it++) {
      let p = 1, prev = 0;
      for (let j = 1; j <= n; j++) {
        const next = ((2 * j - 1) * z * p - (j - 1) * prev) / j;
        prev = p;
        p = next;
      }
      derivative = n * (z * p - prev) / (z * z - 1);
      const step = p / derivative;
      z -= step;
      if (Math.abs(step) < 1e-15) break;
    }
    x.push(z);
    w.push(2 / ((1 - z * z) * derivative * derivative));
  }
  return { x, w };
}
var quadrature = gaussLegendre(24);

// src/lib/efa/correlation.ts
function assembleCorrelations(data, pairs) {
  const p = data.items.length, matrix = Array.from(
    { length: p },
    (_, i) => Array.from({ length: p }, (_2, j) => i === j ? 1 : NaN)
  );
  if (pairs.length !== p * (p - 1) / 2)
    throw new EfaError("pairs", "Correlation job is incomplete.");
  for (const pair of pairs)
    matrix[pair.i][pair.j] = matrix[pair.j][pair.i] = pair.rho;
  const sparse = pairs.filter((x) => x.sparseCells), boundary = pairs.filter((x) => x.boundary);
  const emptyMargins = pairs.filter(
    (x) => x.observedCategoriesX.length < data.items[x.i].categories.length || x.observedCategoriesY.length < data.items[x.j].categories.length
  );
  return {
    matrix,
    pairs,
    counts: data.counts.map((f) => f.reduce((a, b) => a + b, 0)),
    diagnostics: [
      ...sparse.length ? [
        {
          code: "sparse",
          message: `${sparse.length} item pairs contain cells with fewer than five responses. Inspect pair diagnostics.`,
          count: sparse.length
        }
      ] : [],
      ...boundary.length ? [
        {
          code: "boundary-correlation",
          message: `${boundary.length} estimated correlations are near \xB11.`,
          count: boundary.length
        }
      ] : [],
      ...emptyMargins.length ? [
        {
          code: "empty-pair-margins",
          message: `${emptyMargins.length} pairs have unobserved category margins. Their likelihoods use the observed levels, matching polycor; the original category order and observed level indices are retained.`,
          count: emptyMargins.length
        }
      ] : []
    ]
  };
}

// src/lib/efa/extraction.ts
var MINRES_METHOD = "MINRES compensated lower-triangle objective; analytic spectral gradient; projected BFGS; lower-objective SMC/unit-uniqueness initialization; uniqueness [.005,1]; gradient tolerance 1e-8";

// src/lib/efa/parallel.ts
function validateReplicates(replicates, seed) {
  if (!Number.isInteger(replicates) || replicates < 1 || replicates > 1e3)
    throw new EfaError(
      "replicates",
      "Use 1\u20131000 parallel-analysis permutations."
    );
  if (seed !== void 0 && (!Number.isSafeInteger(seed) || !Number.isSafeInteger(seed + (replicates - 1))))
    throw new EfaError(
      "seed",
      "Choose an integer seed whose full sequence of permutation offsets stays within JavaScript's safe integer range."
    );
}
function summarizeParallel(observed, nullEigenvalues, failures, seed, replicates, inputSha256) {
  if (nullEigenvalues.length + failures.length !== replicates)
    throw new EfaError(
      "incomplete-simulation",
      "A simulation result must account for every requested replicate."
    );
  const reference = observed.map((_, j) => {
    const sorted = nullEigenvalues.map((row) => row[j]).sort((a, b) => a - b);
    if (!sorted.length) return null;
    const index = 0.95 * (sorted.length - 1), lo = Math.floor(index);
    return sorted[lo] + (sorted[Math.ceil(index)] - sorted[lo]) * (index - lo);
  });
  let suggestion = 0;
  while (suggestion < observed.length && reference[suggestion] !== null && observed[suggestion] > reference[suggestion])
    suggestion++;
  return {
    provenance: {
      inputSha256,
      engine: EFA_ENGINE,
      correlation: "Two-step pair-margin polychoric; maxcor=.9999",
      extraction: MINRES_METHOD,
      nullModel: "Within-item observed-response permutations with fixed missingness masks",
      communalityConvention: "One-factor MINRES squared loadings replace correlation diagonals for observed and null spectra",
      generator: "mulberry32; replicate seed = batch seed + zero-based replicate index",
      percentile: "95th percentile; linear interpolation (R type 7)"
    },
    seed,
    requested: replicates,
    completed: nullEigenvalues.length,
    percentile: 0.95,
    observed,
    nullEigenvalues,
    reference,
    failures,
    suggested: failures.length ? null : suggestion
  };
}

// src/lib/efa/telemetry.ts
function computeStageName(stage) {
  return stage.startsWith("MICE") ? "MICE" : stage.startsWith("Parallel analysis") ? "Parallel analysis" : stage.startsWith("Resampling stability") ? "Resampling stability" : stage.split(" \xB7 ")[0];
}
var EVENT_LIMIT = 512;
var STAGE_LIMIT = 128;
var ComputeTrace = class {
  constructor(jobId, clock = () => performance.now()) {
    this.clock = clock;
    this.sequence = 0;
    this.origin = this.stageStart = clock();
    this.report = {
      schema: "scatter-compute/1",
      jobId,
      startedAt: (/* @__PURE__ */ new Date()).toISOString(),
      elapsedMs: 0,
      status: "running",
      publication: "not-requested",
      backend: "browser-cpu",
      precision: "float64",
      context: {},
      workersCreated: 0,
      activeWorkers: 0,
      requests: {},
      workerStages: {},
      transport: {
        sentTypedBufferBytes: 0,
        receivedTypedBufferBytes: 0,
        description: "Cumulative typed-array payload bytes copied or transferred by messages; excludes ordinary arrays/objects. Not resident or peak memory. Round-trip time includes queuing and communication; postMessage time is measured on the sender."
      },
      stages: [],
      events: [],
      droppedEvents: 0,
      droppedStages: 0
    };
    this.event("job", "started");
    this.progress({ stage: "Preparing", completed: 0, total: 1 });
  }
  event(kind, action, values = {}) {
    this.report.events.push({ sequence: ++this.sequence, elapsedMs: this.clock() - this.origin, kind, action, ...values });
    if (this.report.events.length > EVENT_LIMIT) {
      this.report.events.shift();
      this.report.droppedEvents++;
    }
  }
  spec(spec, rows, operation) {
    const known = (value, choices) => choices.includes(value) ? value : "invalid";
    Object.assign(this.report.context, {
      operation,
      items: spec.items.length,
      eligibleRows: rows,
      factors: spec.nFactors,
      extraction: known(spec.extraction ?? "minres", ["minres", "dwls", "wlsmv"]),
      rotation: known(spec.rotation, ["oblimin", "promax", "varimax"]),
      missing: known(spec.missing, ["pairwise", "complete"]),
      partition: known(spec.sample.partition, ["all", "development", "holdout"])
    });
  }
  execution(value) {
    this.report.execution = structuredClone(value);
    this.report.backend = value.backend === "cpu" ? "browser-cpu" : value.backend;
    this.report.precision = value.precision;
  }
  cancellation(value) {
    this.report.cancellation = value;
    this.event("job", `Cancellation: ${value}`);
  }
  prepared(rows, items, fingerprint) {
    Object.assign(this.report.context, { fittingRows: rows, items, inputSha256: fingerprint });
  }
  operation(operation) {
    this.report.context.operation = operation;
  }
  worker(created, worker) {
    if (created) this.report.workersCreated++;
    this.report.activeWorkers += created ? 1 : -1;
    this.event("worker", created ? "created" : "terminated", { worker });
  }
  sent(bytes) {
    this.report.transport.sentTypedBufferBytes += bytes;
  }
  received(bytes) {
    this.report.transport.receivedTypedBufferBytes += bytes;
  }
  workerTiming(stages) {
    for (const [stage, ms] of Object.entries(stages)) {
      const key = Object.keys(this.report.workerStages).length < 127 || stage in this.report.workerStages ? stage : "Other stages";
      this.report.workerStages[key] = (this.report.workerStages[key] ?? 0) + ms;
    }
  }
  request(op, roundTripMs, workerMs, postMessageMs) {
    const r = this.report.requests[op] ??= { count: 0, roundTripMs: 0, workerMs: 0, postMessageMs: 0 };
    r.count++;
    r.roundTripMs += roundTripMs;
    r.workerMs += workerMs;
    r.postMessageMs += postMessageMs;
  }
  progress(progress) {
    if (this.ended !== void 0) return;
    const stage = computeStageName(progress.stage);
    progress = { ...progress, stage };
    const now = this.clock();
    if (this.currentStage?.stage !== progress.stage) {
      this.closeStage(now);
      this.currentStage = { ...progress, durationMs: 0 };
      this.stageStart = now;
      this.event("stage", progress.stage);
    } else Object.assign(this.currentStage, progress);
  }
  closeStage(now) {
    if (!this.currentStage) return;
    this.report.stages.push({ ...this.currentStage, durationMs: now - this.stageStart });
    if (this.report.stages.length > STAGE_LIMIT) {
      this.report.stages.shift();
      this.report.droppedStages++;
    }
    this.currentStage = void 0;
  }
  numerical(result) {
    const convergence = (value) => ({
      converged: value.converged,
      iterations: value.iterations,
      objective: value.objective,
      gradient: value.gradient,
      ...value.maxIterations === void 0 ? {} : { maxIterations: value.maxIterations }
    });
    this.report.numerical = {
      extraction: convergence(result.extraction.convergence),
      rotation: convergence(result.rotation.convergence),
      boundaryItems: result.extraction.boundaryItems.length,
      conditionNumber: result.conditionNumber,
      residualRms: result.rmsr,
      inferenceEstimatedBytes: result.weighted?.robust?.plan.estimatedBytes
    };
  }
  finish(status) {
    if (this.ended !== void 0) return;
    this.ended = this.clock();
    this.closeStage(this.ended);
    this.report.status = status;
    this.event("job", status);
  }
  publication(value) {
    this.report.publication = value;
    this.event("publication", value);
  }
  snapshot() {
    const now = this.ended ?? this.clock();
    return structuredClone({
      ...this.report,
      elapsedMs: now - this.origin,
      stages: this.currentStage ? [...this.report.stages, { ...this.currentStage, durationMs: now - this.stageStart }] : this.report.stages
    });
  }
};

// src/lib/efa/weighted-inference.ts
function planWeightedInference(p, k, n, lookupCells = 25 * p * (p - 1) / 2, options = {}) {
  const m = p * (p - 1) / 2, q = p * k - k * (k - 1) / 2, blockSize = options.blockSize ?? 32, budgetBytes = options.budgetBytes ?? 1024 ** 3;
  if (!Number.isInteger(p) || p < 3 || !Number.isInteger(k) || k < 1 || q > m || !Number.isInteger(n) || n < 3 || !Number.isInteger(blockSize) || blockSize < 1 || blockSize > 256 || !Number.isFinite(budgetBytes) || budgetBytes <= 0)
    throw new EfaError(
      "weighted-budget",
      "Invalid dimensions or memory budget for weighted uncertainty."
    );
  const common = 6 * q * q * 8 + 3 * p * n + 8 * lookupCells + 16 * p * k + 16 * blockSize * m;
  const momentBytes = 1.2 * (common + 8 * (5 * m * m + 4 * m * q)), caseBytes = 1.2 * (common + 8 * n * q + 8 * q * q + 24 * m * k + 4 * (m + 1));
  const space = options.space ?? (m < n && momentBytes <= budgetBytes ? "moments" : "cases"), estimatedBytes = space === "moments" ? momentBytes : caseBytes;
  if (estimatedBytes > budgetBytes)
    throw new EfaError(
      "weighted-budget",
      `Exact WLSMV uncertainty needs an estimated ${Math.ceil(estimatedBytes / 1024 ** 2)} MiB, above the ${Math.floor(budgetBytes / 1024 ** 2)} MiB worker budget. Reduce the item/factor set or run DWLS point fitting explicitly. No method was substituted.`
    );
  return {
    space,
    parameters: q,
    pairs: m,
    rows: n,
    blockSize,
    estimatedBytes,
    budgetBytes,
    approximateMultiplyAdds: space === "moments" ? n * m * m / 2 + 2 * m * m * q + 2 * q * q * m : n * n * (m + q) / 2 + n * q * q + 2 * q * q * q
  };
}

// src/lib/efa/mice.ts
function validateMiceOptions(options, p) {
  if (!Number.isInteger(options.imputations) || options.imputations < 2 || options.imputations > 100 || !Number.isInteger(options.iterations) || options.iterations < 1 || options.iterations > 100 || !Number.isSafeInteger(options.seed) || !Number.isSafeInteger(options.seed + (options.imputations - 1) * 104729))
    throw new EfaError(
      "mice-settings",
      "Use 2\u2013100 imputations, 1\u2013100 iterations and an integer seed whose chain offsets stay within JavaScript's safe integer range."
    );
  if (!Array.isArray(options.predictors) || options.predictors.length !== p || options.predictors.some(
    (row, j) => !Array.isArray(row) || new Set(row).size !== row.length || row.some((i) => !Number.isInteger(i) || i < 0 || i >= p || i === j)
  ))
    throw new EfaError(
      "predictors",
      "Specify unique valid predictors for each item, excluding the target itself."
    );
  if (!["ordered-polynomial", "rank"].includes(
    options.predictorEncoding ?? "ordered-polynomial"
  ))
    throw new EfaError(
      "predictor-encoding",
      "Choose ordered-polynomial contrasts or ordinal ranks explicitly."
    );
}

// src/lib/efa/dwls.ts
var DWLS_METHOD = "DWLS pair correlations; reciprocal diagonal two-step sampling variances; analytic loading gradient; L-BFGS tolerance 1e-8; spectral start; unconstrained uniquenesses; no estimator substitution";

// src/lib/efa/compare.ts
function matchFactors(reference, candidate) {
  const ka = reference[0]?.length ?? 0, kb = candidate[0]?.length ?? 0, n = Math.max(ka, kb);
  const congruence = Array.from(
    { length: ka },
    (_, a) => Array.from({ length: kb }, (_2, b) => {
      let xy = 0, xx = 0, yy = 0;
      for (let i = 0; i < reference.length; i++) {
        const x = reference[i][a], y = candidate[i][b];
        xy += x * y;
        xx += x * x;
        yy += y * y;
      }
      return xx * yy > 0 ? xy / Math.sqrt(xx * yy) : 0;
    })
  );
  const u = Array(n + 1).fill(0), v = Array(n + 1).fill(0), p = Array(n + 1).fill(0), way = Array(n + 1).fill(0);
  for (let i = 1; i <= n; i++) {
    p[0] = i;
    let j0 = 0;
    const min = Array(n + 1).fill(Infinity), used = Array(n + 1).fill(false);
    do {
      used[j0] = true;
      const i0 = p[j0];
      let delta = Infinity, j1 = 0;
      for (let j = 1; j <= n; j++)
        if (!used[j]) {
          const cost = 1 - Math.abs(congruence[i0 - 1]?.[j - 1] ?? 0) - u[i0] - v[j];
          if (cost < min[j]) {
            min[j] = cost;
            way[j] = j0;
          }
          if (min[j] < delta) {
            delta = min[j];
            j1 = j;
          }
        }
      for (let j = 0; j <= n; j++)
        if (used[j]) {
          u[p[j]] += delta;
          v[j] -= delta;
        } else min[j] -= delta;
      j0 = j1;
    } while (p[j0] !== 0);
    do {
      const j1 = way[j0];
      p[j0] = p[j1];
      j0 = j1;
    } while (j0 !== 0);
  }
  const mapping = Array(ka).fill(null);
  for (let j = 1; j <= n; j++)
    if (p[j] <= ka && j <= kb) mapping[p[j] - 1] = j - 1;
  const signs = mapping.map(
    (b, a) => b === null ? 1 : congruence[a][b] < 0 ? -1 : 1
  );
  return {
    mapping,
    signs,
    congruence: mapping.map(
      (b, a) => b === null ? null : Math.abs(congruence[a][b])
    ),
    unmatchedCandidate: Array.from({ length: kb }, (_, i) => i).filter(
      (i) => !mapping.includes(i)
    )
  };
}

// src/lib/efa/stability.ts
function alignReplica(reference, result, replicate) {
  const { mapping, signs, congruence } = matchFactors(
    reference.rotation.pattern,
    result.rotation.pattern
  );
  if (mapping.some((i) => i === null))
    throw new EfaError(
      "factor-matching",
      "A resampled fit has unmatched factors."
    );
  const aligned = (matrix) => matrix.map((row) => mapping.map((j, k) => row[j] * signs[k]));
  return {
    replicate,
    pattern: aligned(result.rotation.pattern),
    structure: aligned(result.structure),
    phi: mapping.map(
      (i, a) => mapping.map((j, b) => result.rotation.phi[i][j] * signs[a] * signs[b])
    ),
    communalities: result.communalities,
    uniquenesses: result.uniquenesses,
    congruence,
    rmsr: result.rmsr,
    diagnostics: {
      boundaryItems: result.extraction.boundaryItems.slice(),
      improper: result.uniquenesses.some((v) => v < 0),
      conditionNumber: result.conditionNumber
    }
  };
}
function percentile(values, p) {
  if (!values.length) return null;
  const sorted = values.slice().sort((a, b) => a - b), q = p * (sorted.length - 1), lo = Math.floor(q);
  return sorted[lo] + (sorted[Math.ceil(q)] - sorted[lo]) * (q - lo);
}
function distribution(values, confidence = 0.95) {
  if (!values.length) return { mean: null, sd: null, lower: null, upper: null };
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return {
    mean,
    sd: values.length > 1 ? Math.sqrt(
      values.reduce((s, v) => s + (v - mean) ** 2, 0) / (values.length - 1)
    ) : null,
    lower: percentile(values, (1 - confidence) / 2),
    upper: percentile(values, (1 + confidence) / 2)
  };
}
var primary = (row) => row.reduce((best, v, i) => Math.abs(v) > Math.abs(row[best]) ? i : best, 0);
function summarizeStability(reference, replicas, failures, samples, options, inputSha256, estimator = "minres") {
  const p = reference.rotation.pattern.length, k = reference.rotation.phi.length;
  const matrix = (field, rows, cols) => Array.from(
    { length: rows },
    (_, i) => Array.from(
      { length: cols },
      (_2, j) => distribution(
        replicas.map((r) => r[field][i][j]),
        options.confidence
      )
    )
  );
  return {
    provenance: {
      inputSha256,
      engine: EFA_ENGINE,
      extraction: estimator === "minres" ? MINRES_METHOD : `${DWLS_METHOD}${estimator === "wlsmv" ? "; DWLS point refits of a WLSMV baseline; no per-replicate robust tests or delta standard errors" : ""}`,
      alignment: "Signs and permutation only, relative to the saved baseline",
      generator: "mulberry32; sample seed = batch seed + zero-based replicate index"
    },
    options: structuredClone(options),
    requested: options.replicates,
    completed: replicas.length,
    replicas,
    failures,
    samples,
    pattern: matrix("pattern", p, k),
    structure: matrix("structure", p, k),
    phi: matrix("phi", k, k),
    communalities: Array.from(
      { length: p },
      (_, i) => distribution(
        replicas.map((r) => r.communalities[i]),
        options.confidence
      )
    ),
    uniquenesses: Array.from(
      { length: p },
      (_, i) => distribution(
        replicas.map((r) => r.uniquenesses[i]),
        options.confidence
      )
    ),
    primaryAgreement: Array.from(
      { length: p },
      (_, i) => replicas.length ? replicas.filter(
        (r) => primary(r.pattern[i]) === primary(reference.rotation.pattern[i])
      ).length / replicas.length : null
    ),
    crossLoadingFrequency: Array.from(
      { length: p },
      (_, i) => replicas.length ? replicas.filter(
        (r) => r.pattern[i].filter(
          (v) => Math.abs(v) >= options.crossLoadingThreshold
        ).length > 1
      ).length / replicas.length : null
    ),
    provisional: failures.length > 0 || replicas.length !== options.replicates
  };
}
function validateStability(options) {
  if (!Number.isInteger(options.replicates) || options.replicates < 2 || options.replicates > 1e3 || !Number.isSafeInteger(options.seed) || !Number.isSafeInteger(options.seed + (options.replicates - 1)) || !(options.confidence > 0 && options.confidence < 1) || !(options.crossLoadingThreshold >= 0))
    throw new EfaError(
      "stability-settings",
      "Use 2\u20131000 replicates, an integer seed whose replicate offsets stay within JavaScript's safe integer range, a confidence level between 0 and 1, and a nonnegative loading threshold."
    );
}

// src/lib/efa/imputation-analysis.ts
function imputationWorkingSet(source, options) {
  let maximum = 0;
  for (let target = 0; target < source.items.length; target++) {
    if (source.counts[target].reduce((a, b) => a + b, 0) === source.nRows)
      continue;
    const d = options.predictors[target].reduce(
      (sum, j) => sum + (options.predictorEncoding === "rank" ? 1 : source.items[j].categories.length - 1),
      0
    ), k = source.items[target].categories.length;
    maximum = Math.max(maximum, 8 * d * (3 * source.nRows + 4 * d * k));
  }
  return maximum + 2 * (source.codes.byteLength + source.observed.byteLength) + 128 * source.items.length ** 2;
}
function betweenImputation(values) {
  if (!values.length) return { mean: null, sd: null, min: null, max: null };
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return {
    mean,
    sd: values.length > 1 ? Math.sqrt(
      values.reduce((s, v) => s + (v - mean) ** 2, 0) / (values.length - 1)
    ) : null,
    min: Math.min(...values),
    max: Math.max(...values)
  };
}
function missingPositions(source) {
  const positions = [];
  for (let i = 0; i < source.observed.length; i++)
    if (!source.observed[i]) positions.push(i);
  return positions;
}
function observedPairFloor(source) {
  let minimum = Math.min(
    5,
    ...source.counts.map((counts) => counts.reduce((a, b) => a + b, 0))
  );
  for (let i = 0; i < source.items.length && minimum > 0; i++)
    for (let j = i + 1; j < source.items.length && minimum > 0; j++) {
      let count = 0;
      for (let row = 0; row < source.nRows; row++)
        if (source.observed[i * source.nRows + row] && source.observed[j * source.nRows + row] && ++count >= minimum)
          break;
      minimum = Math.min(minimum, count);
    }
  return minimum;
}
function summarizeImputations(source, options, chains, estimator, supportFloor) {
  const fits = chains.flatMap((c) => c.fit ? [c.fit] : []).sort((a, b) => a.imputation - b.imputation), failures = chains.flatMap((c) => c.failure ? [c.failure] : []).sort((a, b) => a.imputation - b.imputation);
  const ids = [
    ...fits.map((f) => f.imputation),
    ...failures.map((f) => f.imputation)
  ];
  if (ids.length !== options.imputations || new Set(ids).size !== ids.length || ids.some((i) => i < 0 || i >= options.imputations))
    throw new EfaError(
      "incomplete-imputation",
      "Every requested imputation must have one fit or recorded failure."
    );
  const reference = fits[0]?.result, aligned = fits.map((f) => alignReplica(reference, f.result, f.imputation));
  const p = source.items.length, k = reference?.rotation.phi.length ?? 0;
  const matrix = (field, rows, cols) => Array.from(
    { length: rows },
    (_, i) => Array.from(
      { length: cols },
      (_2, j) => betweenImputation(aligned.map((r) => r[field][i][j]))
    )
  );
  return {
    observedPairFloor: supportFloor ?? observedPairFloor(source),
    options: structuredClone({
      ...options,
      predictorEncoding: options.predictorEncoding ?? "ordered-polynomial"
    }),
    requested: options.imputations,
    completed: fits.length,
    fittingRows: source.rows.slice(),
    originalRowCount: source.originalRowCount,
    missingPositions: missingPositions(source),
    fits,
    aligned,
    failures,
    trace: chains.flatMap((c) => c.trace).sort(
      (a, b) => a.imputation - b.imputation || a.iteration - b.iteration || a.item - b.item
    ),
    pattern: matrix("pattern", p, k),
    structure: matrix("structure", p, k),
    phi: matrix("phi", k, k),
    communalities: Array.from(
      { length: p },
      (_, i) => betweenImputation(aligned.map((r) => r.communalities[i]))
    ),
    uniquenesses: Array.from(
      { length: p },
      (_, i) => betweenImputation(aligned.map((r) => r.uniquenesses[i]))
    ),
    provisional: failures.length > 0,
    provenance: {
      engine: EFA_ENGINE,
      method: `Separate ordinal polr / binary logreg conditional imputations; ${(estimator ?? reference?.weighted?.estimator ?? "minres").toUpperCase()} fitted independently to each completed dataset`,
      inputSha256: source.fingerprint,
      alignment: "Signs and factor permutation only, anchored to first successful imputation",
      uncertainty: reference?.weighted?.robust ? "Separate within-imputation robust standard errors retained in each fit; aligned between-imputation dispersion is descriptive; no Rubin-pooled confidence intervals" : "Descriptive between-imputation dispersion only; no within-imputation variance or Rubin-pooled confidence intervals"
    }
  };
}

// src/lib/efa/service.ts
var WorkerClient = class {
  constructor(factory, trace, index) {
    this.trace = trace;
    this.index = index;
    this.counter = 0;
    this.terminated = false;
    this.pending = /* @__PURE__ */ new Map();
    this.worker = factory();
    trace.worker(true, index);
    this.worker.onmessage = (event) => {
      const { id, progress, execution, error, value, workerMs = 0, workerStages = {} } = event.data;
      const p = this.pending.get(id);
      if (!p) return;
      if (execution) {
        trace.execution(execution);
        return;
      }
      if (progress) {
        p.progress(progress);
        return;
      }
      this.pending.delete(id);
      const durationMs = performance.now() - p.started;
      trace.request(p.op, durationMs, workerMs, p.postMessageMs);
      trace.workerTiming(workerStages);
      trace.event("request", error ? `${p.op} failed` : `${p.op} completed`, {
        worker: index,
        request: id,
        durationMs,
        workerMs
      });
      if (p.op === "prepare" && !error) {
        trace.prepared(value.nRows, value.items.length, value.fingerprint);
        trace.received(value.codes.byteLength + value.observed.byteLength);
      }
      if ((p.op === "fit" || p.op === "fit-finish") && !error && value?.extraction) trace.numerical(value);
      if (p.op === "rotation-batch" && !error) trace.received(value.values.byteLength);
      if (p.op === "fit-cache" && !error) trace.received(value.inference.covariance.byteLength);
      if (error)
        p.reject(new EfaError(error.code, error.message, error.diagnostics));
      else p.resolve(value);
    };
    this.worker.onerror = (event) => {
      trace.event("worker", "runtime error", { worker: index });
      for (const p of this.pending.values())
        p.reject(new Error(event.message || "Worker failed."));
      this.pending.clear();
    };
  }
  request(request, progress = () => {
  }) {
    return new Promise((resolve, reject) => {
      const id = ++this.counter;
      const started = performance.now();
      if (!["initialize", "pairs", "observed-support"].includes(request.op)) this.trace.operation(request.op);
      if (request.op === "prepare") this.trace.spec(request.spec, request.rows.length, "prepare");
      if (request.op === "initialize") {
        this.trace.prepared(request.data.nRows, request.data.items.length, request.data.fingerprint);
        this.trace.sent(request.data.codes.byteLength + request.data.observed.byteLength);
      }
      if (request.op === "rotation-accept") this.trace.sent(request.batch.values.byteLength);
      if (request.op === "fit" && request.invariant?.inference) this.trace.sent(request.invariant.inference.covariance.byteLength);
      const pending = {
        resolve: (v) => resolve(v),
        reject,
        progress,
        op: request.op,
        started,
        postMessageMs: 0
      };
      this.pending.set(id, pending);
      this.trace.event("request", `${request.op} started`, {
        worker: this.index,
        request: id,
        count: request.op === "pairs" ? request.pairs.length : void 0
      });
      try {
        const before = performance.now();
        this.worker.postMessage({ ...request, id }, request.op === "rotation-accept" ? [request.batch.values.buffer] : []);
        pending.postMessageMs = performance.now() - before;
      } catch (error) {
        this.pending.delete(id);
        this.trace.event("request", `${request.op} message failed`, { worker: this.index, request: id });
        reject(error);
      }
    });
  }
  terminate() {
    if (this.terminated) return;
    this.terminated = true;
    this.worker.terminate();
    this.trace.worker(false, this.index);
    for (const p of this.pending.values())
      p.reject(new EfaError("cancelled", "Analysis cancelled."));
    this.pending.clear();
  }
};
var EfaService = class {
  constructor(workerFactory = () => new Worker(new URL("./efa.worker.ts", import.meta.url)), concurrency = Math.max(
    1,
    Math.min(
      4,
      typeof navigator === "undefined" ? 1 : navigator.hardwareConcurrency || 1
    )
  )) {
    this.workerFactory = workerFactory;
    this.concurrency = concurrency;
    this.companionCleanup = Promise.resolve();
    this.cleanups = /* @__PURE__ */ new WeakMap();
    this.jobs = /* @__PURE__ */ new Map();
    this.listeners = /* @__PURE__ */ new Set();
    this.cache = /* @__PURE__ */ new WeakMap();
    this.invariantCache = new FitInvariantCache();
    this.completedCaches = /* @__PURE__ */ new WeakMap();
    this.revisionIds = /* @__PURE__ */ new WeakMap();
    this.traces = /* @__PURE__ */ new WeakMap();
    this.subscribe = (listener) => {
      this.listeners.add(listener);
      return () => {
        this.listeners.delete(listener);
      };
    };
    this.concurrency = Math.max(
      1,
      Math.min(
        4,
        typeof navigator === "undefined" ? 4 : navigator.hardwareConcurrency || 1,
        Math.floor(concurrency) || 1
      )
    );
  }
  async connectScala(connection) {
    this.companion = await connectCompanion(connection);
    this.emit();
  }
  scalaConnected() {
    return !!this.companion;
  }
  disconnectScala() {
    this.cancelAll();
    this.companion = void 0;
    this.emit();
  }
  emit() {
    this.listeners.forEach((fn) => fn());
  }
  getJob(id) {
    return this.jobs.get(id);
  }
  listJobs() {
    return [...this.jobs.values()];
  }
  report(id) {
    return this.jobs.get(id)?.trace.snapshot();
  }
  trackPublication(job, completion) {
    job.trace.publication("pending");
    void completion.then(() => {
      job.trace.publication("accepted");
      this.emit();
    }, () => {
      job.trace.publication("discarded");
      this.emit();
    });
  }
  revision(table) {
    let id = this.revisionIds.get(table);
    if (!id) {
      id = crypto.randomUUID();
      this.revisionIds.set(table, id);
    }
    return id;
  }
  cancelAll() {
    for (const job of this.jobs.values())
      if (job.status === "running") job.cancel();
  }
  launch(task) {
    this.cancelAll();
    const workers = [], id = crypto.randomUUID();
    const trace = new ComputeTrace(id);
    this.traces.set(workers, trace);
    const job = {
      id,
      trace,
      status: "running",
      progress: { stage: "Preparing", completed: 0, total: 1 },
      promise: Promise.resolve(void 0),
      cancel: () => {
        if (job.status !== "running") return;
        job.status = "cancelled";
        trace.cancellation("requested");
        void this.cleanups.get(workers)?.();
        workers.forEach((w) => w.terminate());
        if (!this.cleanups.has(workers)) trace.cancellation("workers-terminated");
        trace.finish("cancelled");
        this.emit();
      }
    };
    this.jobs.set(id, job);
    this.emit();
    let lastProgressEmission = 0;
    const progress = (p) => {
      if (job.status === "running") {
        const changedStage = p.stage !== job.progress.stage;
        job.progress = p;
        trace.progress(p);
        const now = performance.now();
        if (changedStage || p.completed === p.total || now - lastProgressEmission >= 250) {
          lastProgressEmission = now;
          this.emit();
        }
      }
    };
    job.promise = task(workers, progress, () => job.status === "running").then((result) => {
      if (job.status !== "running")
        throw new EfaError("cancelled", "Analysis cancelled.");
      this.completedCaches.get(workers)?.();
      this.completedCaches.delete(workers);
      job.result = result;
      job.status = "completed";
      trace.finish("completed");
      job.progress = { stage: "Completed", completed: 1, total: 1 };
      return result;
    }).catch((error) => {
      if (job.status !== "cancelled") {
        job.status = "failed";
        job.error = error instanceof Error ? error.message : String(error);
        trace.finish("failed");
      }
      throw error;
    }).finally(async () => {
      await this.cleanups.get(workers)?.();
      workers.forEach((w) => w.terminate());
      this.completedCaches.delete(workers);
      this.emit();
    });
    void job.promise.catch(() => {
    });
    for (const [key, value] of this.jobs)
      if (this.jobs.size > 20 && value.status !== "running" && key !== id)
        this.jobs.delete(key);
    return job;
  }
  client(workers) {
    const client = new WorkerClient(this.workerFactory, this.traces.get(workers), workers.length + 1);
    workers.push(client);
    return client;
  }
  async batches(workers, first, data, count, request, label, progress, live, workerLimit = this.concurrency) {
    const clients = [first], results = Array(count);
    for (let i = 1; i < Math.min(workerLimit, count); i++) {
      if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
      const client = this.client(workers);
      await client.request({ op: "initialize", data });
      clients.push(client);
    }
    let next = 0, completed = 0;
    await Promise.all(
      clients.map(async (client) => {
        while (next < count && live()) {
          const index = next++;
          let reported = 0;
          results[index] = await client.request(request(index), (p) => {
            const now = performance.now();
            if (now - reported > 250 || p.completed === p.total) {
              reported = now;
              progress({
                stage: `${label} ${index + 1}: ${p.stage} (${p.completed}/${p.total})`,
                completed,
                total: count
              });
            }
          });
          progress({ stage: label, completed: ++completed, total: count });
        }
      })
    );
    if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
    return results;
  }
  impute(table, spec, rows, options, minimumPairN = 0) {
    const snapshot = structuredClone(spec), membership = rows.slice(), settings = structuredClone(options);
    if (computeSettings(snapshot).backend !== "cpu") throw new EfaError("backend-batch", "Accelerated MICE is not connected yet. Select Browser CPU explicitly for imputation.");
    validateMiceOptions(settings, snapshot.items.length);
    if (snapshot.missing !== "pairwise")
      throw new EfaError(
        "mice-population",
        "MICE keeps incomplete respondents. Choose the pairwise/eligible population before starting imputation; complete-case deletion would remove its targets."
      );
    return this.launch(async (workers, progress, live) => {
      const first = this.client(workers), data = await first.request({
        op: "prepare",
        table: {
          columns: snapshot.items.map((x) => x.column),
          data: Object.fromEntries(
            snapshot.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec: snapshot,
        rows: membership
      });
      progress({ stage: "Original observed support", completed: 0, total: 1 });
      const supportFloor = await first.request({
        op: "observed-support"
      });
      if (minimumPairN > 0 && supportFloor < minimumPairN)
        throw new EfaError(
          "privacy",
          "Original observed pairs are below the private aggregate floor. Imputation does not add observed support."
        );
      const estimatedBytes = imputationWorkingSet(data, settings), workerLimit = Math.min(
        this.concurrency,
        settings.imputations,
        snapshot.extraction === "wlsmv" ? 1 : 4,
        Math.max(1, Math.floor(1024 ** 3 / Math.max(1, estimatedBytes)))
      );
      const results = await this.batches(
        workers,
        first,
        data,
        settings.imputations,
        (index) => ({
          op: "imputation",
          spec: snapshot,
          options: settings,
          index
        }),
        "MICE imputation",
        progress,
        live,
        workerLimit
      );
      const analysis = summarizeImputations(
        data,
        settings,
        results,
        snapshot.extraction,
        supportFloor
      );
      analysis.provenance.execution = {
        workers: workerLimit,
        estimatedWorkingSetBytesPerWorker: estimatedBytes,
        note: `Concurrency reduced for expanded predictor designs using an approximate 1 GiB combined working-set budget, with at least one worker. This is a scheduling estimate, not measured peak memory or a cap on a single model.${snapshot.extraction === "wlsmv" ? " WLSMV chains run sequentially; each robust fit separately enforces its inference allocation budget." : ""}`
      };
      return analysis;
    });
  }
  stability(table, run, options) {
    const spec = structuredClone(run.spec), membership = run.result.fittingRows.slice(), reference = structuredClone({ rotation: run.result.rotation }), settings = structuredClone(options), fingerprint = run.result.provenance.inputSha256;
    if (computeSettings(spec).backend !== "cpu") throw new EfaError("backend-batch", "Accelerated resampling is not connected yet. Refit with Browser CPU before resampling.");
    validateStability(settings);
    return this.launch(async (workers, progress, live) => {
      const first = this.client(workers), data = await first.request({
        op: "prepare",
        table: {
          columns: spec.items.map((x) => x.column),
          data: Object.fromEntries(
            spec.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec,
        rows: membership
      });
      if (!fingerprint || fingerprint !== data.fingerprint)
        throw new EfaError(
          "changed-data",
          "The fitted responses changed. Refit before evaluating resampling stability."
        );
      const results = await this.batches(
        workers,
        first,
        data,
        settings.replicates,
        (index) => ({
          op: "stability",
          spec,
          reference,
          options: settings,
          index
        }),
        "Stability replicate",
        progress,
        live
      );
      return summarizeStability(
        reference,
        results.flatMap((r) => r.replica ? [r.replica] : []),
        results.flatMap((r) => r.failure ? [r.failure] : []),
        results.map((r) => r.indices),
        settings,
        data.fingerprint,
        spec.extraction
      );
    });
  }
  preview(table, spec, rows) {
    const snapshot = structuredClone(spec), membership = rows.slice();
    return this.launch(async (workers) => {
      const worker = this.client(workers);
      const data = await worker.request({
        op: "prepare",
        table: {
          columns: snapshot.items.map((x) => x.column),
          data: Object.fromEntries(
            snapshot.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec: snapshot,
        rows: membership
      });
      return {
        nRows: data.nRows,
        counts: data.counts,
        ...snapshot.extraction === "wlsmv" ? {
          inferencePlan: planWeightedInference(
            data.items.length,
            snapshot.nFactors,
            data.nRows,
            data.items.reduce(
              (sum, item, i) => sum + data.items.slice(i + 1).reduce(
                (s, next) => s + item.categories.length * next.categories.length,
                0
              ),
              0
            ),
            computeSettings(snapshot)
          )
        } : {}
      };
    });
  }
  fit(table, spec, rows, reuse, minimumPairN = 0) {
    const settings = computeSettings(spec);
    const connection = this.companion;
    if (settings.backend === "scala" && !connection) throw new EfaError("companion-unavailable", "Connect the local Scala companion before fitting.");
    const snapshot = structuredClone(spec), membership = rows.slice();
    const key = JSON.stringify({
      items: snapshot.items,
      missing: snapshot.missing,
      rows: membership
    });
    const selected = {
      columns: snapshot.items.map((x) => x.column),
      data: Object.fromEntries(
        snapshot.items.map((x) => [x.column, table.data[x.column]])
      ),
      nRows: table.nRows
    };
    return this.launch(async (workers, progress, live) => {
      const first = this.client(workers), entries = this.cache.get(table) ?? [], cached = entries.find((e) => e.key === key);
      const trace = this.traces.get(workers);
      trace.event("cache", cached ? "correlations hit: identical preprocessing and rows" : "correlations miss");
      const data = cached ? cached.data : await first.request({
        op: "prepare",
        table: selected,
        spec: snapshot,
        rows: membership
      });
      if (cached) await first.request({ op: "initialize", data });
      trace.spec(snapshot, membership.length, "fit");
      let correlation = cached?.correlation;
      if (!correlation) {
        const subset = entries.find(
          (entry) => JSON.stringify(entry.data.rows) === JSON.stringify(data.rows) && data.items.every(
            (item) => entry.data.items.some(
              (previous) => JSON.stringify(previous) === JSON.stringify(item)
            )
          )
        );
        if (subset) {
          trace.event("cache", "retained pairs reused: identical fitting rows and item transformations");
          const oldIndices = data.items.map(
            (item) => subset.data.items.findIndex(
              (previous) => JSON.stringify(previous) === JSON.stringify(item)
            )
          ), newIndices = new Map(oldIndices.map((v, i) => [v, i]));
          const pairs = [];
          for (const pair of subset.correlation.pairs) {
            const a = newIndices.get(pair.i), b = newIndices.get(pair.j);
            if (a === void 0 || b === void 0) continue;
            pairs.push(
              a < b ? { ...pair, i: a, j: b } : {
                ...pair,
                i: b,
                j: a,
                thresholdsX: pair.thresholdsY,
                thresholdsY: pair.thresholdsX,
                observedCategoriesX: pair.observedCategoriesY,
                observedCategoriesY: pair.observedCategoriesX
              }
            );
          }
          correlation = assembleCorrelations(
            data,
            pairs.sort((a, b) => a.i - b.i || a.j - b.j)
          );
          progress({
            stage: "Reused unchanged item pairs",
            completed: pairs.length,
            total: pairs.length
          });
        }
      }
      if (!correlation) {
        const pairs = [];
        for (let i = 0; i < data.items.length - 1; i++)
          for (let j = i + 1; j < data.items.length; j++) pairs.push([i, j]);
        const clients2 = [first];
        for (let n = 1; n < Math.min(this.concurrency, Math.ceil(pairs.length / 64)); n++) {
          const worker = this.client(workers);
          await worker.request({ op: "initialize", data });
          clients2.push(worker);
        }
        let next2 = 0, done = 0;
        const estimates = [];
        progress({ stage: "Correlations", completed: 0, total: pairs.length });
        await Promise.all(
          clients2.map(async (client) => {
            while (next2 < pairs.length && live()) {
              const batch = pairs.slice(next2, next2 + 64);
              next2 += batch.length;
              const result2 = await client.request({
                op: "pairs",
                pairs: batch
              });
              estimates.push(...result2);
              done += result2.length;
              progress({
                stage: "Correlations",
                completed: done,
                total: pairs.length
              });
            }
          })
        );
        if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
        estimates.sort((a, b) => a.i - b.i || a.j - b.j);
        correlation = assembleCorrelations(data, estimates);
        this.cache.set(
          table,
          [
            { key, data, correlation },
            ...entries.filter((e) => e.key !== key)
          ].slice(0, 2)
        );
      }
      if (!cached)
        this.cache.set(
          table,
          [
            { key, data, correlation },
            ...entries.filter((e) => e.key !== key)
          ].slice(0, 2)
        );
      let extraction;
      if (data.rows.length < minimumPairN || correlation.pairs.some((pair) => pair.n < minimumPairN))
        throw new EfaError(
          "privacy",
          "This fit includes item pairs below the private aggregate floor. Widen the sample or revise the selected items."
        );
      if (reuse && data.fingerprint && reuse.result.provenance.inputSha256 === data.fingerprint && reuse.spec.nFactors === snapshot.nFactors && (reuse.spec.extraction ?? "minres") === (snapshot.extraction ?? "minres") && JSON.stringify({
        items: reuse.spec.items,
        missing: reuse.spec.missing,
        rows: reuse.eligibleRows
      }) === key)
        extraction = reuse.result.extraction;
      if (reuse && !extraction)
        throw new EfaError(
          "rotation",
          "The fitted inputs changed. Create a refit before comparing rotations."
        );
      if (extraction) trace.event("cache", "unrotated extraction reused");
      if (snapshot.extraction && snapshot.extraction !== "minres")
        workers.filter((worker) => worker !== first).forEach((worker) => worker.terminate());
      if (snapshot.extraction !== "wlsmv") return first.request(
        { op: "fit", correlation, spec: snapshot, extraction },
        progress
      );
      const invariantKey = JSON.stringify({
        revision: this.revision(table),
        key,
        fingerprint: data.fingerprint,
        factors: snapshot.nFactors,
        estimator: snapshot.extraction,
        settings,
        engine: EFA_ENGINE
      });
      let invariant = this.invariantCache.get(invariantKey);
      if (invariant && extraction && JSON.stringify(invariant.extraction) !== JSON.stringify(extraction)) invariant = void 0;
      trace.event("cache", invariant ? "WLSMV inference hit: reusing extraction, ordinal uncertainty, canonical covariance and robust test; recomputing rotation and its standard errors" : "WLSMV inference miss");
      if (invariant) progress({ stage: "Reused rotation-independent WLSMV inference", completed: 1, total: 1 });
      let companion;
      if (!invariant && settings.backend === "scala" && connection) {
        progress({ stage: "Starting local Scala companion", completed: 0, total: 1 });
        await this.companionCleanup;
        if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
        companion = { ...connection, id: crypto.randomUUID() };
        const session = companion;
        let closing;
        const heartbeat = setInterval(() => {
          void companionRequest(session, `/v1/jobs/${session.id}/heartbeat`, "POST").catch(() => {
          });
        }, 15e3);
        this.cleanups.set(workers, () => closing ??= this.companionCleanup = (async () => {
          clearInterval(heartbeat);
          try {
            await closeCompanionSession(session);
            trace.cancellation("native-exited");
          } catch {
            trace.cancellation("native-unconfirmed");
          }
          this.emit();
        })());
        await createCompanionSession(connection, session.id);
        if (!live()) {
          await this.cleanups.get(workers)();
          throw new EfaError("cancelled", "Analysis cancelled.");
        }
      }
      const { rotationContext: context } = await first.request(
        { op: "fit", correlation, spec: snapshot, extraction, invariant, parallelDerivatives: true, companion },
        progress
      );
      if (companion) await this.cleanups.get(workers)();
      if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
      const q = context.identified.free.length, clients = [first];
      for (let slot = 1; slot < Math.min(this.concurrency, Math.ceil(q / 8)); slot++) {
        if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
        const client = this.client(workers);
        await client.request({ op: "rotation-initialize", context });
        clients.push(client);
      }
      trace.event("worker", `Rotation derivatives: ${clients.length} workers, batches of 8, four perturbations per parameter`);
      let next = 0;
      progress({ stage: "Rotated standard errors", completed: 0, total: q });
      await Promise.all(clients.map(async (client) => {
        while (next < q && live()) {
          const start = next, count = Math.min(8, q - start);
          next += count;
          const batch = await client.request({ op: "rotation-batch", start, count });
          if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
          if (batch.start !== start || batch.count !== count) throw new EfaError("weighted-rotation-batch", "Rotation worker returned the wrong range.");
          const completed = await first.request({ op: "rotation-accept", batch });
          progress({ stage: "Rotated standard errors", completed, total: q });
        }
      }));
      if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
      clients.filter((client) => client !== first).forEach((client) => client.terminate());
      const result = await first.request({ op: "fit-finish" }, progress);
      if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
      if (!invariant && !this.invariantCache.acceptsCovariance(q)) trace.event("cache", "WLSMV covariance exceeds cache budget; skipped transfer");
      if (!invariant && this.invariantCache.acceptsCovariance(q)) {
        const saved = await first.request({ op: "fit-cache" });
        if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
        saved.sourceJobId = trace.snapshot().jobId;
        this.completedCaches.set(workers, () => {
          const stored = this.invariantCache.put(invariantKey, saved);
          trace.event("cache", stored ? "Completed WLSMV invariant state cached (128 MiB / two-entry limit)" : "WLSMV invariant state exceeds cache budget; not retained");
        });
      }
      return result;
    });
  }
  scores(table, run) {
    const spec = structuredClone(run.spec), rows = run.result.fittingRows.slice(), result = run.result;
    return this.launch(async (workers) => {
      const worker = this.client(workers);
      await worker.request({
        op: "prepare",
        table: {
          columns: spec.items.map((x) => x.column),
          data: Object.fromEntries(
            spec.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec,
        rows
      });
      return worker.request({ op: "score", result });
    });
  }
  parallel(table, spec, rows, replicates = 100, minimumPairN = 0) {
    validateReplicates(replicates, spec.seed);
    const snapshot = structuredClone(spec), membership = rows.slice();
    return this.launch(async (workers, progress, live) => {
      const worker = this.client(workers);
      const data = await worker.request({
        op: "prepare",
        table: {
          columns: snapshot.items.map((x) => x.column),
          data: Object.fromEntries(
            snapshot.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec: snapshot,
        rows: membership
      });
      const observed = await worker.request(
        { op: "parallel-observed", minimumPairN },
        progress
      );
      const clients = [worker];
      for (let i = 1; i < Math.min(this.concurrency, replicates); i++) {
        const next2 = this.client(workers);
        await next2.request({ op: "initialize", data });
        clients.push(next2);
      }
      let next = 0, completed = 0;
      const results = Array(replicates);
      const failures = [];
      progress({ stage: "Parallel analysis", completed: 0, total: replicates });
      await Promise.all(
        clients.map(async (client) => {
          while (next < replicates && live()) {
            const index = next++;
            let reported = 0;
            try {
              results[index] = await client.request(
                { op: "parallel-replicate", seed: snapshot.seed + index },
                (p) => {
                  const now = performance.now();
                  if (now - reported > 250 || p.completed === p.total) {
                    reported = now;
                    progress({
                      stage: `Parallel analysis \xB7 replicate ${index + 1}: ${p.stage} (${p.completed}/${p.total}) \xB7 ${failures.length} failed`,
                      completed,
                      total: replicates
                    });
                  }
                }
              );
            } catch (error) {
              if (!live()) throw error;
              failures.push({
                replicate: index,
                error: error instanceof Error ? error.message : String(error)
              });
            }
            progress({
              stage: `Parallel analysis \xB7 ${failures.length} failed`,
              completed: ++completed,
              total: replicates
            });
          }
        })
      );
      if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
      return summarizeParallel(
        observed,
        results.filter((x) => !!x),
        failures.sort((a, b) => a.replicate - b.replicate),
        snapshot.seed,
        replicates,
        data.fingerprint
      );
    });
  }
};

// src/lib/efa/prepare.ts
function validateSpec(spec) {
  if (!spec || !Array.isArray(spec.items) || typeof spec.label !== "string" || !spec.label.trim() || !spec.sample || !["all", "development", "holdout"].includes(spec.sample.partition))
    throw new EfaError(
      "spec",
      "Supply a run label, items and an explicit sample partition."
    );
  computeSettings(spec);
  const p = spec.items.length, k = spec.nFactors;
  if (p < 3 || p > 500)
    throw new EfaError("items", "Select between 3 and 500 ordered items.");
  if (!Number.isInteger(k) || k < 1 || k >= p || (p - k) ** 2 - p - k < 0)
    throw new EfaError(
      "identification",
      `${k} factors are underidentified for ${p} items. Reduce the factor count or add items.`
    );
  if (!["pairwise", "complete"].includes(spec.missing) || !["minres", "dwls", "wlsmv"].includes(spec.extraction ?? "minres") || !["oblimin", "varimax", "promax"].includes(spec.rotation))
    throw new EfaError("method", "Unsupported EFA method.");
  if (!Number.isSafeInteger(spec.seed))
    throw new EfaError("seed", "Use an integer seed.");
  if (new Set(spec.items.map((i) => i.column)).size !== p)
    throw new EfaError("items", "Selected items must be unique.");
  for (const item of spec.items) {
    if (item.categories.length < 2 || item.categories.length > 65535 || new Set(item.categories).size !== item.categories.length || item.categories.some(
      (v) => typeof v !== "string" && typeof v !== "number" || v === "" || typeof v === "number" && !Number.isFinite(v)
    ))
      throw new EfaError(
        "category-order",
        `Specify a unique, explicit category order for ${item.column}.`
      );
  }
}

// src/lib/efa/persistence.ts
var record = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
function validateEfaState(value, nRows) {
  if (value == null) return;
  const fail = () => {
    throw new Error("Workspace file is damaged: invalid EFA state.");
  };
  if (!record(value) || !Array.isArray(value.runs) || !Array.isArray(value.splits))
    return fail();
  const rows = (v) => Array.isArray(v) && v.every((i) => Number.isInteger(i) && i >= 0 && i < nRows) && new Set(v).size === v.length;
  const matrix = (v, p, k) => Array.isArray(v) && v.length === p && v.every(
    (row) => Array.isArray(row) && row.length === k && row.every((x) => typeof x === "number" && Number.isFinite(x))
  );
  const numeric = (v, p) => Array.isArray(v) && v.length === p && v.every((x) => typeof x === "number" && Number.isFinite(x));
  const reviewRevision = (v) => v === void 0 || typeof v === "number" && Number.isSafeInteger(v) && v >= 0;
  const ids = /* @__PURE__ */ new Set();
  for (const s of value.splits) {
    if (!record(s) || typeof s.id !== "string" || ids.has(s.id) || !rows(s.development) || !rows(s.holdout) || !rows(s.eligible))
      return fail();
    const d = new Set(s.development);
    if (s.holdout.some((r) => d.has(r))) return fail();
    ids.add(s.id);
  }
  ids.clear();
  if (value.parallelRuns !== void 0) {
    if (!Array.isArray(value.parallelRuns)) return fail();
    for (const simulation of value.parallelRuns) {
      if (!record(simulation) || typeof simulation.id !== "string" || !record(simulation.spec) || !record(simulation.result) || !rows(simulation.eligibleRows))
        return fail();
      const s = simulation;
      try {
        validateSpec(s.spec);
      } catch {
        return fail();
      }
      const p = s.spec.items.length, r = s.result;
      if (!numeric(r.observed, p) || !Array.isArray(r.reference) || r.reference.length !== p || r.reference.some((v) => v !== null && !Number.isFinite(v)) || !Array.isArray(r.nullEigenvalues) || !r.nullEigenvalues.every((v) => numeric(v, p)) || !Array.isArray(r.failures) || r.failures.some((f) => !f || typeof f.error !== "string") || !Number.isInteger(r.completed) || r.completed !== r.nullEigenvalues.length)
        return fail();
    }
  }
  for (const v of value.runs) {
    if (!record(v) || typeof v.id !== "string" || ids.has(v.id) || !record(v.spec) || !record(v.result) || !record(v.reviews) || !reviewRevision(v.reviewRevision) || !reviewRevision(v.parentReviewRevision) || !rows(v.eligibleRows) || !Array.isArray(v.scoreColumns) || v.scoreColumns.some((x) => typeof x !== "string"))
      return fail();
    const run = v;
    if (typeof run.spec.label !== "string" || !Number.isInteger(run.revision) || run.revision < 1 || typeof run.createdAt !== "string" || typeof run.datasetRevision !== "string")
      return fail();
    try {
      validateSpec(run.spec);
    } catch {
      return fail();
    }
    if (!record(run.spec.sample) || !["all", "development", "holdout"].includes(run.spec.sample.partition))
      return fail();
    const p = run.spec.items.length, k = run.spec.nFactors, r = run.result;
    const execution = r.provenance?.execution;
    const backend = run.spec.compute?.backend ?? "cpu";
    if (backend !== "cpu" && !execution) return fail();
    if (execution) {
      if (!record(execution) || Object.keys(execution).some((key) => !["backend", "state", "precision", "kernelVersion", "kernelSha256", "adapter", "runtime", "blockSize", "budgetBytes", "selfCheck", "timings", "reusedFromJobId"].includes(key)) || execution.reusedFromJobId !== void 0 && (typeof execution.reusedFromJobId !== "string" || !/^[0-9a-f-]{36}$/.test(execution.reusedFromJobId)) || execution.backend !== backend || execution.state !== "completed" || typeof execution.precision !== "string" || ![32, 64, 128, 256].includes(execution.blockSize) || !Number.isFinite(execution.budgetBytes) || execution.budgetBytes < 256 * 1024 ** 2 || execution.budgetBytes > 4096 * 1024 ** 2) return fail();
      if (backend !== "cpu") {
        const check = execution.selfCheck;
        if (execution.kernelVersion !== "ordinal-trace/1" || typeof execution.kernelSha256 !== "string" || !/^[a-f0-9]{64}$/.test(execution.kernelSha256) || !record(check) || Object.keys(check).some((key) => !["version", "passed", "checks", "tolerance", "maxScaledError", "elapsedMs"].includes(key)) || check.version !== "ordinal-trace/1" || check.passed !== true || !Number.isSafeInteger(check.checks) || check.checks < 1 || check.tolerance !== 1e-10 || !Number.isFinite(check.maxScaledError) || check.maxScaledError < 0 || check.maxScaledError > check.tolerance || !Number.isFinite(check.elapsedMs) || check.elapsedMs < 0) return fail();
      }
    }
    if (!rows(r.fittingRows) || r.originalRowCount !== nRows || !r.rotation || !r.correlation || !r.extraction || !r.provenance || !Array.isArray(r.diagnostics) || !Array.isArray(r.categoryCounts) || !Array.isArray(r.correlation.pairs) || r.correlation.pairs.length !== p * (p - 1) / 2)
      return fail();
    if (!matrix(r.rotation.pattern, p, k) || !matrix(r.rotation.phi, k, k) || !matrix(r.structure, p, k) || !matrix(r.weights, p, k) || !matrix(r.extraction.loadings, p, k) || !matrix(r.correlation.matrix, p, p) || !matrix(r.residuals, p, p) || !matrix(r.reproduced, p, p) || !numeric(r.means, p) || !numeric(r.sds, p) || !numeric(r.communalities, p) || !numeric(r.uniquenesses, p) || !numeric(r.correlation.counts, p))
      return fail();
    if (r.correlation.pairs.some(
      (pair) => !pair || !Number.isInteger(pair.i) || !Number.isInteger(pair.j) || pair.i < 0 || pair.j >= p || pair.i >= pair.j || !Number.isFinite(pair.rho) || !Number.isInteger(pair.n) || pair.n < 0 || !Array.isArray(pair.thresholdsX) || !Array.isArray(pair.thresholdsY)
    ))
      return fail();
    const estimator = run.spec.extraction ?? "minres";
    if ((r.extraction.estimator ?? "minres") !== (estimator === "minres" ? "minres" : "dwls"))
      return fail();
    if (estimator === "minres" && r.weighted !== void 0) return fail();
    if (estimator !== "minres") {
      const w = r.weighted, m = p * (p - 1) / 2, q = p * k - k * (k - 1) / 2, df = m - q, n = r.fittingRows.length;
      if (!record(w) || w.estimator !== estimator || !numeric(w.samplingVariances, m) || !numeric(w.fittingWeights, m) || w.samplingVariances.some((v2) => v2 <= 0) || w.fittingWeights.some(
        (v2, i) => v2 <= 0 || Math.abs(v2 * w.samplingVariances[i] - 1) > 1e-8
      ) || typeof w.uncertaintyMethod !== "string" || !Number.isFinite(w.rawStatistic) || w.rawStatistic < 0 || w.df !== df)
        return fail();
      if (estimator === "dwls" && w.robust !== void 0) return fail();
      if (estimator === "wlsmv") {
        const robust = w.robust;
        if (!record(robust) || !record(robust.test) || !record(robust.plan) || !record(robust.standardErrors))
          return fail();
        const t = robust.test, se = robust.standardErrors, plan = robust.plan;
        if (t.df !== df || t.denominator !== n - 1 || t.rawStatistic !== w.rawStatistic || ![t.trace, t.traceSquared].every(
          (v2) => Number.isFinite(v2) && v2 >= -1e-8
        ) || !matrix(se.pattern, p, k) || !matrix(se.structure, p, k) || !matrix(se.phi, k, k) || !numeric(se.communalities, p) || !numeric(se.uniquenesses, p) || [
          ...se.pattern.flat(),
          ...se.structure.flat(),
          ...se.phi.flat(),
          ...se.communalities,
          ...se.uniquenesses
        ].some((v2) => v2 < 0) || !Number.isFinite(se.derivativeMaxRelativeChange) || se.derivativeMaxRelativeChange < 0 || se.derivativeMaxRelativeChange > 5e-3 || typeof se.method !== "string")
          return fail();
        if (df === 0 ? [t.scalingFactor, t.shift, t.statistic, t.pValue].some(
          (v2) => v2 !== null
        ) : ![t.scalingFactor, t.shift, t.statistic, t.pValue].every(
          (v2) => typeof v2 === "number" && Number.isFinite(v2)
        ) || t.scalingFactor <= 0 || t.pValue < 0 || t.pValue > 1)
          return fail();
        if (!["moments", "cases"].includes(plan.space) || plan.parameters !== q || plan.pairs !== m || plan.rows !== n || !Number.isInteger(plan.blockSize) || plan.blockSize < 1 || plan.blockSize > 256 || !Number.isFinite(plan.estimatedBytes) || plan.estimatedBytes <= 0 || plan.estimatedBytes > plan.budgetBytes || !Number.isFinite(plan.budgetBytes) || plan.budgetBytes > 4 * 1024 ** 3 || !Number.isFinite(plan.approximateMultiplyAdds) || plan.approximateMultiplyAdds <= 0)
          return fail();
      }
    }
    if (!Number.isFinite(r.rmsr) || r.diagnostics.some(
      (d) => !d || typeof d.code !== "string" || typeof d.message !== "string"
    ))
      return fail();
    if (Object.values(run.reviews).some(
      (review) => !review || !["retain", "investigate", "exclude"].includes(review.status) || typeof review.note !== "string"
    ))
      return fail();
    ids.add(run.id);
  }
  const finite = (x) => typeof x === "number" && Number.isFinite(x);
  const nullable = (x) => x === null || finite(x);
  const replicaDiagnostics = (x, p) => x === void 0 || record(x) && typeof x.improper === "boolean" && finite(x.conditionNumber) && Array.isArray(x.boundaryItems) && x.boundaryItems.every((i) => Number.isInteger(i) && i >= 0 && i < p);
  const distribution2 = (x, keys) => record(x) && keys.every((key) => nullable(x[key]));
  const distributionMatrix = (x, p, k, keys) => Array.isArray(x) && x.length === p && x.every(
    (row) => Array.isArray(row) && row.length === k && row.every((v) => distribution2(v, keys))
  );
  const reviewMap = (x) => record(x) && Object.values(x).every(
    (v) => record(v) && ["retain", "investigate", "exclude"].includes(String(v.status)) && typeof v.note === "string"
  );
  if (value.imputationRuns !== void 0) {
    if (!Array.isArray(value.imputationRuns)) return fail();
    for (const raw of value.imputationRuns) {
      if (!record(raw) || typeof raw.id !== "string" || ids.has(raw.id) || !record(raw.result) || !record(raw.spec) || !rows(raw.eligibleRows) || !reviewMap(raw.reviews) || !reviewRevision(raw.reviewRevision) || !reviewRevision(raw.parentReviewRevision))
        return fail();
      const run = raw, r = run.result, p = run.spec.items?.length;
      try {
        validateSpec(run.spec);
        if ((run.spec.compute?.backend ?? "cpu") !== "cpu") return fail();
        validateMiceOptions(r.options, p);
      } catch {
        return fail();
      }
      if (r.observedPairFloor !== void 0 && (!Number.isInteger(r.observedPairFloor) || r.observedPairFloor < 0 || r.observedPairFloor > 5) || run.spec.missing !== "pairwise" || !Number.isInteger(run.revision) || run.revision < 1 || typeof run.createdAt !== "string" || typeof run.datasetRevision !== "string" || !rows(r.fittingRows) || r.originalRowCount !== nRows || !Array.isArray(r.fits) || !Array.isArray(r.failures) || !Array.isArray(r.aligned) || !Array.isArray(r.trace) || r.requested !== r.options.imputations || r.completed !== r.fits.length || r.completed + r.failures.length !== r.requested || r.aligned.length !== r.completed || r.provisional !== r.failures.length > 0 || !record(r.provenance))
        return fail();
      const n = r.fittingRows.length, k = r.completed ? run.spec.nFactors : 0, keys = ["mean", "sd", "min", "max"], eligible = new Set(run.eligibleRows);
      if (!Array.isArray(r.missingPositions) || new Set(r.missingPositions).size !== r.missingPositions.length || r.missingPositions.some(
        (i) => !Number.isInteger(i) || i < 0 || i >= n * p
      ) || r.fittingRows.some((i) => !eligible.has(i)))
        return fail();
      const chainIds = [
        ...r.fits.map((f) => f?.imputation),
        ...r.failures.map((f) => f?.imputation)
      ];
      if (new Set(chainIds).size !== r.requested || chainIds.some(
        (i) => !Number.isInteger(i) || i < 0 || i >= r.requested
      ) || r.failures.some(
        (f) => !f || !["fit", "imputation"].includes(f.stage) || typeof f.error !== "string"
      ))
        return fail();
      for (const fit of r.fits) {
        if (!fit || !record(fit.result) || !Array.isArray(fit.replacements) || fit.replacements.length !== r.missingPositions.length || fit.replacements.some(
          (v, j) => !Number.isInteger(v) || v < 0 || v >= run.spec.items[Math.floor(r.missingPositions[j] / n)].categories.length
        ))
          return fail();
        validateEfaState(
          {
            runs: [
              { ...run, kind: "fit", scoreColumns: [], result: fit.result }
            ],
            splits: []
          },
          nRows
        );
        if (JSON.stringify(fit.result.fittingRows) !== JSON.stringify(r.fittingRows))
          return fail();
      }
      if (!distributionMatrix(r.pattern, p, k, keys) || !distributionMatrix(r.structure, p, k, keys) || !distributionMatrix(r.phi, k, k, keys) || !Array.isArray(r.communalities) || r.communalities.length !== p || !r.communalities.every((v) => distribution2(v, keys)) || !Array.isArray(r.uniquenesses) || r.uniquenesses.length !== p || !r.uniquenesses.every((v) => distribution2(v, keys)))
        return fail();
      if (r.aligned.some(
        (a) => !a || !matrix(a.pattern, p, k) || !matrix(a.structure, p, k) || !matrix(a.phi, k, k) || !numeric(a.communalities, p) || !numeric(a.uniquenesses, p) || !finite(a.rmsr) || !replicaDiagnostics(a.diagnostics, p)
      ) || r.trace.some(
        (t) => !t || !Number.isInteger(t.imputation) || t.imputation < 0 || t.imputation >= r.requested || !Number.isInteger(t.item) || t.item < 0 || t.item >= p || !Number.isInteger(t.iteration) || t.iteration < 1 || t.iteration > r.options.iterations || !finite(t.mean) || !finite(t.sd) || !finite(t.gradient) || !numeric(t.counts, run.spec.items[t.item].categories.length)
      ))
        return fail();
      ids.add(run.id);
    }
  }
  if (value.stabilityRuns !== void 0) {
    if (!Array.isArray(value.stabilityRuns)) return fail();
    for (const raw of value.stabilityRuns) {
      if (!record(raw) || typeof raw.id !== "string" || ids.has(raw.id) || !record(raw.result))
        return fail();
      const run = raw, r = run.result, parent = value.runs.find(
        (v) => v.id === run.runId
      );
      if (!parent || typeof run.createdAt !== "string" || typeof run.datasetRevision !== "string")
        return fail();
      try {
        validateStability(r.options);
      } catch {
        return fail();
      }
      const p = parent.spec.items.length, k = parent.spec.nFactors, n = parent.result.fittingRows.length, keys = ["mean", "sd", "lower", "upper"];
      if (r.requested !== r.options.replicates || !Array.isArray(r.replicas) || !Array.isArray(r.failures) || !Array.isArray(r.samples) || r.completed !== r.replicas.length || r.completed + r.failures.length !== r.requested || r.samples.length !== r.requested || r.provisional !== r.failures.length > 0 || r.samples.some(
        (sample) => !Array.isArray(sample) || sample.some((i) => !Number.isInteger(i) || i < 0 || i >= n)
      ))
        return fail();
      const replicaIds = [
        ...r.replicas.map((a) => a?.replicate),
        ...r.failures.map((f) => f?.replicate)
      ];
      if (new Set(replicaIds).size !== r.requested || replicaIds.some(
        (i) => !Number.isInteger(i) || i < 0 || i >= r.requested
      ) || r.failures.some((f) => !f || typeof f.error !== "string"))
        return fail();
      if (r.options.groups && (!Array.isArray(r.options.groups) || r.options.groups.length !== n || r.options.groups.some((g) => typeof g !== "string" || !g)))
        return fail();
      if (!distributionMatrix(r.pattern, p, k, keys) || !distributionMatrix(r.structure, p, k, keys) || !distributionMatrix(r.phi, k, k, keys) || !Array.isArray(r.communalities) || r.communalities.length !== p || !r.communalities.every((v) => distribution2(v, keys)) || !Array.isArray(r.uniquenesses) || r.uniquenesses.length !== p || !r.uniquenesses.every((v) => distribution2(v, keys)))
        return fail();
      if (r.replicas.some(
        (a) => !a || !matrix(a.pattern, p, k) || !matrix(a.structure, p, k) || !matrix(a.phi, k, k) || !numeric(a.communalities, p) || !numeric(a.uniquenesses, p) || !finite(a.rmsr) || !replicaDiagnostics(a.diagnostics, p)
      ))
        return fail();
      for (const rates of [r.primaryAgreement, r.crossLoadingFrequency])
        if (!Array.isArray(rates) || rates.length !== p || rates.some((v) => v !== null && (!finite(v) || v < 0 || v > 1)))
          return fail();
      ids.add(run.id);
    }
  }
}

// <stdin>
window.run = async (backend, blockSize) => {
  const results = [], service = new EfaService(() => new Worker("./efa.worker.js", { type: "module" }), 4);
  for (const name of ["normal", "pairwise", "complete", "skew", "heavy-tail"]) {
    const input = await (await fetch("./reference/" + name + ".input.json")).json();
    const spec = { items: input.columns.map((column, i) => ({ column, categories: input.categories[i], reverse: input.reverse.includes(i) })), nFactors: input.nFactors, extraction: "wlsmv", rotation: "oblimin", missing: input.missing, label: "Cache qualification", seed: 73021, sample: { partition: "all" }, compute: { backend, blockSize } };
    let origin;
    for (const rotation of ["oblimin", "promax", "varimax"]) {
      const job = service.fit(input, { ...spec, rotation }, Array.from({ length: input.nRows }, (_, i) => i));
      const result = await job.promise, report = service.report(job.id);
      if (rotation === "oblimin") origin = job.id;
      else {
        if (result.provenance.execution.reusedFromJobId !== origin) throw new Error("Invariant cache was not used");
        if (report.execution.timings || report.requests["fit-cache"]) throw new Error("Cache hit presented fresh trace work");
        if (Object.keys(report.workerStages).some((stage) => /Ordinal uncertainty|Robust trace|Case projection/.test(stage))) throw new Error("Invariant work repeated");
      }
      const saved = { runs: [{ id: job.id, revision: 1, createdAt: (/* @__PURE__ */ new Date()).toISOString(), datasetRevision: "synthetic", spec: { ...spec, rotation }, result, eligibleRows: Array.from({ length: input.nRows }, (_, i) => i), kind: "fit", reviews: {}, reasons: "qualification", revisedAfterHoldout: false, scoreColumns: [] }], splits: [] };
      validateEfaState(JSON.parse(JSON.stringify(saved)), input.nRows);
      results.push({ name, rotation, result, report });
    }
  }
  return results;
};
