var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/is-any-array/lib/index.js
var require_lib = __commonJS({
  "node_modules/is-any-array/lib/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.isAnyArray = void 0;
    var toString = Object.prototype.toString;
    function isAnyArray(value) {
      const tag = toString.call(value);
      return tag.endsWith("Array]") && !tag.includes("Big");
    }
    exports.isAnyArray = isAnyArray;
  }
});

// node_modules/ml-array-max/lib/index.js
var require_lib2 = __commonJS({
  "node_modules/ml-array-max/lib/index.js"(exports, module) {
    "use strict";
    var isAnyArray = require_lib();
    function max(input, options = {}) {
      if (!isAnyArray.isAnyArray(input)) {
        throw new TypeError("input must be an array");
      }
      if (input.length === 0) {
        throw new TypeError("input must not be empty");
      }
      const { fromIndex = 0, toIndex = input.length } = options;
      if (fromIndex < 0 || fromIndex >= input.length || !Number.isInteger(fromIndex)) {
        throw new Error("fromIndex must be a positive integer smaller than length");
      }
      if (toIndex <= fromIndex || toIndex > input.length || !Number.isInteger(toIndex)) {
        throw new Error(
          "toIndex must be an integer greater than fromIndex and at most equal to length"
        );
      }
      let maxValue = input[fromIndex];
      for (let i = fromIndex + 1; i < toIndex; i++) {
        if (input[i] > maxValue) maxValue = input[i];
      }
      return maxValue;
    }
    module.exports = max;
  }
});

// node_modules/ml-array-min/lib/index.js
var require_lib3 = __commonJS({
  "node_modules/ml-array-min/lib/index.js"(exports, module) {
    "use strict";
    var isAnyArray = require_lib();
    function min(input, options = {}) {
      if (!isAnyArray.isAnyArray(input)) {
        throw new TypeError("input must be an array");
      }
      if (input.length === 0) {
        throw new TypeError("input must not be empty");
      }
      const { fromIndex = 0, toIndex = input.length } = options;
      if (fromIndex < 0 || fromIndex >= input.length || !Number.isInteger(fromIndex)) {
        throw new Error("fromIndex must be a positive integer smaller than length");
      }
      if (toIndex <= fromIndex || toIndex > input.length || !Number.isInteger(toIndex)) {
        throw new Error(
          "toIndex must be an integer greater than fromIndex and at most equal to length"
        );
      }
      let minValue = input[fromIndex];
      for (let i = fromIndex + 1; i < toIndex; i++) {
        if (input[i] < minValue) minValue = input[i];
      }
      return minValue;
    }
    module.exports = min;
  }
});

// node_modules/ml-array-rescale/lib/index.js
var require_lib4 = __commonJS({
  "node_modules/ml-array-rescale/lib/index.js"(exports, module) {
    "use strict";
    var isAnyArray = require_lib();
    var max = require_lib2();
    var min = require_lib3();
    function _interopDefaultLegacy(e) {
      return e && typeof e === "object" && "default" in e ? e : { "default": e };
    }
    var max__default = /* @__PURE__ */ _interopDefaultLegacy(max);
    var min__default = /* @__PURE__ */ _interopDefaultLegacy(min);
    function rescale(input, options = {}) {
      if (!isAnyArray.isAnyArray(input)) {
        throw new TypeError("input must be an array");
      } else if (input.length === 0) {
        throw new TypeError("input must not be empty");
      }
      let output;
      if (options.output !== void 0) {
        if (!isAnyArray.isAnyArray(options.output)) {
          throw new TypeError("output option must be an array if specified");
        }
        output = options.output;
      } else {
        output = new Array(input.length);
      }
      const currentMin = min__default["default"](input);
      const currentMax = max__default["default"](input);
      if (currentMin === currentMax) {
        throw new RangeError(
          "minimum and maximum input values are equal. Cannot rescale a constant array"
        );
      }
      const {
        min: minValue = options.autoMinMax ? currentMin : 0,
        max: maxValue = options.autoMinMax ? currentMax : 1
      } = options;
      if (minValue >= maxValue) {
        throw new RangeError("min option must be smaller than max option");
      }
      const factor = (maxValue - minValue) / (currentMax - currentMin);
      for (let i = 0; i < input.length; i++) {
        output[i] = (input[i] - currentMin) * factor + minValue;
      }
      return output;
    }
    module.exports = rescale;
  }
});

// node_modules/ml-matrix/matrix.js
var require_matrix = __commonJS({
  "node_modules/ml-matrix/matrix.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var isAnyArray = require_lib();
    var rescale = require_lib4();
    var indent = " ".repeat(2);
    var indentData = " ".repeat(4);
    function inspectMatrix() {
      return inspectMatrixWithOptions(this);
    }
    function inspectMatrixWithOptions(matrix2, options = {}) {
      const {
        maxRows = 15,
        maxColumns = 10,
        maxNumSize = 8,
        padMinus = "auto"
      } = options;
      return `${matrix2.constructor.name} {
${indent}[
${indentData}${inspectData(matrix2, maxRows, maxColumns, maxNumSize, padMinus)}
${indent}]
${indent}rows: ${matrix2.rows}
${indent}columns: ${matrix2.columns}
}`;
    }
    function inspectData(matrix2, maxRows, maxColumns, maxNumSize, padMinus) {
      const { rows, columns } = matrix2;
      const maxI = Math.min(rows, maxRows);
      const maxJ = Math.min(columns, maxColumns);
      const result = [];
      if (padMinus === "auto") {
        padMinus = false;
        loop: for (let i = 0; i < maxI; i++) {
          for (let j = 0; j < maxJ; j++) {
            if (matrix2.get(i, j) < 0) {
              padMinus = true;
              break loop;
            }
          }
        }
      }
      for (let i = 0; i < maxI; i++) {
        let line = [];
        for (let j = 0; j < maxJ; j++) {
          line.push(formatNumber(matrix2.get(i, j), maxNumSize, padMinus));
        }
        result.push(`${line.join(" ")}`);
      }
      if (maxJ !== columns) {
        result[result.length - 1] += ` ... ${columns - maxColumns} more columns`;
      }
      if (maxI !== rows) {
        result.push(`... ${rows - maxRows} more rows`);
      }
      return result.join(`
${indentData}`);
    }
    function formatNumber(num, maxNumSize, padMinus) {
      return (num >= 0 && padMinus ? ` ${formatNumber2(num, maxNumSize - 1)}` : formatNumber2(num, maxNumSize)).padEnd(maxNumSize);
    }
    function formatNumber2(num, len) {
      let str = num.toString();
      if (str.length <= len) return str;
      let fix = num.toFixed(len);
      if (fix.length > len) {
        fix = num.toFixed(Math.max(0, len - (fix.length - len)));
      }
      if (fix.length <= len && !fix.startsWith("0.000") && !fix.startsWith("-0.000")) {
        return fix;
      }
      let exp = num.toExponential(len);
      if (exp.length > len) {
        exp = num.toExponential(Math.max(0, len - (exp.length - len)));
      }
      return exp.slice(0);
    }
    function installMathOperations(AbstractMatrix3, Matrix4) {
      AbstractMatrix3.prototype.add = function add(value) {
        if (typeof value === "number") return this.addS(value);
        return this.addM(value);
      };
      AbstractMatrix3.prototype.addS = function addS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) + value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.addM = function addM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) + matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.add = function add(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.add(value);
      };
      AbstractMatrix3.prototype.sub = function sub(value) {
        if (typeof value === "number") return this.subS(value);
        return this.subM(value);
      };
      AbstractMatrix3.prototype.subS = function subS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) - value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.subM = function subM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) - matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.sub = function sub(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.sub(value);
      };
      AbstractMatrix3.prototype.subtract = AbstractMatrix3.prototype.sub;
      AbstractMatrix3.prototype.subtractS = AbstractMatrix3.prototype.subS;
      AbstractMatrix3.prototype.subtractM = AbstractMatrix3.prototype.subM;
      AbstractMatrix3.subtract = AbstractMatrix3.sub;
      AbstractMatrix3.prototype.mul = function mul(value) {
        if (typeof value === "number") return this.mulS(value);
        return this.mulM(value);
      };
      AbstractMatrix3.prototype.mulS = function mulS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) * value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.mulM = function mulM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) * matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.mul = function mul(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.mul(value);
      };
      AbstractMatrix3.prototype.multiply = AbstractMatrix3.prototype.mul;
      AbstractMatrix3.prototype.multiplyS = AbstractMatrix3.prototype.mulS;
      AbstractMatrix3.prototype.multiplyM = AbstractMatrix3.prototype.mulM;
      AbstractMatrix3.multiply = AbstractMatrix3.mul;
      AbstractMatrix3.prototype.div = function div(value) {
        if (typeof value === "number") return this.divS(value);
        return this.divM(value);
      };
      AbstractMatrix3.prototype.divS = function divS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) / value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.divM = function divM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) / matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.div = function div(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.div(value);
      };
      AbstractMatrix3.prototype.divide = AbstractMatrix3.prototype.div;
      AbstractMatrix3.prototype.divideS = AbstractMatrix3.prototype.divS;
      AbstractMatrix3.prototype.divideM = AbstractMatrix3.prototype.divM;
      AbstractMatrix3.divide = AbstractMatrix3.div;
      AbstractMatrix3.prototype.mod = function mod(value) {
        if (typeof value === "number") return this.modS(value);
        return this.modM(value);
      };
      AbstractMatrix3.prototype.modS = function modS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) % value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.modM = function modM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) % matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.mod = function mod(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.mod(value);
      };
      AbstractMatrix3.prototype.modulus = AbstractMatrix3.prototype.mod;
      AbstractMatrix3.prototype.modulusS = AbstractMatrix3.prototype.modS;
      AbstractMatrix3.prototype.modulusM = AbstractMatrix3.prototype.modM;
      AbstractMatrix3.modulus = AbstractMatrix3.mod;
      AbstractMatrix3.prototype.and = function and(value) {
        if (typeof value === "number") return this.andS(value);
        return this.andM(value);
      };
      AbstractMatrix3.prototype.andS = function andS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) & value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.andM = function andM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) & matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.and = function and(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.and(value);
      };
      AbstractMatrix3.prototype.or = function or(value) {
        if (typeof value === "number") return this.orS(value);
        return this.orM(value);
      };
      AbstractMatrix3.prototype.orS = function orS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) | value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.orM = function orM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) | matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.or = function or(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.or(value);
      };
      AbstractMatrix3.prototype.xor = function xor(value) {
        if (typeof value === "number") return this.xorS(value);
        return this.xorM(value);
      };
      AbstractMatrix3.prototype.xorS = function xorS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) ^ value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.xorM = function xorM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) ^ matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.xor = function xor(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.xor(value);
      };
      AbstractMatrix3.prototype.leftShift = function leftShift(value) {
        if (typeof value === "number") return this.leftShiftS(value);
        return this.leftShiftM(value);
      };
      AbstractMatrix3.prototype.leftShiftS = function leftShiftS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) << value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.leftShiftM = function leftShiftM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) << matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.leftShift = function leftShift(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.leftShift(value);
      };
      AbstractMatrix3.prototype.signPropagatingRightShift = function signPropagatingRightShift(value) {
        if (typeof value === "number") return this.signPropagatingRightShiftS(value);
        return this.signPropagatingRightShiftM(value);
      };
      AbstractMatrix3.prototype.signPropagatingRightShiftS = function signPropagatingRightShiftS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) >> value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.signPropagatingRightShiftM = function signPropagatingRightShiftM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) >> matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.signPropagatingRightShift = function signPropagatingRightShift(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.signPropagatingRightShift(value);
      };
      AbstractMatrix3.prototype.rightShift = function rightShift(value) {
        if (typeof value === "number") return this.rightShiftS(value);
        return this.rightShiftM(value);
      };
      AbstractMatrix3.prototype.rightShiftS = function rightShiftS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) >>> value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.rightShiftM = function rightShiftM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) >>> matrix2.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.rightShift = function rightShift(matrix2, value) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.rightShift(value);
      };
      AbstractMatrix3.prototype.zeroFillRightShift = AbstractMatrix3.prototype.rightShift;
      AbstractMatrix3.prototype.zeroFillRightShiftS = AbstractMatrix3.prototype.rightShiftS;
      AbstractMatrix3.prototype.zeroFillRightShiftM = AbstractMatrix3.prototype.rightShiftM;
      AbstractMatrix3.zeroFillRightShift = AbstractMatrix3.rightShift;
      AbstractMatrix3.prototype.not = function not() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, ~this.get(i, j));
          }
        }
        return this;
      };
      AbstractMatrix3.not = function not(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.not();
      };
      AbstractMatrix3.prototype.abs = function abs() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.abs(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.abs = function abs(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.abs();
      };
      AbstractMatrix3.prototype.acos = function acos() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.acos(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.acos = function acos(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.acos();
      };
      AbstractMatrix3.prototype.acosh = function acosh() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.acosh(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.acosh = function acosh(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.acosh();
      };
      AbstractMatrix3.prototype.asin = function asin() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.asin(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.asin = function asin(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.asin();
      };
      AbstractMatrix3.prototype.asinh = function asinh() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.asinh(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.asinh = function asinh(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.asinh();
      };
      AbstractMatrix3.prototype.atan = function atan() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.atan(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.atan = function atan(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.atan();
      };
      AbstractMatrix3.prototype.atanh = function atanh() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.atanh(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.atanh = function atanh(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.atanh();
      };
      AbstractMatrix3.prototype.cbrt = function cbrt() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.cbrt(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.cbrt = function cbrt(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.cbrt();
      };
      AbstractMatrix3.prototype.ceil = function ceil() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.ceil(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.ceil = function ceil(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.ceil();
      };
      AbstractMatrix3.prototype.clz32 = function clz32() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.clz32(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.clz32 = function clz32(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.clz32();
      };
      AbstractMatrix3.prototype.cos = function cos() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.cos(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.cos = function cos(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.cos();
      };
      AbstractMatrix3.prototype.cosh = function cosh() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.cosh(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.cosh = function cosh(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.cosh();
      };
      AbstractMatrix3.prototype.exp = function exp() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.exp(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.exp = function exp(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.exp();
      };
      AbstractMatrix3.prototype.expm1 = function expm1() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.expm1(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.expm1 = function expm1(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.expm1();
      };
      AbstractMatrix3.prototype.floor = function floor() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.floor(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.floor = function floor(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.floor();
      };
      AbstractMatrix3.prototype.fround = function fround() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.fround(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.fround = function fround(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.fround();
      };
      AbstractMatrix3.prototype.log = function log() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.log(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.log = function log(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.log();
      };
      AbstractMatrix3.prototype.log1p = function log1p() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.log1p(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.log1p = function log1p(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.log1p();
      };
      AbstractMatrix3.prototype.log10 = function log10() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.log10(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.log10 = function log10(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.log10();
      };
      AbstractMatrix3.prototype.log2 = function log2() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.log2(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.log2 = function log2(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.log2();
      };
      AbstractMatrix3.prototype.round = function round() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.round(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.round = function round(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.round();
      };
      AbstractMatrix3.prototype.sign = function sign() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.sign(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.sign = function sign(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.sign();
      };
      AbstractMatrix3.prototype.sin = function sin() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.sin(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.sin = function sin(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.sin();
      };
      AbstractMatrix3.prototype.sinh = function sinh() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.sinh(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.sinh = function sinh(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.sinh();
      };
      AbstractMatrix3.prototype.sqrt = function sqrt() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.sqrt(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.sqrt = function sqrt(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.sqrt();
      };
      AbstractMatrix3.prototype.tan = function tan() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.tan(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.tan = function tan(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.tan();
      };
      AbstractMatrix3.prototype.tanh = function tanh() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.tanh(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.tanh = function tanh(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.tanh();
      };
      AbstractMatrix3.prototype.trunc = function trunc() {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, Math.trunc(this.get(i, j)));
          }
        }
        return this;
      };
      AbstractMatrix3.trunc = function trunc(matrix2) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.trunc();
      };
      AbstractMatrix3.pow = function pow(matrix2, arg0) {
        const newMatrix = new Matrix4(matrix2);
        return newMatrix.pow(arg0);
      };
      AbstractMatrix3.prototype.pow = function pow(value) {
        if (typeof value === "number") return this.powS(value);
        return this.powM(value);
      };
      AbstractMatrix3.prototype.powS = function powS(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) ** value);
          }
        }
        return this;
      };
      AbstractMatrix3.prototype.powM = function powM(matrix2) {
        matrix2 = Matrix4.checkMatrix(matrix2);
        if (this.rows !== matrix2.rows || this.columns !== matrix2.columns) {
          throw new RangeError("Matrices dimensions must be equal");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) ** matrix2.get(i, j));
          }
        }
        return this;
      };
    }
    function checkRowIndex(matrix2, index, outer) {
      let max = outer ? matrix2.rows : matrix2.rows - 1;
      if (index < 0 || index > max) {
        throw new RangeError("Row index out of range");
      }
    }
    function checkColumnIndex(matrix2, index, outer) {
      let max = outer ? matrix2.columns : matrix2.columns - 1;
      if (index < 0 || index > max) {
        throw new RangeError("Column index out of range");
      }
    }
    function checkRowVector(matrix2, vector) {
      if (vector.to1DArray) {
        vector = vector.to1DArray();
      }
      if (vector.length !== matrix2.columns) {
        throw new RangeError(
          "vector size must be the same as the number of columns"
        );
      }
      return vector;
    }
    function checkColumnVector(matrix2, vector) {
      if (vector.to1DArray) {
        vector = vector.to1DArray();
      }
      if (vector.length !== matrix2.rows) {
        throw new RangeError("vector size must be the same as the number of rows");
      }
      return vector;
    }
    function checkRowIndices(matrix2, rowIndices) {
      if (!isAnyArray.isAnyArray(rowIndices)) {
        throw new TypeError("row indices must be an array");
      }
      for (let i = 0; i < rowIndices.length; i++) {
        if (rowIndices[i] < 0 || rowIndices[i] >= matrix2.rows) {
          throw new RangeError("row indices are out of range");
        }
      }
    }
    function checkColumnIndices(matrix2, columnIndices) {
      if (!isAnyArray.isAnyArray(columnIndices)) {
        throw new TypeError("column indices must be an array");
      }
      for (let i = 0; i < columnIndices.length; i++) {
        if (columnIndices[i] < 0 || columnIndices[i] >= matrix2.columns) {
          throw new RangeError("column indices are out of range");
        }
      }
    }
    function checkRange(matrix2, startRow, endRow, startColumn, endColumn) {
      if (arguments.length !== 5) {
        throw new RangeError("expected 4 arguments");
      }
      checkNumber("startRow", startRow);
      checkNumber("endRow", endRow);
      checkNumber("startColumn", startColumn);
      checkNumber("endColumn", endColumn);
      if (startRow > endRow || startColumn > endColumn || startRow < 0 || startRow >= matrix2.rows || endRow < 0 || endRow >= matrix2.rows || startColumn < 0 || startColumn >= matrix2.columns || endColumn < 0 || endColumn >= matrix2.columns) {
        throw new RangeError("Submatrix indices are out of range");
      }
    }
    function newArray(length, value = 0) {
      let array = [];
      for (let i = 0; i < length; i++) {
        array.push(value);
      }
      return array;
    }
    function checkNumber(name, value) {
      if (typeof value !== "number") {
        throw new TypeError(`${name} must be a number`);
      }
    }
    function checkNonEmpty(matrix2) {
      if (matrix2.isEmpty()) {
        throw new Error("Empty matrix has no elements to index");
      }
    }
    function sumByRow(matrix2) {
      let sum = newArray(matrix2.rows);
      for (let i = 0; i < matrix2.rows; ++i) {
        for (let j = 0; j < matrix2.columns; ++j) {
          sum[i] += matrix2.get(i, j);
        }
      }
      return sum;
    }
    function sumByColumn(matrix2) {
      let sum = newArray(matrix2.columns);
      for (let i = 0; i < matrix2.rows; ++i) {
        for (let j = 0; j < matrix2.columns; ++j) {
          sum[j] += matrix2.get(i, j);
        }
      }
      return sum;
    }
    function sumAll(matrix2) {
      let v = 0;
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          v += matrix2.get(i, j);
        }
      }
      return v;
    }
    function productByRow(matrix2) {
      let sum = newArray(matrix2.rows, 1);
      for (let i = 0; i < matrix2.rows; ++i) {
        for (let j = 0; j < matrix2.columns; ++j) {
          sum[i] *= matrix2.get(i, j);
        }
      }
      return sum;
    }
    function productByColumn(matrix2) {
      let sum = newArray(matrix2.columns, 1);
      for (let i = 0; i < matrix2.rows; ++i) {
        for (let j = 0; j < matrix2.columns; ++j) {
          sum[j] *= matrix2.get(i, j);
        }
      }
      return sum;
    }
    function productAll(matrix2) {
      let v = 1;
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          v *= matrix2.get(i, j);
        }
      }
      return v;
    }
    function varianceByRow(matrix2, unbiased, mean) {
      const rows = matrix2.rows;
      const cols = matrix2.columns;
      const variance = [];
      for (let i = 0; i < rows; i++) {
        let sum1 = 0;
        let sum2 = 0;
        let x = 0;
        for (let j = 0; j < cols; j++) {
          x = matrix2.get(i, j) - mean[i];
          sum1 += x;
          sum2 += x * x;
        }
        if (unbiased) {
          variance.push((sum2 - sum1 * sum1 / cols) / (cols - 1));
        } else {
          variance.push((sum2 - sum1 * sum1 / cols) / cols);
        }
      }
      return variance;
    }
    function varianceByColumn(matrix2, unbiased, mean) {
      const rows = matrix2.rows;
      const cols = matrix2.columns;
      const variance = [];
      for (let j = 0; j < cols; j++) {
        let sum1 = 0;
        let sum2 = 0;
        let x = 0;
        for (let i = 0; i < rows; i++) {
          x = matrix2.get(i, j) - mean[j];
          sum1 += x;
          sum2 += x * x;
        }
        if (unbiased) {
          variance.push((sum2 - sum1 * sum1 / rows) / (rows - 1));
        } else {
          variance.push((sum2 - sum1 * sum1 / rows) / rows);
        }
      }
      return variance;
    }
    function varianceAll(matrix2, unbiased, mean) {
      const rows = matrix2.rows;
      const cols = matrix2.columns;
      const size = rows * cols;
      let sum1 = 0;
      let sum2 = 0;
      let x = 0;
      for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
          x = matrix2.get(i, j) - mean;
          sum1 += x;
          sum2 += x * x;
        }
      }
      if (unbiased) {
        return (sum2 - sum1 * sum1 / size) / (size - 1);
      } else {
        return (sum2 - sum1 * sum1 / size) / size;
      }
    }
    function centerByRow(matrix2, mean) {
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          matrix2.set(i, j, matrix2.get(i, j) - mean[i]);
        }
      }
    }
    function centerByColumn(matrix2, mean) {
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          matrix2.set(i, j, matrix2.get(i, j) - mean[j]);
        }
      }
    }
    function centerAll(matrix2, mean) {
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          matrix2.set(i, j, matrix2.get(i, j) - mean);
        }
      }
    }
    function getScaleByRow(matrix2) {
      const scale = [];
      for (let i = 0; i < matrix2.rows; i++) {
        let sum = 0;
        for (let j = 0; j < matrix2.columns; j++) {
          sum += matrix2.get(i, j) ** 2 / (matrix2.columns - 1);
        }
        scale.push(Math.sqrt(sum));
      }
      return scale;
    }
    function scaleByRow(matrix2, scale) {
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          matrix2.set(i, j, matrix2.get(i, j) / scale[i]);
        }
      }
    }
    function getScaleByColumn(matrix2) {
      const scale = [];
      for (let j = 0; j < matrix2.columns; j++) {
        let sum = 0;
        for (let i = 0; i < matrix2.rows; i++) {
          sum += matrix2.get(i, j) ** 2 / (matrix2.rows - 1);
        }
        scale.push(Math.sqrt(sum));
      }
      return scale;
    }
    function scaleByColumn(matrix2, scale) {
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          matrix2.set(i, j, matrix2.get(i, j) / scale[j]);
        }
      }
    }
    function getScaleAll(matrix2) {
      const divider = matrix2.size - 1;
      let sum = 0;
      for (let j = 0; j < matrix2.columns; j++) {
        for (let i = 0; i < matrix2.rows; i++) {
          sum += matrix2.get(i, j) ** 2 / divider;
        }
      }
      return Math.sqrt(sum);
    }
    function scaleAll(matrix2, scale) {
      for (let i = 0; i < matrix2.rows; i++) {
        for (let j = 0; j < matrix2.columns; j++) {
          matrix2.set(i, j, matrix2.get(i, j) / scale);
        }
      }
    }
    var AbstractMatrix2 = class _AbstractMatrix {
      static from1DArray(newRows, newColumns, newData) {
        let length = newRows * newColumns;
        if (length !== newData.length) {
          throw new RangeError("data length does not match given dimensions");
        }
        let newMatrix = new Matrix3(newRows, newColumns);
        for (let row = 0; row < newRows; row++) {
          for (let column = 0; column < newColumns; column++) {
            newMatrix.set(row, column, newData[row * newColumns + column]);
          }
        }
        return newMatrix;
      }
      static rowVector(newData) {
        let vector = new Matrix3(1, newData.length);
        for (let i = 0; i < newData.length; i++) {
          vector.set(0, i, newData[i]);
        }
        return vector;
      }
      static columnVector(newData) {
        let vector = new Matrix3(newData.length, 1);
        for (let i = 0; i < newData.length; i++) {
          vector.set(i, 0, newData[i]);
        }
        return vector;
      }
      static zeros(rows, columns) {
        return new Matrix3(rows, columns);
      }
      static ones(rows, columns) {
        return new Matrix3(rows, columns).fill(1);
      }
      static rand(rows, columns, options = {}) {
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        const { random = Math.random } = options;
        let matrix2 = new Matrix3(rows, columns);
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            matrix2.set(i, j, random());
          }
        }
        return matrix2;
      }
      static randInt(rows, columns, options = {}) {
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        const { min = 0, max = 1e3, random = Math.random } = options;
        if (!Number.isInteger(min)) throw new TypeError("min must be an integer");
        if (!Number.isInteger(max)) throw new TypeError("max must be an integer");
        if (min >= max) throw new RangeError("min must be smaller than max");
        let interval = max - min;
        let matrix2 = new Matrix3(rows, columns);
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            let value = min + Math.round(random() * interval);
            matrix2.set(i, j, value);
          }
        }
        return matrix2;
      }
      static eye(rows, columns, value) {
        if (columns === void 0) columns = rows;
        if (value === void 0) value = 1;
        let min = Math.min(rows, columns);
        let matrix2 = this.zeros(rows, columns);
        for (let i = 0; i < min; i++) {
          matrix2.set(i, i, value);
        }
        return matrix2;
      }
      static diag(data, rows, columns) {
        let l = data.length;
        if (rows === void 0) rows = l;
        if (columns === void 0) columns = rows;
        let min = Math.min(l, rows, columns);
        let matrix2 = this.zeros(rows, columns);
        for (let i = 0; i < min; i++) {
          matrix2.set(i, i, data[i]);
        }
        return matrix2;
      }
      static min(matrix1, matrix2) {
        matrix1 = this.checkMatrix(matrix1);
        matrix2 = this.checkMatrix(matrix2);
        let rows = matrix1.rows;
        let columns = matrix1.columns;
        let result = new Matrix3(rows, columns);
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            result.set(i, j, Math.min(matrix1.get(i, j), matrix2.get(i, j)));
          }
        }
        return result;
      }
      static max(matrix1, matrix2) {
        matrix1 = this.checkMatrix(matrix1);
        matrix2 = this.checkMatrix(matrix2);
        let rows = matrix1.rows;
        let columns = matrix1.columns;
        let result = new this(rows, columns);
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            result.set(i, j, Math.max(matrix1.get(i, j), matrix2.get(i, j)));
          }
        }
        return result;
      }
      static checkMatrix(value) {
        return _AbstractMatrix.isMatrix(value) ? value : new Matrix3(value);
      }
      static isMatrix(value) {
        return value != null && value.klass === "Matrix";
      }
      get size() {
        return this.rows * this.columns;
      }
      apply(callback) {
        if (typeof callback !== "function") {
          throw new TypeError("callback must be a function");
        }
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            callback.call(this, i, j);
          }
        }
        return this;
      }
      to1DArray() {
        let array = [];
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            array.push(this.get(i, j));
          }
        }
        return array;
      }
      to2DArray() {
        let copy = [];
        for (let i = 0; i < this.rows; i++) {
          copy.push([]);
          for (let j = 0; j < this.columns; j++) {
            copy[i].push(this.get(i, j));
          }
        }
        return copy;
      }
      toJSON() {
        return this.to2DArray();
      }
      isRowVector() {
        return this.rows === 1;
      }
      isColumnVector() {
        return this.columns === 1;
      }
      isVector() {
        return this.rows === 1 || this.columns === 1;
      }
      isSquare() {
        return this.rows === this.columns;
      }
      isEmpty() {
        return this.rows === 0 || this.columns === 0;
      }
      isSymmetric() {
        if (this.isSquare()) {
          for (let i = 0; i < this.rows; i++) {
            for (let j = 0; j <= i; j++) {
              if (this.get(i, j) !== this.get(j, i)) {
                return false;
              }
            }
          }
          return true;
        }
        return false;
      }
      isDistance() {
        if (!this.isSymmetric()) return false;
        for (let i = 0; i < this.rows; i++) {
          if (this.get(i, i) !== 0) return false;
        }
        return true;
      }
      isEchelonForm() {
        let i = 0;
        let j = 0;
        let previousColumn = -1;
        let isEchelonForm = true;
        let checked = false;
        while (i < this.rows && isEchelonForm) {
          j = 0;
          checked = false;
          while (j < this.columns && checked === false) {
            if (this.get(i, j) === 0) {
              j++;
            } else if (this.get(i, j) === 1 && j > previousColumn) {
              checked = true;
              previousColumn = j;
            } else {
              isEchelonForm = false;
              checked = true;
            }
          }
          i++;
        }
        return isEchelonForm;
      }
      isReducedEchelonForm() {
        let i = 0;
        let j = 0;
        let previousColumn = -1;
        let isReducedEchelonForm = true;
        let checked = false;
        while (i < this.rows && isReducedEchelonForm) {
          j = 0;
          checked = false;
          while (j < this.columns && checked === false) {
            if (this.get(i, j) === 0) {
              j++;
            } else if (this.get(i, j) === 1 && j > previousColumn) {
              checked = true;
              previousColumn = j;
            } else {
              isReducedEchelonForm = false;
              checked = true;
            }
          }
          for (let k = j + 1; k < this.rows; k++) {
            if (this.get(i, k) !== 0) {
              isReducedEchelonForm = false;
            }
          }
          i++;
        }
        return isReducedEchelonForm;
      }
      echelonForm() {
        let result = this.clone();
        let h = 0;
        let k = 0;
        while (h < result.rows && k < result.columns) {
          let iMax = h;
          for (let i = h; i < result.rows; i++) {
            if (result.get(i, k) > result.get(iMax, k)) {
              iMax = i;
            }
          }
          if (result.get(iMax, k) === 0) {
            k++;
          } else {
            result.swapRows(h, iMax);
            let tmp = result.get(h, k);
            for (let j = k; j < result.columns; j++) {
              result.set(h, j, result.get(h, j) / tmp);
            }
            for (let i = h + 1; i < result.rows; i++) {
              let factor = result.get(i, k) / result.get(h, k);
              result.set(i, k, 0);
              for (let j = k + 1; j < result.columns; j++) {
                result.set(i, j, result.get(i, j) - result.get(h, j) * factor);
              }
            }
            h++;
            k++;
          }
        }
        return result;
      }
      reducedEchelonForm() {
        let result = this.echelonForm();
        let m = result.columns;
        let n = result.rows;
        let h = n - 1;
        while (h >= 0) {
          if (result.maxRow(h) === 0) {
            h--;
          } else {
            let p = 0;
            let pivot = false;
            while (p < n && pivot === false) {
              if (result.get(h, p) === 1) {
                pivot = true;
              } else {
                p++;
              }
            }
            for (let i = 0; i < h; i++) {
              let factor = result.get(i, p);
              for (let j = p; j < m; j++) {
                let tmp = result.get(i, j) - factor * result.get(h, j);
                result.set(i, j, tmp);
              }
            }
            h--;
          }
        }
        return result;
      }
      set() {
        throw new Error("set method is unimplemented");
      }
      get() {
        throw new Error("get method is unimplemented");
      }
      repeat(options = {}) {
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        const { rows = 1, columns = 1 } = options;
        if (!Number.isInteger(rows) || rows <= 0) {
          throw new TypeError("rows must be a positive integer");
        }
        if (!Number.isInteger(columns) || columns <= 0) {
          throw new TypeError("columns must be a positive integer");
        }
        let matrix2 = new Matrix3(this.rows * rows, this.columns * columns);
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            matrix2.setSubMatrix(this, this.rows * i, this.columns * j);
          }
        }
        return matrix2;
      }
      fill(value) {
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, value);
          }
        }
        return this;
      }
      neg() {
        return this.mulS(-1);
      }
      getRow(index) {
        checkRowIndex(this, index);
        let row = [];
        for (let i = 0; i < this.columns; i++) {
          row.push(this.get(index, i));
        }
        return row;
      }
      getRowVector(index) {
        return Matrix3.rowVector(this.getRow(index));
      }
      setRow(index, array) {
        checkRowIndex(this, index);
        array = checkRowVector(this, array);
        for (let i = 0; i < this.columns; i++) {
          this.set(index, i, array[i]);
        }
        return this;
      }
      swapRows(row1, row2) {
        checkRowIndex(this, row1);
        checkRowIndex(this, row2);
        for (let i = 0; i < this.columns; i++) {
          let temp = this.get(row1, i);
          this.set(row1, i, this.get(row2, i));
          this.set(row2, i, temp);
        }
        return this;
      }
      getColumn(index) {
        checkColumnIndex(this, index);
        let column = [];
        for (let i = 0; i < this.rows; i++) {
          column.push(this.get(i, index));
        }
        return column;
      }
      getColumnVector(index) {
        return Matrix3.columnVector(this.getColumn(index));
      }
      setColumn(index, array) {
        checkColumnIndex(this, index);
        array = checkColumnVector(this, array);
        for (let i = 0; i < this.rows; i++) {
          this.set(i, index, array[i]);
        }
        return this;
      }
      swapColumns(column1, column2) {
        checkColumnIndex(this, column1);
        checkColumnIndex(this, column2);
        for (let i = 0; i < this.rows; i++) {
          let temp = this.get(i, column1);
          this.set(i, column1, this.get(i, column2));
          this.set(i, column2, temp);
        }
        return this;
      }
      addRowVector(vector) {
        vector = checkRowVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) + vector[j]);
          }
        }
        return this;
      }
      subRowVector(vector) {
        vector = checkRowVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) - vector[j]);
          }
        }
        return this;
      }
      mulRowVector(vector) {
        vector = checkRowVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) * vector[j]);
          }
        }
        return this;
      }
      divRowVector(vector) {
        vector = checkRowVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) / vector[j]);
          }
        }
        return this;
      }
      addColumnVector(vector) {
        vector = checkColumnVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) + vector[i]);
          }
        }
        return this;
      }
      subColumnVector(vector) {
        vector = checkColumnVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) - vector[i]);
          }
        }
        return this;
      }
      mulColumnVector(vector) {
        vector = checkColumnVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) * vector[i]);
          }
        }
        return this;
      }
      divColumnVector(vector) {
        vector = checkColumnVector(this, vector);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            this.set(i, j, this.get(i, j) / vector[i]);
          }
        }
        return this;
      }
      mulRow(index, value) {
        checkRowIndex(this, index);
        for (let i = 0; i < this.columns; i++) {
          this.set(index, i, this.get(index, i) * value);
        }
        return this;
      }
      mulColumn(index, value) {
        checkColumnIndex(this, index);
        for (let i = 0; i < this.rows; i++) {
          this.set(i, index, this.get(i, index) * value);
        }
        return this;
      }
      max(by) {
        if (this.isEmpty()) {
          return NaN;
        }
        switch (by) {
          case "row": {
            const max = new Array(this.rows).fill(Number.NEGATIVE_INFINITY);
            for (let row = 0; row < this.rows; row++) {
              for (let column = 0; column < this.columns; column++) {
                if (this.get(row, column) > max[row]) {
                  max[row] = this.get(row, column);
                }
              }
            }
            return max;
          }
          case "column": {
            const max = new Array(this.columns).fill(Number.NEGATIVE_INFINITY);
            for (let row = 0; row < this.rows; row++) {
              for (let column = 0; column < this.columns; column++) {
                if (this.get(row, column) > max[column]) {
                  max[column] = this.get(row, column);
                }
              }
            }
            return max;
          }
          case void 0: {
            let max = this.get(0, 0);
            for (let row = 0; row < this.rows; row++) {
              for (let column = 0; column < this.columns; column++) {
                if (this.get(row, column) > max) {
                  max = this.get(row, column);
                }
              }
            }
            return max;
          }
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      maxIndex() {
        checkNonEmpty(this);
        let v = this.get(0, 0);
        let idx = [0, 0];
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            if (this.get(i, j) > v) {
              v = this.get(i, j);
              idx[0] = i;
              idx[1] = j;
            }
          }
        }
        return idx;
      }
      min(by) {
        if (this.isEmpty()) {
          return NaN;
        }
        switch (by) {
          case "row": {
            const min = new Array(this.rows).fill(Number.POSITIVE_INFINITY);
            for (let row = 0; row < this.rows; row++) {
              for (let column = 0; column < this.columns; column++) {
                if (this.get(row, column) < min[row]) {
                  min[row] = this.get(row, column);
                }
              }
            }
            return min;
          }
          case "column": {
            const min = new Array(this.columns).fill(Number.POSITIVE_INFINITY);
            for (let row = 0; row < this.rows; row++) {
              for (let column = 0; column < this.columns; column++) {
                if (this.get(row, column) < min[column]) {
                  min[column] = this.get(row, column);
                }
              }
            }
            return min;
          }
          case void 0: {
            let min = this.get(0, 0);
            for (let row = 0; row < this.rows; row++) {
              for (let column = 0; column < this.columns; column++) {
                if (this.get(row, column) < min) {
                  min = this.get(row, column);
                }
              }
            }
            return min;
          }
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      minIndex() {
        checkNonEmpty(this);
        let v = this.get(0, 0);
        let idx = [0, 0];
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            if (this.get(i, j) < v) {
              v = this.get(i, j);
              idx[0] = i;
              idx[1] = j;
            }
          }
        }
        return idx;
      }
      maxRow(row) {
        checkRowIndex(this, row);
        if (this.isEmpty()) {
          return NaN;
        }
        let v = this.get(row, 0);
        for (let i = 1; i < this.columns; i++) {
          if (this.get(row, i) > v) {
            v = this.get(row, i);
          }
        }
        return v;
      }
      maxRowIndex(row) {
        checkRowIndex(this, row);
        checkNonEmpty(this);
        let v = this.get(row, 0);
        let idx = [row, 0];
        for (let i = 1; i < this.columns; i++) {
          if (this.get(row, i) > v) {
            v = this.get(row, i);
            idx[1] = i;
          }
        }
        return idx;
      }
      minRow(row) {
        checkRowIndex(this, row);
        if (this.isEmpty()) {
          return NaN;
        }
        let v = this.get(row, 0);
        for (let i = 1; i < this.columns; i++) {
          if (this.get(row, i) < v) {
            v = this.get(row, i);
          }
        }
        return v;
      }
      minRowIndex(row) {
        checkRowIndex(this, row);
        checkNonEmpty(this);
        let v = this.get(row, 0);
        let idx = [row, 0];
        for (let i = 1; i < this.columns; i++) {
          if (this.get(row, i) < v) {
            v = this.get(row, i);
            idx[1] = i;
          }
        }
        return idx;
      }
      maxColumn(column) {
        checkColumnIndex(this, column);
        if (this.isEmpty()) {
          return NaN;
        }
        let v = this.get(0, column);
        for (let i = 1; i < this.rows; i++) {
          if (this.get(i, column) > v) {
            v = this.get(i, column);
          }
        }
        return v;
      }
      maxColumnIndex(column) {
        checkColumnIndex(this, column);
        checkNonEmpty(this);
        let v = this.get(0, column);
        let idx = [0, column];
        for (let i = 1; i < this.rows; i++) {
          if (this.get(i, column) > v) {
            v = this.get(i, column);
            idx[0] = i;
          }
        }
        return idx;
      }
      minColumn(column) {
        checkColumnIndex(this, column);
        if (this.isEmpty()) {
          return NaN;
        }
        let v = this.get(0, column);
        for (let i = 1; i < this.rows; i++) {
          if (this.get(i, column) < v) {
            v = this.get(i, column);
          }
        }
        return v;
      }
      minColumnIndex(column) {
        checkColumnIndex(this, column);
        checkNonEmpty(this);
        let v = this.get(0, column);
        let idx = [0, column];
        for (let i = 1; i < this.rows; i++) {
          if (this.get(i, column) < v) {
            v = this.get(i, column);
            idx[0] = i;
          }
        }
        return idx;
      }
      diag() {
        let min = Math.min(this.rows, this.columns);
        let diag = [];
        for (let i = 0; i < min; i++) {
          diag.push(this.get(i, i));
        }
        return diag;
      }
      norm(type = "frobenius") {
        switch (type) {
          case "max":
            return this.max();
          case "frobenius":
            return Math.sqrt(this.dot(this));
          default:
            throw new RangeError(`unknown norm type: ${type}`);
        }
      }
      cumulativeSum() {
        let sum = 0;
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            sum += this.get(i, j);
            this.set(i, j, sum);
          }
        }
        return this;
      }
      dot(vector2) {
        if (_AbstractMatrix.isMatrix(vector2)) vector2 = vector2.to1DArray();
        let vector1 = this.to1DArray();
        if (vector1.length !== vector2.length) {
          throw new RangeError("vectors do not have the same size");
        }
        let dot2 = 0;
        for (let i = 0; i < vector1.length; i++) {
          dot2 += vector1[i] * vector2[i];
        }
        return dot2;
      }
      mmul(other) {
        other = Matrix3.checkMatrix(other);
        let m = this.rows;
        let n = this.columns;
        let p = other.columns;
        let result = new Matrix3(m, p);
        let Bcolj = new Float64Array(n);
        for (let j = 0; j < p; j++) {
          for (let k = 0; k < n; k++) {
            Bcolj[k] = other.get(k, j);
          }
          for (let i = 0; i < m; i++) {
            let s = 0;
            for (let k = 0; k < n; k++) {
              s += this.get(i, k) * Bcolj[k];
            }
            result.set(i, j, s);
          }
        }
        return result;
      }
      mpow(scalar) {
        if (!this.isSquare()) {
          throw new RangeError("Matrix must be square");
        }
        if (!Number.isInteger(scalar) || scalar < 0) {
          throw new RangeError("Exponent must be a non-negative integer");
        }
        let result = Matrix3.eye(this.rows);
        let bb = this;
        for (let e = scalar; e >= 1; e /= 2) {
          if ((e & 1) !== 0) {
            result = result.mmul(bb);
          }
          bb = bb.mmul(bb);
        }
        return result;
      }
      strassen2x2(other) {
        other = Matrix3.checkMatrix(other);
        let result = new Matrix3(2, 2);
        const a11 = this.get(0, 0);
        const b11 = other.get(0, 0);
        const a12 = this.get(0, 1);
        const b12 = other.get(0, 1);
        const a21 = this.get(1, 0);
        const b21 = other.get(1, 0);
        const a22 = this.get(1, 1);
        const b22 = other.get(1, 1);
        const m1 = (a11 + a22) * (b11 + b22);
        const m2 = (a21 + a22) * b11;
        const m3 = a11 * (b12 - b22);
        const m4 = a22 * (b21 - b11);
        const m5 = (a11 + a12) * b22;
        const m6 = (a21 - a11) * (b11 + b12);
        const m7 = (a12 - a22) * (b21 + b22);
        const c00 = m1 + m4 - m5 + m7;
        const c01 = m3 + m5;
        const c10 = m2 + m4;
        const c11 = m1 - m2 + m3 + m6;
        result.set(0, 0, c00);
        result.set(0, 1, c01);
        result.set(1, 0, c10);
        result.set(1, 1, c11);
        return result;
      }
      strassen3x3(other) {
        other = Matrix3.checkMatrix(other);
        let result = new Matrix3(3, 3);
        const a00 = this.get(0, 0);
        const a01 = this.get(0, 1);
        const a02 = this.get(0, 2);
        const a10 = this.get(1, 0);
        const a11 = this.get(1, 1);
        const a12 = this.get(1, 2);
        const a20 = this.get(2, 0);
        const a21 = this.get(2, 1);
        const a22 = this.get(2, 2);
        const b00 = other.get(0, 0);
        const b01 = other.get(0, 1);
        const b02 = other.get(0, 2);
        const b10 = other.get(1, 0);
        const b11 = other.get(1, 1);
        const b12 = other.get(1, 2);
        const b20 = other.get(2, 0);
        const b21 = other.get(2, 1);
        const b22 = other.get(2, 2);
        const m1 = (a00 + a01 + a02 - a10 - a11 - a21 - a22) * b11;
        const m2 = (a00 - a10) * (-b01 + b11);
        const m3 = a11 * (-b00 + b01 + b10 - b11 - b12 - b20 + b22);
        const m4 = (-a00 + a10 + a11) * (b00 - b01 + b11);
        const m5 = (a10 + a11) * (-b00 + b01);
        const m6 = a00 * b00;
        const m7 = (-a00 + a20 + a21) * (b00 - b02 + b12);
        const m8 = (-a00 + a20) * (b02 - b12);
        const m9 = (a20 + a21) * (-b00 + b02);
        const m10 = (a00 + a01 + a02 - a11 - a12 - a20 - a21) * b12;
        const m11 = a21 * (-b00 + b02 + b10 - b11 - b12 - b20 + b21);
        const m12 = (-a02 + a21 + a22) * (b11 + b20 - b21);
        const m13 = (a02 - a22) * (b11 - b21);
        const m14 = a02 * b20;
        const m15 = (a21 + a22) * (-b20 + b21);
        const m16 = (-a02 + a11 + a12) * (b12 + b20 - b22);
        const m17 = (a02 - a12) * (b12 - b22);
        const m18 = (a11 + a12) * (-b20 + b22);
        const m19 = a01 * b10;
        const m20 = a12 * b21;
        const m21 = a10 * b02;
        const m22 = a20 * b01;
        const m23 = a22 * b22;
        const c00 = m6 + m14 + m19;
        const c01 = m1 + m4 + m5 + m6 + m12 + m14 + m15;
        const c02 = m6 + m7 + m9 + m10 + m14 + m16 + m18;
        const c10 = m2 + m3 + m4 + m6 + m14 + m16 + m17;
        const c11 = m2 + m4 + m5 + m6 + m20;
        const c12 = m14 + m16 + m17 + m18 + m21;
        const c20 = m6 + m7 + m8 + m11 + m12 + m13 + m14;
        const c21 = m12 + m13 + m14 + m15 + m22;
        const c22 = m6 + m7 + m8 + m9 + m23;
        result.set(0, 0, c00);
        result.set(0, 1, c01);
        result.set(0, 2, c02);
        result.set(1, 0, c10);
        result.set(1, 1, c11);
        result.set(1, 2, c12);
        result.set(2, 0, c20);
        result.set(2, 1, c21);
        result.set(2, 2, c22);
        return result;
      }
      mmulStrassen(y) {
        y = Matrix3.checkMatrix(y);
        let x = this.clone();
        let r1 = x.rows;
        let c1 = x.columns;
        let r2 = y.rows;
        let c2 = y.columns;
        if (c1 !== r2) {
          console.warn(
            `Multiplying ${r1} x ${c1} and ${r2} x ${c2} matrix: dimensions do not match.`
          );
        }
        function embed(mat, rows, cols) {
          let r3 = mat.rows;
          let c3 = mat.columns;
          if (r3 === rows && c3 === cols) {
            return mat;
          } else {
            let resultat = _AbstractMatrix.zeros(rows, cols);
            resultat = resultat.setSubMatrix(mat, 0, 0);
            return resultat;
          }
        }
        let r = Math.max(r1, r2);
        let c = Math.max(c1, c2);
        x = embed(x, r, c);
        y = embed(y, r, c);
        function blockMult(a, b, rows, cols) {
          if (rows <= 512 || cols <= 512) {
            return a.mmul(b);
          }
          if (rows % 2 === 1 && cols % 2 === 1) {
            a = embed(a, rows + 1, cols + 1);
            b = embed(b, rows + 1, cols + 1);
          } else if (rows % 2 === 1) {
            a = embed(a, rows + 1, cols);
            b = embed(b, rows + 1, cols);
          } else if (cols % 2 === 1) {
            a = embed(a, rows, cols + 1);
            b = embed(b, rows, cols + 1);
          }
          let halfRows = parseInt(a.rows / 2, 10);
          let halfCols = parseInt(a.columns / 2, 10);
          let a11 = a.subMatrix(0, halfRows - 1, 0, halfCols - 1);
          let b11 = b.subMatrix(0, halfRows - 1, 0, halfCols - 1);
          let a12 = a.subMatrix(0, halfRows - 1, halfCols, a.columns - 1);
          let b12 = b.subMatrix(0, halfRows - 1, halfCols, b.columns - 1);
          let a21 = a.subMatrix(halfRows, a.rows - 1, 0, halfCols - 1);
          let b21 = b.subMatrix(halfRows, b.rows - 1, 0, halfCols - 1);
          let a22 = a.subMatrix(halfRows, a.rows - 1, halfCols, a.columns - 1);
          let b22 = b.subMatrix(halfRows, b.rows - 1, halfCols, b.columns - 1);
          let m1 = blockMult(
            _AbstractMatrix.add(a11, a22),
            _AbstractMatrix.add(b11, b22),
            halfRows,
            halfCols
          );
          let m2 = blockMult(_AbstractMatrix.add(a21, a22), b11, halfRows, halfCols);
          let m3 = blockMult(a11, _AbstractMatrix.sub(b12, b22), halfRows, halfCols);
          let m4 = blockMult(a22, _AbstractMatrix.sub(b21, b11), halfRows, halfCols);
          let m5 = blockMult(_AbstractMatrix.add(a11, a12), b22, halfRows, halfCols);
          let m6 = blockMult(
            _AbstractMatrix.sub(a21, a11),
            _AbstractMatrix.add(b11, b12),
            halfRows,
            halfCols
          );
          let m7 = blockMult(
            _AbstractMatrix.sub(a12, a22),
            _AbstractMatrix.add(b21, b22),
            halfRows,
            halfCols
          );
          let c11 = _AbstractMatrix.add(m1, m4);
          c11.sub(m5);
          c11.add(m7);
          let c12 = _AbstractMatrix.add(m3, m5);
          let c21 = _AbstractMatrix.add(m2, m4);
          let c22 = _AbstractMatrix.sub(m1, m2);
          c22.add(m3);
          c22.add(m6);
          let result = _AbstractMatrix.zeros(2 * c11.rows, 2 * c11.columns);
          result = result.setSubMatrix(c11, 0, 0);
          result = result.setSubMatrix(c12, c11.rows, 0);
          result = result.setSubMatrix(c21, 0, c11.columns);
          result = result.setSubMatrix(c22, c11.rows, c11.columns);
          return result.subMatrix(0, rows - 1, 0, cols - 1);
        }
        return blockMult(x, y, r, c);
      }
      scaleRows(options = {}) {
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        const { min = 0, max = 1 } = options;
        if (!Number.isFinite(min)) throw new TypeError("min must be a number");
        if (!Number.isFinite(max)) throw new TypeError("max must be a number");
        if (min >= max) throw new RangeError("min must be smaller than max");
        let newMatrix = new Matrix3(this.rows, this.columns);
        for (let i = 0; i < this.rows; i++) {
          const row = this.getRow(i);
          if (row.length > 0) {
            rescale(row, { min, max, output: row });
          }
          newMatrix.setRow(i, row);
        }
        return newMatrix;
      }
      scaleColumns(options = {}) {
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        const { min = 0, max = 1 } = options;
        if (!Number.isFinite(min)) throw new TypeError("min must be a number");
        if (!Number.isFinite(max)) throw new TypeError("max must be a number");
        if (min >= max) throw new RangeError("min must be smaller than max");
        let newMatrix = new Matrix3(this.rows, this.columns);
        for (let i = 0; i < this.columns; i++) {
          const column = this.getColumn(i);
          if (column.length) {
            rescale(column, {
              min,
              max,
              output: column
            });
          }
          newMatrix.setColumn(i, column);
        }
        return newMatrix;
      }
      flipRows() {
        const middle = Math.ceil(this.columns / 2);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < middle; j++) {
            let first = this.get(i, j);
            let last = this.get(i, this.columns - 1 - j);
            this.set(i, j, last);
            this.set(i, this.columns - 1 - j, first);
          }
        }
        return this;
      }
      flipColumns() {
        const middle = Math.ceil(this.rows / 2);
        for (let j = 0; j < this.columns; j++) {
          for (let i = 0; i < middle; i++) {
            let first = this.get(i, j);
            let last = this.get(this.rows - 1 - i, j);
            this.set(i, j, last);
            this.set(this.rows - 1 - i, j, first);
          }
        }
        return this;
      }
      kroneckerProduct(other) {
        other = Matrix3.checkMatrix(other);
        let m = this.rows;
        let n = this.columns;
        let p = other.rows;
        let q = other.columns;
        let result = new Matrix3(m * p, n * q);
        for (let i = 0; i < m; i++) {
          for (let j = 0; j < n; j++) {
            for (let k = 0; k < p; k++) {
              for (let l = 0; l < q; l++) {
                result.set(p * i + k, q * j + l, this.get(i, j) * other.get(k, l));
              }
            }
          }
        }
        return result;
      }
      kroneckerSum(other) {
        other = Matrix3.checkMatrix(other);
        if (!this.isSquare() || !other.isSquare()) {
          throw new Error("Kronecker Sum needs two Square Matrices");
        }
        let m = this.rows;
        let n = other.rows;
        let AxI = this.kroneckerProduct(Matrix3.eye(n, n));
        let IxB = Matrix3.eye(m, m).kroneckerProduct(other);
        return AxI.add(IxB);
      }
      transpose() {
        let result = new Matrix3(this.columns, this.rows);
        for (let i = 0; i < this.rows; i++) {
          for (let j = 0; j < this.columns; j++) {
            result.set(j, i, this.get(i, j));
          }
        }
        return result;
      }
      sortRows(compareFunction = compareNumbers) {
        for (let i = 0; i < this.rows; i++) {
          this.setRow(i, this.getRow(i).sort(compareFunction));
        }
        return this;
      }
      sortColumns(compareFunction = compareNumbers) {
        for (let i = 0; i < this.columns; i++) {
          this.setColumn(i, this.getColumn(i).sort(compareFunction));
        }
        return this;
      }
      subMatrix(startRow, endRow, startColumn, endColumn) {
        checkRange(this, startRow, endRow, startColumn, endColumn);
        let newMatrix = new Matrix3(
          endRow - startRow + 1,
          endColumn - startColumn + 1
        );
        for (let i = startRow; i <= endRow; i++) {
          for (let j = startColumn; j <= endColumn; j++) {
            newMatrix.set(i - startRow, j - startColumn, this.get(i, j));
          }
        }
        return newMatrix;
      }
      subMatrixRow(indices, startColumn, endColumn) {
        if (startColumn === void 0) startColumn = 0;
        if (endColumn === void 0) endColumn = this.columns - 1;
        if (startColumn > endColumn || startColumn < 0 || startColumn >= this.columns || endColumn < 0 || endColumn >= this.columns) {
          throw new RangeError("Argument out of range");
        }
        let newMatrix = new Matrix3(indices.length, endColumn - startColumn + 1);
        for (let i = 0; i < indices.length; i++) {
          for (let j = startColumn; j <= endColumn; j++) {
            if (indices[i] < 0 || indices[i] >= this.rows) {
              throw new RangeError(`Row index out of range: ${indices[i]}`);
            }
            newMatrix.set(i, j - startColumn, this.get(indices[i], j));
          }
        }
        return newMatrix;
      }
      subMatrixColumn(indices, startRow, endRow) {
        if (startRow === void 0) startRow = 0;
        if (endRow === void 0) endRow = this.rows - 1;
        if (startRow > endRow || startRow < 0 || startRow >= this.rows || endRow < 0 || endRow >= this.rows) {
          throw new RangeError("Argument out of range");
        }
        let newMatrix = new Matrix3(endRow - startRow + 1, indices.length);
        for (let i = 0; i < indices.length; i++) {
          for (let j = startRow; j <= endRow; j++) {
            if (indices[i] < 0 || indices[i] >= this.columns) {
              throw new RangeError(`Column index out of range: ${indices[i]}`);
            }
            newMatrix.set(j - startRow, i, this.get(j, indices[i]));
          }
        }
        return newMatrix;
      }
      setSubMatrix(matrix2, startRow, startColumn) {
        matrix2 = Matrix3.checkMatrix(matrix2);
        if (matrix2.isEmpty()) {
          return this;
        }
        let endRow = startRow + matrix2.rows - 1;
        let endColumn = startColumn + matrix2.columns - 1;
        checkRange(this, startRow, endRow, startColumn, endColumn);
        for (let i = 0; i < matrix2.rows; i++) {
          for (let j = 0; j < matrix2.columns; j++) {
            this.set(startRow + i, startColumn + j, matrix2.get(i, j));
          }
        }
        return this;
      }
      selection(rowIndices, columnIndices) {
        checkRowIndices(this, rowIndices);
        checkColumnIndices(this, columnIndices);
        let newMatrix = new Matrix3(rowIndices.length, columnIndices.length);
        for (let i = 0; i < rowIndices.length; i++) {
          let rowIndex = rowIndices[i];
          for (let j = 0; j < columnIndices.length; j++) {
            let columnIndex = columnIndices[j];
            newMatrix.set(i, j, this.get(rowIndex, columnIndex));
          }
        }
        return newMatrix;
      }
      trace() {
        let min = Math.min(this.rows, this.columns);
        let trace = 0;
        for (let i = 0; i < min; i++) {
          trace += this.get(i, i);
        }
        return trace;
      }
      clone() {
        return this.constructor.copy(this, new Matrix3(this.rows, this.columns));
      }
      /**
       * @template {AbstractMatrix} M
       * @param {AbstractMatrix} from
       * @param {M} to
       * @return {M}
       */
      static copy(from, to) {
        for (const [row, column, value] of from.entries()) {
          to.set(row, column, value);
        }
        return to;
      }
      sum(by) {
        switch (by) {
          case "row":
            return sumByRow(this);
          case "column":
            return sumByColumn(this);
          case void 0:
            return sumAll(this);
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      product(by) {
        switch (by) {
          case "row":
            return productByRow(this);
          case "column":
            return productByColumn(this);
          case void 0:
            return productAll(this);
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      mean(by) {
        const sum = this.sum(by);
        switch (by) {
          case "row": {
            for (let i = 0; i < this.rows; i++) {
              sum[i] /= this.columns;
            }
            return sum;
          }
          case "column": {
            for (let i = 0; i < this.columns; i++) {
              sum[i] /= this.rows;
            }
            return sum;
          }
          case void 0:
            return sum / this.size;
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      variance(by, options = {}) {
        if (typeof by === "object") {
          options = by;
          by = void 0;
        }
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        const { unbiased = true, mean = this.mean(by) } = options;
        if (typeof unbiased !== "boolean") {
          throw new TypeError("unbiased must be a boolean");
        }
        switch (by) {
          case "row": {
            if (!isAnyArray.isAnyArray(mean)) {
              throw new TypeError("mean must be an array");
            }
            return varianceByRow(this, unbiased, mean);
          }
          case "column": {
            if (!isAnyArray.isAnyArray(mean)) {
              throw new TypeError("mean must be an array");
            }
            return varianceByColumn(this, unbiased, mean);
          }
          case void 0: {
            if (typeof mean !== "number") {
              throw new TypeError("mean must be a number");
            }
            return varianceAll(this, unbiased, mean);
          }
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      standardDeviation(by, options) {
        if (typeof by === "object") {
          options = by;
          by = void 0;
        }
        const variance = this.variance(by, options);
        if (by === void 0) {
          return Math.sqrt(variance);
        } else {
          for (let i = 0; i < variance.length; i++) {
            variance[i] = Math.sqrt(variance[i]);
          }
          return variance;
        }
      }
      center(by, options = {}) {
        if (typeof by === "object") {
          options = by;
          by = void 0;
        }
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        const { center = this.mean(by) } = options;
        switch (by) {
          case "row": {
            if (!isAnyArray.isAnyArray(center)) {
              throw new TypeError("center must be an array");
            }
            centerByRow(this, center);
            return this;
          }
          case "column": {
            if (!isAnyArray.isAnyArray(center)) {
              throw new TypeError("center must be an array");
            }
            centerByColumn(this, center);
            return this;
          }
          case void 0: {
            if (typeof center !== "number") {
              throw new TypeError("center must be a number");
            }
            centerAll(this, center);
            return this;
          }
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      scale(by, options = {}) {
        if (typeof by === "object") {
          options = by;
          by = void 0;
        }
        if (typeof options !== "object") {
          throw new TypeError("options must be an object");
        }
        let scale = options.scale;
        switch (by) {
          case "row": {
            if (scale === void 0) {
              scale = getScaleByRow(this);
            } else if (!isAnyArray.isAnyArray(scale)) {
              throw new TypeError("scale must be an array");
            }
            scaleByRow(this, scale);
            return this;
          }
          case "column": {
            if (scale === void 0) {
              scale = getScaleByColumn(this);
            } else if (!isAnyArray.isAnyArray(scale)) {
              throw new TypeError("scale must be an array");
            }
            scaleByColumn(this, scale);
            return this;
          }
          case void 0: {
            if (scale === void 0) {
              scale = getScaleAll(this);
            } else if (typeof scale !== "number") {
              throw new TypeError("scale must be a number");
            }
            scaleAll(this, scale);
            return this;
          }
          default:
            throw new Error(`invalid option: ${by}`);
        }
      }
      toString(options) {
        return inspectMatrixWithOptions(this, options);
      }
      [Symbol.iterator]() {
        return this.entries();
      }
      /**
       * iterator from left to right, from top to bottom
       * yield [row, column, value]
       * @returns {Generator<[number, number, number], void, void>}
       */
      *entries() {
        for (let row = 0; row < this.rows; row++) {
          for (let col = 0; col < this.columns; col++) {
            yield [row, col, this.get(row, col)];
          }
        }
      }
      /**
       * iterator from left to right, from top to bottom
       * yield value
       * @returns {Generator<number, void, void>}
       */
      *values() {
        for (let row = 0; row < this.rows; row++) {
          for (let col = 0; col < this.columns; col++) {
            yield this.get(row, col);
          }
        }
      }
    };
    AbstractMatrix2.prototype.klass = "Matrix";
    if (typeof Symbol !== "undefined") {
      AbstractMatrix2.prototype[Symbol.for("nodejs.util.inspect.custom")] = inspectMatrix;
    }
    function compareNumbers(a, b) {
      return a - b;
    }
    function isArrayOfNumbers(array) {
      return array.every((element) => {
        return typeof element === "number";
      });
    }
    AbstractMatrix2.random = AbstractMatrix2.rand;
    AbstractMatrix2.randomInt = AbstractMatrix2.randInt;
    AbstractMatrix2.diagonal = AbstractMatrix2.diag;
    AbstractMatrix2.prototype.diagonal = AbstractMatrix2.prototype.diag;
    AbstractMatrix2.identity = AbstractMatrix2.eye;
    AbstractMatrix2.prototype.negate = AbstractMatrix2.prototype.neg;
    AbstractMatrix2.prototype.tensorProduct = AbstractMatrix2.prototype.kroneckerProduct;
    var Matrix3 = class _Matrix extends AbstractMatrix2 {
      /**
       * @type {Float64Array[]}
       */
      data;
      /**
       * Init an empty matrix
       * @param {number} nRows
       * @param {number} nColumns
       */
      #initData(nRows, nColumns) {
        this.data = [];
        if (Number.isInteger(nColumns) && nColumns >= 0) {
          for (let i = 0; i < nRows; i++) {
            this.data.push(new Float64Array(nColumns));
          }
        } else {
          throw new TypeError("nColumns must be a positive integer");
        }
        this.rows = nRows;
        this.columns = nColumns;
      }
      constructor(nRows, nColumns) {
        super();
        if (_Matrix.isMatrix(nRows)) {
          this.#initData(nRows.rows, nRows.columns);
          _Matrix.copy(nRows, this);
        } else if (Number.isInteger(nRows) && nRows >= 0) {
          this.#initData(nRows, nColumns);
        } else if (isAnyArray.isAnyArray(nRows)) {
          const arrayData = nRows;
          nRows = arrayData.length;
          nColumns = nRows ? arrayData[0].length : 0;
          if (typeof nColumns !== "number") {
            throw new TypeError(
              "Data must be a 2D array with at least one element"
            );
          }
          this.data = [];
          for (let i = 0; i < nRows; i++) {
            if (arrayData[i].length !== nColumns) {
              throw new RangeError("Inconsistent array dimensions");
            }
            if (!isArrayOfNumbers(arrayData[i])) {
              throw new TypeError("Input data contains non-numeric values");
            }
            this.data.push(Float64Array.from(arrayData[i]));
          }
          this.rows = nRows;
          this.columns = nColumns;
        } else {
          throw new TypeError(
            "First argument must be a positive number or an array"
          );
        }
      }
      set(rowIndex, columnIndex, value) {
        this.data[rowIndex][columnIndex] = value;
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.data[rowIndex][columnIndex];
      }
      removeRow(index) {
        checkRowIndex(this, index);
        this.data.splice(index, 1);
        this.rows -= 1;
        return this;
      }
      addRow(index, array) {
        if (array === void 0) {
          array = index;
          index = this.rows;
        }
        checkRowIndex(this, index, true);
        array = Float64Array.from(checkRowVector(this, array));
        this.data.splice(index, 0, array);
        this.rows += 1;
        return this;
      }
      removeColumn(index) {
        checkColumnIndex(this, index);
        for (let i = 0; i < this.rows; i++) {
          const newRow = new Float64Array(this.columns - 1);
          for (let j = 0; j < index; j++) {
            newRow[j] = this.data[i][j];
          }
          for (let j = index + 1; j < this.columns; j++) {
            newRow[j - 1] = this.data[i][j];
          }
          this.data[i] = newRow;
        }
        this.columns -= 1;
        return this;
      }
      addColumn(index, array) {
        if (typeof array === "undefined") {
          array = index;
          index = this.columns;
        }
        checkColumnIndex(this, index, true);
        array = checkColumnVector(this, array);
        for (let i = 0; i < this.rows; i++) {
          const newRow = new Float64Array(this.columns + 1);
          let j = 0;
          for (; j < index; j++) {
            newRow[j] = this.data[i][j];
          }
          newRow[j++] = array[i];
          for (; j < this.columns + 1; j++) {
            newRow[j] = this.data[i][j - 1];
          }
          this.data[i] = newRow;
        }
        this.columns += 1;
        return this;
      }
    };
    installMathOperations(AbstractMatrix2, Matrix3);
    var SymmetricMatrix2 = class _SymmetricMatrix extends AbstractMatrix2 {
      /** @type {Matrix} */
      #matrix;
      get size() {
        return this.#matrix.size;
      }
      get rows() {
        return this.#matrix.rows;
      }
      get columns() {
        return this.#matrix.columns;
      }
      get diagonalSize() {
        return this.rows;
      }
      /**
       * not the same as matrix.isSymmetric()
       * Here is to check if it's instanceof SymmetricMatrix without bundling issues
       *
       * @param value
       * @returns {boolean}
       */
      static isSymmetricMatrix(value) {
        return Matrix3.isMatrix(value) && value.klassType === "SymmetricMatrix";
      }
      /**
       * @param diagonalSize
       * @return {SymmetricMatrix}
       */
      static zeros(diagonalSize) {
        return new this(diagonalSize);
      }
      /**
       * @param diagonalSize
       * @return {SymmetricMatrix}
       */
      static ones(diagonalSize) {
        return new this(diagonalSize).fill(1);
      }
      /**
       * @param {number | AbstractMatrix | ArrayLike<ArrayLike<number>>} diagonalSize
       * @return {this}
       */
      constructor(diagonalSize) {
        super();
        if (Matrix3.isMatrix(diagonalSize)) {
          if (!diagonalSize.isSymmetric()) {
            throw new TypeError("not symmetric data");
          }
          this.#matrix = Matrix3.copy(
            diagonalSize,
            new Matrix3(diagonalSize.rows, diagonalSize.rows)
          );
        } else if (Number.isInteger(diagonalSize) && diagonalSize >= 0) {
          this.#matrix = new Matrix3(diagonalSize, diagonalSize);
        } else {
          this.#matrix = new Matrix3(diagonalSize);
          if (!this.isSymmetric()) {
            throw new TypeError("not symmetric data");
          }
        }
      }
      clone() {
        const matrix2 = new _SymmetricMatrix(this.diagonalSize);
        for (const [row, col, value] of this.upperRightEntries()) {
          matrix2.set(row, col, value);
        }
        return matrix2;
      }
      toMatrix() {
        return new Matrix3(this);
      }
      get(rowIndex, columnIndex) {
        return this.#matrix.get(rowIndex, columnIndex);
      }
      set(rowIndex, columnIndex, value) {
        this.#matrix.set(rowIndex, columnIndex, value);
        this.#matrix.set(columnIndex, rowIndex, value);
        return this;
      }
      removeCross(index) {
        this.#matrix.removeRow(index);
        this.#matrix.removeColumn(index);
        return this;
      }
      addCross(index, array) {
        if (array === void 0) {
          array = index;
          index = this.diagonalSize;
        }
        const row = array.slice();
        row.splice(index, 1);
        this.#matrix.addRow(index, row);
        this.#matrix.addColumn(index, array);
        return this;
      }
      /**
       * @param {Mask[]} mask
       */
      applyMask(mask) {
        if (mask.length !== this.diagonalSize) {
          throw new RangeError("Mask size do not match with matrix size");
        }
        const sidesToRemove = [];
        for (const [index, passthroughs] of mask.entries()) {
          if (passthroughs) continue;
          sidesToRemove.push(index);
        }
        sidesToRemove.reverse();
        for (const sideIndex of sidesToRemove) {
          this.removeCross(sideIndex);
        }
        return this;
      }
      /**
       * Compact format upper-right corner of matrix
       * iterate from left to right, from top to bottom.
       *
       * ```
       *   A B C D
       * A 1 2 3 4
       * B 2 5 6 7
       * C 3 6 8 9
       * D 4 7 9 10
       * ```
       *
       * will return compact 1D array `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]`
       *
       * length is S(i=0, n=sideSize) => 10 for a 4 sideSized matrix
       *
       * @returns {number[]}
       */
      toCompact() {
        const { diagonalSize } = this;
        const compact = new Array(diagonalSize * (diagonalSize + 1) / 2);
        for (let col = 0, row = 0, index = 0; index < compact.length; index++) {
          compact[index] = this.get(row, col);
          if (++col >= diagonalSize) col = ++row;
        }
        return compact;
      }
      /**
       * @param {number[]} compact
       * @return {SymmetricMatrix}
       */
      static fromCompact(compact) {
        const compactSize = compact.length;
        const diagonalSize = (Math.sqrt(8 * compactSize + 1) - 1) / 2;
        if (!Number.isInteger(diagonalSize)) {
          throw new TypeError(
            `This array is not a compact representation of a Symmetric Matrix, ${JSON.stringify(
              compact
            )}`
          );
        }
        const matrix2 = new _SymmetricMatrix(diagonalSize);
        for (let col = 0, row = 0, index = 0; index < compactSize; index++) {
          matrix2.set(col, row, compact[index]);
          if (++col >= diagonalSize) col = ++row;
        }
        return matrix2;
      }
      /**
       * half iterator upper-right-corner from left to right, from top to bottom
       * yield [row, column, value]
       *
       * @returns {Generator<[number, number, number], void, void>}
       */
      *upperRightEntries() {
        for (let row = 0, col = 0; row < this.diagonalSize; void 0) {
          const value = this.get(row, col);
          yield [row, col, value];
          if (++col >= this.diagonalSize) col = ++row;
        }
      }
      /**
       * half iterator upper-right-corner from left to right, from top to bottom
       * yield value
       *
       * @returns {Generator<[number, number, number], void, void>}
       */
      *upperRightValues() {
        for (let row = 0, col = 0; row < this.diagonalSize; void 0) {
          const value = this.get(row, col);
          yield value;
          if (++col >= this.diagonalSize) col = ++row;
        }
      }
    };
    SymmetricMatrix2.prototype.klassType = "SymmetricMatrix";
    var DistanceMatrix2 = class _DistanceMatrix extends SymmetricMatrix2 {
      /**
       * not the same as matrix.isSymmetric()
       * Here is to check if it's instanceof SymmetricMatrix without bundling issues
       *
       * @param value
       * @returns {boolean}
       */
      static isDistanceMatrix(value) {
        return SymmetricMatrix2.isSymmetricMatrix(value) && value.klassSubType === "DistanceMatrix";
      }
      constructor(sideSize) {
        super(sideSize);
        if (!this.isDistance()) {
          throw new TypeError("Provided arguments do no produce a distance matrix");
        }
      }
      set(rowIndex, columnIndex, value) {
        if (rowIndex === columnIndex) value = 0;
        return super.set(rowIndex, columnIndex, value);
      }
      addCross(index, array) {
        if (array === void 0) {
          array = index;
          index = this.diagonalSize;
        }
        array = array.slice();
        array[index] = 0;
        return super.addCross(index, array);
      }
      toSymmetricMatrix() {
        return new SymmetricMatrix2(this);
      }
      clone() {
        const matrix2 = new _DistanceMatrix(this.diagonalSize);
        for (const [row, col, value] of this.upperRightEntries()) {
          if (row === col) continue;
          matrix2.set(row, col, value);
        }
        return matrix2;
      }
      /**
       * Compact format upper-right corner of matrix
       * no diagonal (only zeros)
       * iterable from left to right, from top to bottom.
       *
       * ```
       *   A B C D
       * A 0 1 2 3
       * B 1 0 4 5
       * C 2 4 0 6
       * D 3 5 6 0
       * ```
       *
       * will return compact 1D array `[1, 2, 3, 4, 5, 6]`
       *
       * length is S(i=0, n=sideSize-1) => 6 for a 4 side sized matrix
       *
       * @returns {number[]}
       */
      toCompact() {
        const { diagonalSize } = this;
        const compactLength = (diagonalSize - 1) * diagonalSize / 2;
        const compact = new Array(compactLength);
        for (let col = 1, row = 0, index = 0; index < compact.length; index++) {
          compact[index] = this.get(row, col);
          if (++col >= diagonalSize) col = ++row + 1;
        }
        return compact;
      }
      /**
       * @param {number[]} compact
       */
      static fromCompact(compact) {
        const compactSize = compact.length;
        if (compactSize === 0) {
          return new this(0);
        }
        const diagonalSize = (Math.sqrt(8 * compactSize + 1) + 1) / 2;
        if (!Number.isInteger(diagonalSize)) {
          throw new TypeError(
            `This array is not a compact representation of a DistanceMatrix, ${JSON.stringify(
              compact
            )}`
          );
        }
        const matrix2 = new this(diagonalSize);
        for (let col = 1, row = 0, index = 0; index < compactSize; index++) {
          matrix2.set(col, row, compact[index]);
          if (++col >= diagonalSize) col = ++row + 1;
        }
        return matrix2;
      }
    };
    DistanceMatrix2.prototype.klassSubType = "DistanceMatrix";
    var BaseView = class extends AbstractMatrix2 {
      constructor(matrix2, rows, columns) {
        super();
        this.matrix = matrix2;
        this.rows = rows;
        this.columns = columns;
      }
    };
    var MatrixColumnView2 = class extends BaseView {
      constructor(matrix2, column) {
        checkColumnIndex(matrix2, column);
        super(matrix2, matrix2.rows, 1);
        this.column = column;
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(rowIndex, this.column, value);
        return this;
      }
      get(rowIndex) {
        return this.matrix.get(rowIndex, this.column);
      }
    };
    var MatrixColumnSelectionView2 = class extends BaseView {
      constructor(matrix2, columnIndices) {
        checkColumnIndices(matrix2, columnIndices);
        super(matrix2, matrix2.rows, columnIndices.length);
        this.columnIndices = columnIndices;
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(rowIndex, this.columnIndices[columnIndex], value);
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(rowIndex, this.columnIndices[columnIndex]);
      }
    };
    var MatrixFlipColumnView2 = class extends BaseView {
      constructor(matrix2) {
        super(matrix2, matrix2.rows, matrix2.columns);
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(rowIndex, this.columns - columnIndex - 1, value);
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(rowIndex, this.columns - columnIndex - 1);
      }
    };
    var MatrixFlipRowView2 = class extends BaseView {
      constructor(matrix2) {
        super(matrix2, matrix2.rows, matrix2.columns);
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(this.rows - rowIndex - 1, columnIndex, value);
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(this.rows - rowIndex - 1, columnIndex);
      }
    };
    var MatrixRowView2 = class extends BaseView {
      constructor(matrix2, row) {
        checkRowIndex(matrix2, row);
        super(matrix2, 1, matrix2.columns);
        this.row = row;
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(this.row, columnIndex, value);
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(this.row, columnIndex);
      }
    };
    var MatrixRowSelectionView2 = class extends BaseView {
      constructor(matrix2, rowIndices) {
        checkRowIndices(matrix2, rowIndices);
        super(matrix2, rowIndices.length, matrix2.columns);
        this.rowIndices = rowIndices;
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(this.rowIndices[rowIndex], columnIndex, value);
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(this.rowIndices[rowIndex], columnIndex);
      }
    };
    var MatrixSelectionView2 = class extends BaseView {
      constructor(matrix2, rowIndices, columnIndices) {
        checkRowIndices(matrix2, rowIndices);
        checkColumnIndices(matrix2, columnIndices);
        super(matrix2, rowIndices.length, columnIndices.length);
        this.rowIndices = rowIndices;
        this.columnIndices = columnIndices;
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(
          this.rowIndices[rowIndex],
          this.columnIndices[columnIndex],
          value
        );
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(
          this.rowIndices[rowIndex],
          this.columnIndices[columnIndex]
        );
      }
    };
    var MatrixSubView2 = class extends BaseView {
      constructor(matrix2, startRow, endRow, startColumn, endColumn) {
        checkRange(matrix2, startRow, endRow, startColumn, endColumn);
        super(matrix2, endRow - startRow + 1, endColumn - startColumn + 1);
        this.startRow = startRow;
        this.startColumn = startColumn;
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(
          this.startRow + rowIndex,
          this.startColumn + columnIndex,
          value
        );
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(
          this.startRow + rowIndex,
          this.startColumn + columnIndex
        );
      }
    };
    var MatrixTransposeView2 = class extends BaseView {
      constructor(matrix2) {
        super(matrix2, matrix2.columns, matrix2.rows);
      }
      set(rowIndex, columnIndex, value) {
        this.matrix.set(columnIndex, rowIndex, value);
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.matrix.get(columnIndex, rowIndex);
      }
    };
    var WrapperMatrix1D2 = class extends AbstractMatrix2 {
      constructor(data, options = {}) {
        const { rows = 1 } = options;
        if (data.length % rows !== 0) {
          throw new Error("the data length is not divisible by the number of rows");
        }
        super();
        this.rows = rows;
        this.columns = data.length / rows;
        this.data = data;
      }
      set(rowIndex, columnIndex, value) {
        let index = this._calculateIndex(rowIndex, columnIndex);
        this.data[index] = value;
        return this;
      }
      get(rowIndex, columnIndex) {
        let index = this._calculateIndex(rowIndex, columnIndex);
        return this.data[index];
      }
      _calculateIndex(row, column) {
        return row * this.columns + column;
      }
    };
    var WrapperMatrix2D3 = class extends AbstractMatrix2 {
      constructor(data) {
        super();
        this.data = data;
        this.rows = data.length;
        this.columns = data[0].length;
      }
      set(rowIndex, columnIndex, value) {
        this.data[rowIndex][columnIndex] = value;
        return this;
      }
      get(rowIndex, columnIndex) {
        return this.data[rowIndex][columnIndex];
      }
    };
    function wrap2(array, options) {
      if (isAnyArray.isAnyArray(array)) {
        if (array[0] && isAnyArray.isAnyArray(array[0])) {
          return new WrapperMatrix2D3(array);
        } else {
          return new WrapperMatrix1D2(array, options);
        }
      } else {
        throw new Error("the argument is not an array");
      }
    }
    var LuDecomposition2 = class {
      constructor(matrix2) {
        matrix2 = WrapperMatrix2D3.checkMatrix(matrix2);
        let lu = matrix2.clone();
        let rows = lu.rows;
        let columns = lu.columns;
        let pivotVector = new Float64Array(rows);
        let pivotSign = 1;
        let i, j, k, p, s, t, v;
        let LUcolj, kmax;
        for (i = 0; i < rows; i++) {
          pivotVector[i] = i;
        }
        LUcolj = new Float64Array(rows);
        for (j = 0; j < columns; j++) {
          for (i = 0; i < rows; i++) {
            LUcolj[i] = lu.get(i, j);
          }
          for (i = 0; i < rows; i++) {
            kmax = Math.min(i, j);
            s = 0;
            for (k = 0; k < kmax; k++) {
              s += lu.get(i, k) * LUcolj[k];
            }
            LUcolj[i] -= s;
            lu.set(i, j, LUcolj[i]);
          }
          p = j;
          for (i = j + 1; i < rows; i++) {
            if (Math.abs(LUcolj[i]) > Math.abs(LUcolj[p])) {
              p = i;
            }
          }
          if (p !== j) {
            for (k = 0; k < columns; k++) {
              t = lu.get(p, k);
              lu.set(p, k, lu.get(j, k));
              lu.set(j, k, t);
            }
            v = pivotVector[p];
            pivotVector[p] = pivotVector[j];
            pivotVector[j] = v;
            pivotSign = -pivotSign;
          }
          if (j < rows && lu.get(j, j) !== 0) {
            for (i = j + 1; i < rows; i++) {
              lu.set(i, j, lu.get(i, j) / lu.get(j, j));
            }
          }
        }
        this.LU = lu;
        this.pivotVector = pivotVector;
        this.pivotSign = pivotSign;
      }
      isSingular() {
        let data = this.LU;
        let col = data.columns;
        for (let j = 0; j < col; j++) {
          if (data.get(j, j) === 0) {
            return true;
          }
        }
        return false;
      }
      solve(value) {
        value = Matrix3.checkMatrix(value);
        let lu = this.LU;
        let rows = lu.rows;
        if (rows !== value.rows) {
          throw new Error("Invalid matrix dimensions");
        }
        if (this.isSingular()) {
          throw new Error("LU matrix is singular");
        }
        let count = value.columns;
        let X = value.subMatrixRow(this.pivotVector, 0, count - 1);
        let columns = lu.columns;
        let i, j, k;
        for (k = 0; k < columns; k++) {
          for (i = k + 1; i < columns; i++) {
            for (j = 0; j < count; j++) {
              X.set(i, j, X.get(i, j) - X.get(k, j) * lu.get(i, k));
            }
          }
        }
        for (k = columns - 1; k >= 0; k--) {
          for (j = 0; j < count; j++) {
            X.set(k, j, X.get(k, j) / lu.get(k, k));
          }
          for (i = 0; i < k; i++) {
            for (j = 0; j < count; j++) {
              X.set(i, j, X.get(i, j) - X.get(k, j) * lu.get(i, k));
            }
          }
        }
        return X;
      }
      get determinant() {
        let data = this.LU;
        if (!data.isSquare()) {
          throw new Error("Matrix must be square");
        }
        let determinant3 = this.pivotSign;
        let col = data.columns;
        for (let j = 0; j < col; j++) {
          determinant3 *= data.get(j, j);
        }
        return determinant3;
      }
      get lowerTriangularMatrix() {
        let data = this.LU;
        let rows = data.rows;
        let columns = data.columns;
        let X = new Matrix3(rows, columns);
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            if (i > j) {
              X.set(i, j, data.get(i, j));
            } else if (i === j) {
              X.set(i, j, 1);
            } else {
              X.set(i, j, 0);
            }
          }
        }
        return X;
      }
      get upperTriangularMatrix() {
        let data = this.LU;
        let rows = data.rows;
        let columns = data.columns;
        let X = new Matrix3(rows, columns);
        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < columns; j++) {
            if (i <= j) {
              X.set(i, j, data.get(i, j));
            } else {
              X.set(i, j, 0);
            }
          }
        }
        return X;
      }
      get pivotPermutationVector() {
        return Array.from(this.pivotVector);
      }
    };
    function hypotenuse(a, b) {
      let r = 0;
      if (Math.abs(a) > Math.abs(b)) {
        r = b / a;
        return Math.abs(a) * Math.sqrt(1 + r * r);
      }
      if (b !== 0) {
        r = a / b;
        return Math.abs(b) * Math.sqrt(1 + r * r);
      }
      return 0;
    }
    var QrDecomposition3 = class {
      constructor(value) {
        value = WrapperMatrix2D3.checkMatrix(value);
        let qr = value.clone();
        let m = value.rows;
        let n = value.columns;
        let rdiag = new Float64Array(n);
        let i, j, k, s;
        for (k = 0; k < n; k++) {
          let nrm = 0;
          for (i = k; i < m; i++) {
            nrm = hypotenuse(nrm, qr.get(i, k));
          }
          if (nrm !== 0) {
            if (qr.get(k, k) < 0) {
              nrm = -nrm;
            }
            for (i = k; i < m; i++) {
              qr.set(i, k, qr.get(i, k) / nrm);
            }
            qr.set(k, k, qr.get(k, k) + 1);
            for (j = k + 1; j < n; j++) {
              s = 0;
              for (i = k; i < m; i++) {
                s += qr.get(i, k) * qr.get(i, j);
              }
              s = -s / qr.get(k, k);
              for (i = k; i < m; i++) {
                qr.set(i, j, qr.get(i, j) + s * qr.get(i, k));
              }
            }
          }
          rdiag[k] = -nrm;
        }
        this.QR = qr;
        this.Rdiag = rdiag;
      }
      solve(value) {
        value = Matrix3.checkMatrix(value);
        let qr = this.QR;
        let m = qr.rows;
        if (value.rows !== m) {
          throw new Error("Matrix row dimensions must agree");
        }
        if (!this.isFullRank()) {
          throw new Error("Matrix is rank deficient");
        }
        let count = value.columns;
        let X = value.clone();
        let n = qr.columns;
        let i, j, k, s;
        for (k = 0; k < n; k++) {
          for (j = 0; j < count; j++) {
            s = 0;
            for (i = k; i < m; i++) {
              s += qr.get(i, k) * X.get(i, j);
            }
            s = -s / qr.get(k, k);
            for (i = k; i < m; i++) {
              X.set(i, j, X.get(i, j) + s * qr.get(i, k));
            }
          }
        }
        for (k = n - 1; k >= 0; k--) {
          for (j = 0; j < count; j++) {
            X.set(k, j, X.get(k, j) / this.Rdiag[k]);
          }
          for (i = 0; i < k; i++) {
            for (j = 0; j < count; j++) {
              X.set(i, j, X.get(i, j) - X.get(k, j) * qr.get(i, k));
            }
          }
        }
        return X.subMatrix(0, n - 1, 0, count - 1);
      }
      isFullRank() {
        let columns = this.QR.columns;
        for (let i = 0; i < columns; i++) {
          if (this.Rdiag[i] === 0) {
            return false;
          }
        }
        return true;
      }
      get upperTriangularMatrix() {
        let qr = this.QR;
        let n = qr.columns;
        let X = new Matrix3(n, n);
        let i, j;
        for (i = 0; i < n; i++) {
          for (j = 0; j < n; j++) {
            if (i < j) {
              X.set(i, j, qr.get(i, j));
            } else if (i === j) {
              X.set(i, j, this.Rdiag[i]);
            } else {
              X.set(i, j, 0);
            }
          }
        }
        return X;
      }
      get orthogonalMatrix() {
        let qr = this.QR;
        let rows = qr.rows;
        let columns = qr.columns;
        let X = new Matrix3(rows, columns);
        let i, j, k, s;
        for (k = columns - 1; k >= 0; k--) {
          for (i = 0; i < rows; i++) {
            X.set(i, k, 0);
          }
          X.set(k, k, 1);
          for (j = k; j < columns; j++) {
            if (qr.get(k, k) !== 0) {
              s = 0;
              for (i = k; i < rows; i++) {
                s += qr.get(i, k) * X.get(i, j);
              }
              s = -s / qr.get(k, k);
              for (i = k; i < rows; i++) {
                X.set(i, j, X.get(i, j) + s * qr.get(i, k));
              }
            }
          }
        }
        return X;
      }
    };
    var SingularValueDecomposition3 = class {
      constructor(value, options = {}) {
        value = WrapperMatrix2D3.checkMatrix(value);
        if (value.isEmpty()) {
          throw new Error("Matrix must be non-empty");
        }
        let m = value.rows;
        let n = value.columns;
        const {
          computeLeftSingularVectors = true,
          computeRightSingularVectors = true,
          autoTranspose = false
        } = options;
        let wantu = Boolean(computeLeftSingularVectors);
        let wantv = Boolean(computeRightSingularVectors);
        let swapped = false;
        let a;
        if (m < n) {
          if (!autoTranspose) {
            a = value.clone();
            console.warn(
              "Computing SVD on a matrix with more columns than rows. Consider enabling autoTranspose"
            );
          } else {
            a = value.transpose();
            m = a.rows;
            n = a.columns;
            swapped = true;
            let aux = wantu;
            wantu = wantv;
            wantv = aux;
          }
        } else {
          a = value.clone();
        }
        let nu = Math.min(m, n);
        let ni = Math.min(m + 1, n);
        let s = new Float64Array(ni);
        let U = new Matrix3(m, nu);
        let V = new Matrix3(n, n);
        let e = new Float64Array(n);
        let work = new Float64Array(m);
        let si = new Float64Array(ni);
        for (let i = 0; i < ni; i++) si[i] = i;
        let nct = Math.min(m - 1, n);
        let nrt = Math.max(0, Math.min(n - 2, m));
        let mrc = Math.max(nct, nrt);
        for (let k = 0; k < mrc; k++) {
          if (k < nct) {
            s[k] = 0;
            for (let i = k; i < m; i++) {
              s[k] = hypotenuse(s[k], a.get(i, k));
            }
            if (s[k] !== 0) {
              if (a.get(k, k) < 0) {
                s[k] = -s[k];
              }
              for (let i = k; i < m; i++) {
                a.set(i, k, a.get(i, k) / s[k]);
              }
              a.set(k, k, a.get(k, k) + 1);
            }
            s[k] = -s[k];
          }
          for (let j = k + 1; j < n; j++) {
            if (k < nct && s[k] !== 0) {
              let t = 0;
              for (let i = k; i < m; i++) {
                t += a.get(i, k) * a.get(i, j);
              }
              t = -t / a.get(k, k);
              for (let i = k; i < m; i++) {
                a.set(i, j, a.get(i, j) + t * a.get(i, k));
              }
            }
            e[j] = a.get(k, j);
          }
          if (wantu && k < nct) {
            for (let i = k; i < m; i++) {
              U.set(i, k, a.get(i, k));
            }
          }
          if (k < nrt) {
            e[k] = 0;
            for (let i = k + 1; i < n; i++) {
              e[k] = hypotenuse(e[k], e[i]);
            }
            if (e[k] !== 0) {
              if (e[k + 1] < 0) {
                e[k] = 0 - e[k];
              }
              for (let i = k + 1; i < n; i++) {
                e[i] /= e[k];
              }
              e[k + 1] += 1;
            }
            e[k] = -e[k];
            if (k + 1 < m && e[k] !== 0) {
              for (let i = k + 1; i < m; i++) {
                work[i] = 0;
              }
              for (let i = k + 1; i < m; i++) {
                for (let j = k + 1; j < n; j++) {
                  work[i] += e[j] * a.get(i, j);
                }
              }
              for (let j = k + 1; j < n; j++) {
                let t = -e[j] / e[k + 1];
                for (let i = k + 1; i < m; i++) {
                  a.set(i, j, a.get(i, j) + t * work[i]);
                }
              }
            }
            if (wantv) {
              for (let i = k + 1; i < n; i++) {
                V.set(i, k, e[i]);
              }
            }
          }
        }
        let p = Math.min(n, m + 1);
        if (nct < n) {
          s[nct] = a.get(nct, nct);
        }
        if (m < p) {
          s[p - 1] = 0;
        }
        if (nrt + 1 < p) {
          e[nrt] = a.get(nrt, p - 1);
        }
        e[p - 1] = 0;
        if (wantu) {
          for (let j = nct; j < nu; j++) {
            for (let i = 0; i < m; i++) {
              U.set(i, j, 0);
            }
            U.set(j, j, 1);
          }
          for (let k = nct - 1; k >= 0; k--) {
            if (s[k] !== 0) {
              for (let j = k + 1; j < nu; j++) {
                let t = 0;
                for (let i = k; i < m; i++) {
                  t += U.get(i, k) * U.get(i, j);
                }
                t = -t / U.get(k, k);
                for (let i = k; i < m; i++) {
                  U.set(i, j, U.get(i, j) + t * U.get(i, k));
                }
              }
              for (let i = k; i < m; i++) {
                U.set(i, k, -U.get(i, k));
              }
              U.set(k, k, 1 + U.get(k, k));
              for (let i = 0; i < k - 1; i++) {
                U.set(i, k, 0);
              }
            } else {
              for (let i = 0; i < m; i++) {
                U.set(i, k, 0);
              }
              U.set(k, k, 1);
            }
          }
        }
        if (wantv) {
          for (let k = n - 1; k >= 0; k--) {
            if (k < nrt && e[k] !== 0) {
              for (let j = k + 1; j < n; j++) {
                let t = 0;
                for (let i = k + 1; i < n; i++) {
                  t += V.get(i, k) * V.get(i, j);
                }
                t = -t / V.get(k + 1, k);
                for (let i = k + 1; i < n; i++) {
                  V.set(i, j, V.get(i, j) + t * V.get(i, k));
                }
              }
            }
            for (let i = 0; i < n; i++) {
              V.set(i, k, 0);
            }
            V.set(k, k, 1);
          }
        }
        let pp = p - 1;
        let eps = Number.EPSILON;
        while (p > 0) {
          let k, kase;
          for (k = p - 2; k >= -1; k--) {
            if (k === -1) {
              break;
            }
            const alpha = Number.MIN_VALUE + eps * Math.abs(s[k] + Math.abs(s[k + 1]));
            if (Math.abs(e[k]) <= alpha || Number.isNaN(e[k])) {
              e[k] = 0;
              break;
            }
          }
          if (k === p - 2) {
            kase = 4;
          } else {
            let ks;
            for (ks = p - 1; ks >= k; ks--) {
              if (ks === k) {
                break;
              }
              let t = (ks !== p ? Math.abs(e[ks]) : 0) + (ks !== k + 1 ? Math.abs(e[ks - 1]) : 0);
              if (Math.abs(s[ks]) <= eps * t) {
                s[ks] = 0;
                break;
              }
            }
            if (ks === k) {
              kase = 3;
            } else if (ks === p - 1) {
              kase = 1;
            } else {
              kase = 2;
              k = ks;
            }
          }
          k++;
          switch (kase) {
            case 1: {
              let f = e[p - 2];
              e[p - 2] = 0;
              for (let j = p - 2; j >= k; j--) {
                let t = hypotenuse(s[j], f);
                let cs = s[j] / t;
                let sn = f / t;
                s[j] = t;
                if (j !== k) {
                  f = -sn * e[j - 1];
                  e[j - 1] = cs * e[j - 1];
                }
                if (wantv) {
                  for (let i = 0; i < n; i++) {
                    t = cs * V.get(i, j) + sn * V.get(i, p - 1);
                    V.set(i, p - 1, -sn * V.get(i, j) + cs * V.get(i, p - 1));
                    V.set(i, j, t);
                  }
                }
              }
              break;
            }
            case 2: {
              let f = e[k - 1];
              e[k - 1] = 0;
              for (let j = k; j < p; j++) {
                let t = hypotenuse(s[j], f);
                let cs = s[j] / t;
                let sn = f / t;
                s[j] = t;
                f = -sn * e[j];
                e[j] = cs * e[j];
                if (wantu) {
                  for (let i = 0; i < m; i++) {
                    t = cs * U.get(i, j) + sn * U.get(i, k - 1);
                    U.set(i, k - 1, -sn * U.get(i, j) + cs * U.get(i, k - 1));
                    U.set(i, j, t);
                  }
                }
              }
              break;
            }
            case 3: {
              const scale = Math.max(
                Math.abs(s[p - 1]),
                Math.abs(s[p - 2]),
                Math.abs(e[p - 2]),
                Math.abs(s[k]),
                Math.abs(e[k])
              );
              const sp = s[p - 1] / scale;
              const spm1 = s[p - 2] / scale;
              const epm1 = e[p - 2] / scale;
              const sk = s[k] / scale;
              const ek = e[k] / scale;
              const b = ((spm1 + sp) * (spm1 - sp) + epm1 * epm1) / 2;
              const c = sp * epm1 * (sp * epm1);
              let shift = 0;
              if (b !== 0 || c !== 0) {
                if (b < 0) {
                  shift = 0 - Math.sqrt(b * b + c);
                } else {
                  shift = Math.sqrt(b * b + c);
                }
                shift = c / (b + shift);
              }
              let f = (sk + sp) * (sk - sp) + shift;
              let g = sk * ek;
              for (let j = k; j < p - 1; j++) {
                let t = hypotenuse(f, g);
                if (t === 0) t = Number.MIN_VALUE;
                let cs = f / t;
                let sn = g / t;
                if (j !== k) {
                  e[j - 1] = t;
                }
                f = cs * s[j] + sn * e[j];
                e[j] = cs * e[j] - sn * s[j];
                g = sn * s[j + 1];
                s[j + 1] = cs * s[j + 1];
                if (wantv) {
                  for (let i = 0; i < n; i++) {
                    t = cs * V.get(i, j) + sn * V.get(i, j + 1);
                    V.set(i, j + 1, -sn * V.get(i, j) + cs * V.get(i, j + 1));
                    V.set(i, j, t);
                  }
                }
                t = hypotenuse(f, g);
                if (t === 0) t = Number.MIN_VALUE;
                cs = f / t;
                sn = g / t;
                s[j] = t;
                f = cs * e[j] + sn * s[j + 1];
                s[j + 1] = -sn * e[j] + cs * s[j + 1];
                g = sn * e[j + 1];
                e[j + 1] = cs * e[j + 1];
                if (wantu && j < m - 1) {
                  for (let i = 0; i < m; i++) {
                    t = cs * U.get(i, j) + sn * U.get(i, j + 1);
                    U.set(i, j + 1, -sn * U.get(i, j) + cs * U.get(i, j + 1));
                    U.set(i, j, t);
                  }
                }
              }
              e[p - 2] = f;
              break;
            }
            case 4: {
              if (s[k] <= 0) {
                s[k] = s[k] < 0 ? -s[k] : 0;
                if (wantv) {
                  for (let i = 0; i <= pp; i++) {
                    V.set(i, k, -V.get(i, k));
                  }
                }
              }
              while (k < pp) {
                if (s[k] >= s[k + 1]) {
                  break;
                }
                let t = s[k];
                s[k] = s[k + 1];
                s[k + 1] = t;
                if (wantv && k < n - 1) {
                  for (let i = 0; i < n; i++) {
                    t = V.get(i, k + 1);
                    V.set(i, k + 1, V.get(i, k));
                    V.set(i, k, t);
                  }
                }
                if (wantu && k < m - 1) {
                  for (let i = 0; i < m; i++) {
                    t = U.get(i, k + 1);
                    U.set(i, k + 1, U.get(i, k));
                    U.set(i, k, t);
                  }
                }
                k++;
              }
              p--;
              break;
            }
          }
        }
        if (swapped) {
          let tmp = V;
          V = U;
          U = tmp;
        }
        this.m = m;
        this.n = n;
        this.s = s;
        this.U = U;
        this.V = V;
      }
      solve(value) {
        let Y = value;
        let e = this.threshold;
        let scols = this.s.length;
        let Ls = Matrix3.zeros(scols, scols);
        for (let i = 0; i < scols; i++) {
          if (Math.abs(this.s[i]) <= e) {
            Ls.set(i, i, 0);
          } else {
            Ls.set(i, i, 1 / this.s[i]);
          }
        }
        let U = this.U;
        let V = this.rightSingularVectors;
        let VL = V.mmul(Ls);
        let vrows = V.rows;
        let urows = U.rows;
        let VLU = Matrix3.zeros(vrows, urows);
        for (let i = 0; i < vrows; i++) {
          for (let j = 0; j < urows; j++) {
            let sum = 0;
            for (let k = 0; k < scols; k++) {
              sum += VL.get(i, k) * U.get(j, k);
            }
            VLU.set(i, j, sum);
          }
        }
        return VLU.mmul(Y);
      }
      solveForDiagonal(value) {
        return this.solve(Matrix3.diag(value));
      }
      inverse() {
        let V = this.V;
        let e = this.threshold;
        let vrows = V.rows;
        let vcols = V.columns;
        let X = new Matrix3(vrows, this.s.length);
        for (let i = 0; i < vrows; i++) {
          for (let j = 0; j < vcols; j++) {
            if (Math.abs(this.s[j]) > e) {
              X.set(i, j, V.get(i, j) / this.s[j]);
            }
          }
        }
        let U = this.U;
        let urows = U.rows;
        let ucols = U.columns;
        let Y = new Matrix3(vrows, urows);
        for (let i = 0; i < vrows; i++) {
          for (let j = 0; j < urows; j++) {
            let sum = 0;
            for (let k = 0; k < ucols; k++) {
              sum += X.get(i, k) * U.get(j, k);
            }
            Y.set(i, j, sum);
          }
        }
        return Y;
      }
      get condition() {
        return this.s[0] / this.s[Math.min(this.m, this.n) - 1];
      }
      get norm2() {
        return this.s[0];
      }
      get rank() {
        let tol = Math.max(this.m, this.n) * this.s[0] * Number.EPSILON;
        let r = 0;
        let s = this.s;
        for (let i = 0, ii = s.length; i < ii; i++) {
          if (s[i] > tol) {
            r++;
          }
        }
        return r;
      }
      get diagonal() {
        return Array.from(this.s);
      }
      get threshold() {
        return Number.EPSILON / 2 * Math.max(this.m, this.n) * this.s[0];
      }
      get leftSingularVectors() {
        return this.U;
      }
      get rightSingularVectors() {
        return this.V;
      }
      get diagonalMatrix() {
        return Matrix3.diag(this.s);
      }
    };
    function inverse3(matrix2, useSVD = false) {
      matrix2 = WrapperMatrix2D3.checkMatrix(matrix2);
      if (useSVD) {
        return new SingularValueDecomposition3(matrix2).inverse();
      } else {
        return solve3(matrix2, Matrix3.eye(matrix2.rows));
      }
    }
    function solve3(leftHandSide, rightHandSide, useSVD = false) {
      leftHandSide = WrapperMatrix2D3.checkMatrix(leftHandSide);
      rightHandSide = WrapperMatrix2D3.checkMatrix(rightHandSide);
      if (useSVD) {
        return new SingularValueDecomposition3(leftHandSide).solve(rightHandSide);
      } else {
        return leftHandSide.isSquare() ? new LuDecomposition2(leftHandSide).solve(rightHandSide) : new QrDecomposition3(leftHandSide).solve(rightHandSide);
      }
    }
    function determinant2(matrix2) {
      matrix2 = Matrix3.checkMatrix(matrix2);
      if (matrix2.isSquare()) {
        if (matrix2.columns === 0) {
          return 1;
        }
        let a, b, c, d;
        if (matrix2.columns === 2) {
          a = matrix2.get(0, 0);
          b = matrix2.get(0, 1);
          c = matrix2.get(1, 0);
          d = matrix2.get(1, 1);
          return a * d - b * c;
        } else if (matrix2.columns === 3) {
          let subMatrix0, subMatrix1, subMatrix2;
          subMatrix0 = new MatrixSelectionView2(matrix2, [1, 2], [1, 2]);
          subMatrix1 = new MatrixSelectionView2(matrix2, [1, 2], [0, 2]);
          subMatrix2 = new MatrixSelectionView2(matrix2, [1, 2], [0, 1]);
          a = matrix2.get(0, 0);
          b = matrix2.get(0, 1);
          c = matrix2.get(0, 2);
          return a * determinant2(subMatrix0) - b * determinant2(subMatrix1) + c * determinant2(subMatrix2);
        } else {
          return new LuDecomposition2(matrix2).determinant;
        }
      } else {
        throw Error("determinant can only be calculated for a square matrix");
      }
    }
    function xrange(n, exception) {
      let range = [];
      for (let i = 0; i < n; i++) {
        if (i !== exception) {
          range.push(i);
        }
      }
      return range;
    }
    function dependenciesOneRow(error, matrix2, index, thresholdValue = 1e-9, thresholdError = 1e-9) {
      if (error > thresholdError) {
        return new Array(matrix2.rows + 1).fill(0);
      } else {
        let returnArray = matrix2.addRow(index, [0]);
        for (let i = 0; i < returnArray.rows; i++) {
          if (Math.abs(returnArray.get(i, 0)) < thresholdValue) {
            returnArray.set(i, 0, 0);
          }
        }
        return returnArray.to1DArray();
      }
    }
    function linearDependencies2(matrix2, options = {}) {
      const { thresholdValue = 1e-9, thresholdError = 1e-9 } = options;
      matrix2 = Matrix3.checkMatrix(matrix2);
      let n = matrix2.rows;
      let results = new Matrix3(n, n);
      for (let i = 0; i < n; i++) {
        let b = Matrix3.columnVector(matrix2.getRow(i));
        let Abis = matrix2.subMatrixRow(xrange(n, i)).transpose();
        let svd = new SingularValueDecomposition3(Abis);
        let x = svd.solve(b);
        let error = Matrix3.sub(b, Abis.mmul(x)).abs().max();
        results.setRow(
          i,
          dependenciesOneRow(error, x, i, thresholdValue, thresholdError)
        );
      }
      return results;
    }
    function pseudoInverse2(matrix2, threshold = Number.EPSILON) {
      matrix2 = Matrix3.checkMatrix(matrix2);
      if (matrix2.isEmpty()) {
        return matrix2.transpose();
      }
      let svdSolution = new SingularValueDecomposition3(matrix2, { autoTranspose: true });
      let U = svdSolution.leftSingularVectors;
      let V = svdSolution.rightSingularVectors;
      let s = svdSolution.diagonal;
      for (let i = 0; i < s.length; i++) {
        if (Math.abs(s[i]) > threshold) {
          s[i] = 1 / s[i];
        } else {
          s[i] = 0;
        }
      }
      return V.mmul(Matrix3.diag(s).mmul(U.transpose()));
    }
    function covariance2(xMatrix, yMatrix = xMatrix, options = {}) {
      xMatrix = new Matrix3(xMatrix);
      let yIsSame = false;
      if (typeof yMatrix === "object" && !Matrix3.isMatrix(yMatrix) && !isAnyArray.isAnyArray(yMatrix)) {
        options = yMatrix;
        yMatrix = xMatrix;
        yIsSame = true;
      } else {
        yMatrix = new Matrix3(yMatrix);
      }
      if (xMatrix.rows !== yMatrix.rows) {
        throw new TypeError("Both matrices must have the same number of rows");
      }
      const { center = true } = options;
      if (center) {
        xMatrix = xMatrix.center("column");
        if (!yIsSame) {
          yMatrix = yMatrix.center("column");
        }
      }
      const cov = xMatrix.transpose().mmul(yMatrix);
      for (let i = 0; i < cov.rows; i++) {
        for (let j = 0; j < cov.columns; j++) {
          cov.set(i, j, cov.get(i, j) * (1 / (xMatrix.rows - 1)));
        }
      }
      return cov;
    }
    function correlation2(xMatrix, yMatrix = xMatrix, options = {}) {
      xMatrix = new Matrix3(xMatrix);
      let yIsSame = false;
      if (typeof yMatrix === "object" && !Matrix3.isMatrix(yMatrix) && !isAnyArray.isAnyArray(yMatrix)) {
        options = yMatrix;
        yMatrix = xMatrix;
        yIsSame = true;
      } else {
        yMatrix = new Matrix3(yMatrix);
      }
      if (xMatrix.rows !== yMatrix.rows) {
        throw new TypeError("Both matrices must have the same number of rows");
      }
      const { center = true, scale = true } = options;
      if (center) {
        xMatrix.center("column");
        if (!yIsSame) {
          yMatrix.center("column");
        }
      }
      if (scale) {
        xMatrix.scale("column");
        if (!yIsSame) {
          yMatrix.scale("column");
        }
      }
      const sdx = xMatrix.standardDeviation("column", { unbiased: true });
      const sdy = yIsSame ? sdx : yMatrix.standardDeviation("column", { unbiased: true });
      const corr = xMatrix.transpose().mmul(yMatrix);
      for (let i = 0; i < corr.rows; i++) {
        for (let j = 0; j < corr.columns; j++) {
          corr.set(
            i,
            j,
            corr.get(i, j) * (1 / (sdx[i] * sdy[j])) * (1 / (xMatrix.rows - 1))
          );
        }
      }
      return corr;
    }
    var EigenvalueDecomposition3 = class {
      constructor(matrix2, options = {}) {
        const { assumeSymmetric = false } = options;
        matrix2 = WrapperMatrix2D3.checkMatrix(matrix2);
        if (!matrix2.isSquare()) {
          throw new Error("Matrix is not a square matrix");
        }
        if (matrix2.isEmpty()) {
          throw new Error("Matrix must be non-empty");
        }
        let n = matrix2.columns;
        let V = new Matrix3(n, n);
        let d = new Float64Array(n);
        let e = new Float64Array(n);
        let value = matrix2;
        let i, j;
        let isSymmetric = false;
        if (assumeSymmetric) {
          isSymmetric = true;
        } else {
          isSymmetric = matrix2.isSymmetric();
        }
        if (isSymmetric) {
          for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
              V.set(i, j, value.get(i, j));
            }
          }
          tred2(n, e, d, V);
          tql2(n, e, d, V);
        } else {
          let H = new Matrix3(n, n);
          let ort = new Float64Array(n);
          for (j = 0; j < n; j++) {
            for (i = 0; i < n; i++) {
              H.set(i, j, value.get(i, j));
            }
          }
          orthes(n, H, ort, V);
          hqr2(n, e, d, V, H);
        }
        this.n = n;
        this.e = e;
        this.d = d;
        this.V = V;
      }
      get realEigenvalues() {
        return Array.from(this.d);
      }
      get imaginaryEigenvalues() {
        return Array.from(this.e);
      }
      get eigenvectorMatrix() {
        return this.V;
      }
      get diagonalMatrix() {
        let n = this.n;
        let e = this.e;
        let d = this.d;
        let X = new Matrix3(n, n);
        let i, j;
        for (i = 0; i < n; i++) {
          for (j = 0; j < n; j++) {
            X.set(i, j, 0);
          }
          X.set(i, i, d[i]);
          if (e[i] > 0) {
            X.set(i, i + 1, e[i]);
          } else if (e[i] < 0) {
            X.set(i, i - 1, e[i]);
          }
        }
        return X;
      }
    };
    function tred2(n, e, d, V) {
      let f, g, h, i, j, k, hh, scale;
      for (j = 0; j < n; j++) {
        d[j] = V.get(n - 1, j);
      }
      for (i = n - 1; i > 0; i--) {
        scale = 0;
        h = 0;
        for (k = 0; k < i; k++) {
          scale = scale + Math.abs(d[k]);
        }
        if (scale === 0) {
          e[i] = d[i - 1];
          for (j = 0; j < i; j++) {
            d[j] = V.get(i - 1, j);
            V.set(i, j, 0);
            V.set(j, i, 0);
          }
        } else {
          for (k = 0; k < i; k++) {
            d[k] /= scale;
            h += d[k] * d[k];
          }
          f = d[i - 1];
          g = Math.sqrt(h);
          if (f > 0) {
            g = -g;
          }
          e[i] = scale * g;
          h = h - f * g;
          d[i - 1] = f - g;
          for (j = 0; j < i; j++) {
            e[j] = 0;
          }
          for (j = 0; j < i; j++) {
            f = d[j];
            V.set(j, i, f);
            g = e[j] + V.get(j, j) * f;
            for (k = j + 1; k <= i - 1; k++) {
              g += V.get(k, j) * d[k];
              e[k] += V.get(k, j) * f;
            }
            e[j] = g;
          }
          f = 0;
          for (j = 0; j < i; j++) {
            e[j] /= h;
            f += e[j] * d[j];
          }
          hh = f / (h + h);
          for (j = 0; j < i; j++) {
            e[j] -= hh * d[j];
          }
          for (j = 0; j < i; j++) {
            f = d[j];
            g = e[j];
            for (k = j; k <= i - 1; k++) {
              V.set(k, j, V.get(k, j) - (f * e[k] + g * d[k]));
            }
            d[j] = V.get(i - 1, j);
            V.set(i, j, 0);
          }
        }
        d[i] = h;
      }
      for (i = 0; i < n - 1; i++) {
        V.set(n - 1, i, V.get(i, i));
        V.set(i, i, 1);
        h = d[i + 1];
        if (h !== 0) {
          for (k = 0; k <= i; k++) {
            d[k] = V.get(k, i + 1) / h;
          }
          for (j = 0; j <= i; j++) {
            g = 0;
            for (k = 0; k <= i; k++) {
              g += V.get(k, i + 1) * V.get(k, j);
            }
            for (k = 0; k <= i; k++) {
              V.set(k, j, V.get(k, j) - g * d[k]);
            }
          }
        }
        for (k = 0; k <= i; k++) {
          V.set(k, i + 1, 0);
        }
      }
      for (j = 0; j < n; j++) {
        d[j] = V.get(n - 1, j);
        V.set(n - 1, j, 0);
      }
      V.set(n - 1, n - 1, 1);
      e[0] = 0;
    }
    function tql2(n, e, d, V) {
      let g, h, i, j, k, l, m, p, r, dl1, c, c2, c3, el1, s, s2;
      for (i = 1; i < n; i++) {
        e[i - 1] = e[i];
      }
      e[n - 1] = 0;
      let f = 0;
      let tst1 = 0;
      let eps = Number.EPSILON;
      for (l = 0; l < n; l++) {
        tst1 = Math.max(tst1, Math.abs(d[l]) + Math.abs(e[l]));
        m = l;
        while (m < n) {
          if (Math.abs(e[m]) <= eps * tst1) {
            break;
          }
          m++;
        }
        if (m > l) {
          do {
            g = d[l];
            p = (d[l + 1] - g) / (2 * e[l]);
            r = hypotenuse(p, 1);
            if (p < 0) {
              r = -r;
            }
            d[l] = e[l] / (p + r);
            d[l + 1] = e[l] * (p + r);
            dl1 = d[l + 1];
            h = g - d[l];
            for (i = l + 2; i < n; i++) {
              d[i] -= h;
            }
            f = f + h;
            p = d[m];
            c = 1;
            c2 = c;
            c3 = c;
            el1 = e[l + 1];
            s = 0;
            s2 = 0;
            for (i = m - 1; i >= l; i--) {
              c3 = c2;
              c2 = c;
              s2 = s;
              g = c * e[i];
              h = c * p;
              r = hypotenuse(p, e[i]);
              e[i + 1] = s * r;
              s = e[i] / r;
              c = p / r;
              p = c * d[i] - s * g;
              d[i + 1] = h + s * (c * g + s * d[i]);
              for (k = 0; k < n; k++) {
                h = V.get(k, i + 1);
                V.set(k, i + 1, s * V.get(k, i) + c * h);
                V.set(k, i, c * V.get(k, i) - s * h);
              }
            }
            p = -s * s2 * c3 * el1 * e[l] / dl1;
            e[l] = s * p;
            d[l] = c * p;
          } while (Math.abs(e[l]) > eps * tst1);
        }
        d[l] = d[l] + f;
        e[l] = 0;
      }
      for (i = 0; i < n - 1; i++) {
        k = i;
        p = d[i];
        for (j = i + 1; j < n; j++) {
          if (d[j] < p) {
            k = j;
            p = d[j];
          }
        }
        if (k !== i) {
          d[k] = d[i];
          d[i] = p;
          for (j = 0; j < n; j++) {
            p = V.get(j, i);
            V.set(j, i, V.get(j, k));
            V.set(j, k, p);
          }
        }
      }
    }
    function orthes(n, H, ort, V) {
      let low = 0;
      let high = n - 1;
      let f, g, h, i, j, m;
      let scale;
      for (m = low + 1; m <= high - 1; m++) {
        scale = 0;
        for (i = m; i <= high; i++) {
          scale = scale + Math.abs(H.get(i, m - 1));
        }
        if (scale !== 0) {
          h = 0;
          for (i = high; i >= m; i--) {
            ort[i] = H.get(i, m - 1) / scale;
            h += ort[i] * ort[i];
          }
          g = Math.sqrt(h);
          if (ort[m] > 0) {
            g = -g;
          }
          h = h - ort[m] * g;
          ort[m] = ort[m] - g;
          for (j = m; j < n; j++) {
            f = 0;
            for (i = high; i >= m; i--) {
              f += ort[i] * H.get(i, j);
            }
            f = f / h;
            for (i = m; i <= high; i++) {
              H.set(i, j, H.get(i, j) - f * ort[i]);
            }
          }
          for (i = 0; i <= high; i++) {
            f = 0;
            for (j = high; j >= m; j--) {
              f += ort[j] * H.get(i, j);
            }
            f = f / h;
            for (j = m; j <= high; j++) {
              H.set(i, j, H.get(i, j) - f * ort[j]);
            }
          }
          ort[m] = scale * ort[m];
          H.set(m, m - 1, scale * g);
        }
      }
      for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
          V.set(i, j, i === j ? 1 : 0);
        }
      }
      for (m = high - 1; m >= low + 1; m--) {
        if (H.get(m, m - 1) !== 0) {
          for (i = m + 1; i <= high; i++) {
            ort[i] = H.get(i, m - 1);
          }
          for (j = m; j <= high; j++) {
            g = 0;
            for (i = m; i <= high; i++) {
              g += ort[i] * V.get(i, j);
            }
            g = g / ort[m] / H.get(m, m - 1);
            for (i = m; i <= high; i++) {
              V.set(i, j, V.get(i, j) + g * ort[i]);
            }
          }
        }
      }
    }
    function hqr2(nn, e, d, V, H) {
      let n = nn - 1;
      let low = 0;
      let high = nn - 1;
      let eps = Number.EPSILON;
      let exshift = 0;
      let norm = 0;
      let p = 0;
      let q = 0;
      let r = 0;
      let s = 0;
      let z = 0;
      let iter = 0;
      let i, j, k, l, m, t, w, x, y;
      let ra, sa, vr, vi;
      let notlast, cdivres;
      for (i = 0; i < nn; i++) {
        if (i < low || i > high) {
          d[i] = H.get(i, i);
          e[i] = 0;
        }
        for (j = Math.max(i - 1, 0); j < nn; j++) {
          norm = norm + Math.abs(H.get(i, j));
        }
      }
      while (n >= low) {
        l = n;
        while (l > low) {
          s = Math.abs(H.get(l - 1, l - 1)) + Math.abs(H.get(l, l));
          if (s === 0) {
            s = norm;
          }
          if (Math.abs(H.get(l, l - 1)) < eps * s) {
            break;
          }
          l--;
        }
        if (l === n) {
          H.set(n, n, H.get(n, n) + exshift);
          d[n] = H.get(n, n);
          e[n] = 0;
          n--;
          iter = 0;
        } else if (l === n - 1) {
          w = H.get(n, n - 1) * H.get(n - 1, n);
          p = (H.get(n - 1, n - 1) - H.get(n, n)) / 2;
          q = p * p + w;
          z = Math.sqrt(Math.abs(q));
          H.set(n, n, H.get(n, n) + exshift);
          H.set(n - 1, n - 1, H.get(n - 1, n - 1) + exshift);
          x = H.get(n, n);
          if (q >= 0) {
            z = p >= 0 ? p + z : p - z;
            d[n - 1] = x + z;
            d[n] = d[n - 1];
            if (z !== 0) {
              d[n] = x - w / z;
            }
            e[n - 1] = 0;
            e[n] = 0;
            x = H.get(n, n - 1);
            s = Math.abs(x) + Math.abs(z);
            p = x / s;
            q = z / s;
            r = Math.sqrt(p * p + q * q);
            p = p / r;
            q = q / r;
            for (j = n - 1; j < nn; j++) {
              z = H.get(n - 1, j);
              H.set(n - 1, j, q * z + p * H.get(n, j));
              H.set(n, j, q * H.get(n, j) - p * z);
            }
            for (i = 0; i <= n; i++) {
              z = H.get(i, n - 1);
              H.set(i, n - 1, q * z + p * H.get(i, n));
              H.set(i, n, q * H.get(i, n) - p * z);
            }
            for (i = low; i <= high; i++) {
              z = V.get(i, n - 1);
              V.set(i, n - 1, q * z + p * V.get(i, n));
              V.set(i, n, q * V.get(i, n) - p * z);
            }
          } else {
            d[n - 1] = x + p;
            d[n] = x + p;
            e[n - 1] = z;
            e[n] = -z;
          }
          n = n - 2;
          iter = 0;
        } else {
          x = H.get(n, n);
          y = 0;
          w = 0;
          if (l < n) {
            y = H.get(n - 1, n - 1);
            w = H.get(n, n - 1) * H.get(n - 1, n);
          }
          if (iter === 10) {
            exshift += x;
            for (i = low; i <= n; i++) {
              H.set(i, i, H.get(i, i) - x);
            }
            s = Math.abs(H.get(n, n - 1)) + Math.abs(H.get(n - 1, n - 2));
            x = y = 0.75 * s;
            w = -0.4375 * s * s;
          }
          if (iter === 30) {
            s = (y - x) / 2;
            s = s * s + w;
            if (s > 0) {
              s = Math.sqrt(s);
              if (y < x) {
                s = -s;
              }
              s = x - w / ((y - x) / 2 + s);
              for (i = low; i <= n; i++) {
                H.set(i, i, H.get(i, i) - s);
              }
              exshift += s;
              x = y = w = 0.964;
            }
          }
          iter = iter + 1;
          m = n - 2;
          while (m >= l) {
            z = H.get(m, m);
            r = x - z;
            s = y - z;
            p = (r * s - w) / H.get(m + 1, m) + H.get(m, m + 1);
            q = H.get(m + 1, m + 1) - z - r - s;
            r = H.get(m + 2, m + 1);
            s = Math.abs(p) + Math.abs(q) + Math.abs(r);
            p = p / s;
            q = q / s;
            r = r / s;
            if (m === l) {
              break;
            }
            if (Math.abs(H.get(m, m - 1)) * (Math.abs(q) + Math.abs(r)) < eps * (Math.abs(p) * (Math.abs(H.get(m - 1, m - 1)) + Math.abs(z) + Math.abs(H.get(m + 1, m + 1))))) {
              break;
            }
            m--;
          }
          for (i = m + 2; i <= n; i++) {
            H.set(i, i - 2, 0);
            if (i > m + 2) {
              H.set(i, i - 3, 0);
            }
          }
          for (k = m; k <= n - 1; k++) {
            notlast = k !== n - 1;
            if (k !== m) {
              p = H.get(k, k - 1);
              q = H.get(k + 1, k - 1);
              r = notlast ? H.get(k + 2, k - 1) : 0;
              x = Math.abs(p) + Math.abs(q) + Math.abs(r);
              if (x !== 0) {
                p = p / x;
                q = q / x;
                r = r / x;
              }
            }
            if (x === 0) {
              break;
            }
            s = Math.sqrt(p * p + q * q + r * r);
            if (p < 0) {
              s = -s;
            }
            if (s !== 0) {
              if (k !== m) {
                H.set(k, k - 1, -s * x);
              } else if (l !== m) {
                H.set(k, k - 1, -H.get(k, k - 1));
              }
              p = p + s;
              x = p / s;
              y = q / s;
              z = r / s;
              q = q / p;
              r = r / p;
              for (j = k; j < nn; j++) {
                p = H.get(k, j) + q * H.get(k + 1, j);
                if (notlast) {
                  p = p + r * H.get(k + 2, j);
                  H.set(k + 2, j, H.get(k + 2, j) - p * z);
                }
                H.set(k, j, H.get(k, j) - p * x);
                H.set(k + 1, j, H.get(k + 1, j) - p * y);
              }
              for (i = 0; i <= Math.min(n, k + 3); i++) {
                p = x * H.get(i, k) + y * H.get(i, k + 1);
                if (notlast) {
                  p = p + z * H.get(i, k + 2);
                  H.set(i, k + 2, H.get(i, k + 2) - p * r);
                }
                H.set(i, k, H.get(i, k) - p);
                H.set(i, k + 1, H.get(i, k + 1) - p * q);
              }
              for (i = low; i <= high; i++) {
                p = x * V.get(i, k) + y * V.get(i, k + 1);
                if (notlast) {
                  p = p + z * V.get(i, k + 2);
                  V.set(i, k + 2, V.get(i, k + 2) - p * r);
                }
                V.set(i, k, V.get(i, k) - p);
                V.set(i, k + 1, V.get(i, k + 1) - p * q);
              }
            }
          }
        }
      }
      if (norm === 0) {
        return;
      }
      for (n = nn - 1; n >= 0; n--) {
        p = d[n];
        q = e[n];
        if (q === 0) {
          l = n;
          H.set(n, n, 1);
          for (i = n - 1; i >= 0; i--) {
            w = H.get(i, i) - p;
            r = 0;
            for (j = l; j <= n; j++) {
              r = r + H.get(i, j) * H.get(j, n);
            }
            if (e[i] < 0) {
              z = w;
              s = r;
            } else {
              l = i;
              if (e[i] === 0) {
                H.set(i, n, w !== 0 ? -r / w : -r / (eps * norm));
              } else {
                x = H.get(i, i + 1);
                y = H.get(i + 1, i);
                q = (d[i] - p) * (d[i] - p) + e[i] * e[i];
                t = (x * s - z * r) / q;
                H.set(i, n, t);
                H.set(
                  i + 1,
                  n,
                  Math.abs(x) > Math.abs(z) ? (-r - w * t) / x : (-s - y * t) / z
                );
              }
              t = Math.abs(H.get(i, n));
              if (eps * t * t > 1) {
                for (j = i; j <= n; j++) {
                  H.set(j, n, H.get(j, n) / t);
                }
              }
            }
          }
        } else if (q < 0) {
          l = n - 1;
          if (Math.abs(H.get(n, n - 1)) > Math.abs(H.get(n - 1, n))) {
            H.set(n - 1, n - 1, q / H.get(n, n - 1));
            H.set(n - 1, n, -(H.get(n, n) - p) / H.get(n, n - 1));
          } else {
            cdivres = cdiv(0, -H.get(n - 1, n), H.get(n - 1, n - 1) - p, q);
            H.set(n - 1, n - 1, cdivres[0]);
            H.set(n - 1, n, cdivres[1]);
          }
          H.set(n, n - 1, 0);
          H.set(n, n, 1);
          for (i = n - 2; i >= 0; i--) {
            ra = 0;
            sa = 0;
            for (j = l; j <= n; j++) {
              ra = ra + H.get(i, j) * H.get(j, n - 1);
              sa = sa + H.get(i, j) * H.get(j, n);
            }
            w = H.get(i, i) - p;
            if (e[i] < 0) {
              z = w;
              r = ra;
              s = sa;
            } else {
              l = i;
              if (e[i] === 0) {
                cdivres = cdiv(-ra, -sa, w, q);
                H.set(i, n - 1, cdivres[0]);
                H.set(i, n, cdivres[1]);
              } else {
                x = H.get(i, i + 1);
                y = H.get(i + 1, i);
                vr = (d[i] - p) * (d[i] - p) + e[i] * e[i] - q * q;
                vi = (d[i] - p) * 2 * q;
                if (vr === 0 && vi === 0) {
                  vr = eps * norm * (Math.abs(w) + Math.abs(q) + Math.abs(x) + Math.abs(y) + Math.abs(z));
                }
                cdivres = cdiv(
                  x * r - z * ra + q * sa,
                  x * s - z * sa - q * ra,
                  vr,
                  vi
                );
                H.set(i, n - 1, cdivres[0]);
                H.set(i, n, cdivres[1]);
                if (Math.abs(x) > Math.abs(z) + Math.abs(q)) {
                  H.set(
                    i + 1,
                    n - 1,
                    (-ra - w * H.get(i, n - 1) + q * H.get(i, n)) / x
                  );
                  H.set(
                    i + 1,
                    n,
                    (-sa - w * H.get(i, n) - q * H.get(i, n - 1)) / x
                  );
                } else {
                  cdivres = cdiv(
                    -r - y * H.get(i, n - 1),
                    -s - y * H.get(i, n),
                    z,
                    q
                  );
                  H.set(i + 1, n - 1, cdivres[0]);
                  H.set(i + 1, n, cdivres[1]);
                }
              }
              t = Math.max(Math.abs(H.get(i, n - 1)), Math.abs(H.get(i, n)));
              if (eps * t * t > 1) {
                for (j = i; j <= n; j++) {
                  H.set(j, n - 1, H.get(j, n - 1) / t);
                  H.set(j, n, H.get(j, n) / t);
                }
              }
            }
          }
        }
      }
      for (i = 0; i < nn; i++) {
        if (i < low || i > high) {
          for (j = i; j < nn; j++) {
            V.set(i, j, H.get(i, j));
          }
        }
      }
      for (j = nn - 1; j >= low; j--) {
        for (i = low; i <= high; i++) {
          z = 0;
          for (k = low; k <= Math.min(j, high); k++) {
            z = z + V.get(i, k) * H.get(k, j);
          }
          V.set(i, j, z);
        }
      }
    }
    function cdiv(xr, xi, yr, yi) {
      let r, d;
      if (Math.abs(yr) > Math.abs(yi)) {
        r = yi / yr;
        d = yr + r * yi;
        return [(xr + r * xi) / d, (xi - r * xr) / d];
      } else {
        r = yr / yi;
        d = yi + r * yr;
        return [(r * xr + xi) / d, (r * xi - xr) / d];
      }
    }
    var CholeskyDecomposition3 = class {
      constructor(value) {
        value = WrapperMatrix2D3.checkMatrix(value);
        if (!value.isSymmetric()) {
          throw new Error("Matrix is not symmetric");
        }
        let a = value;
        let dimension = a.rows;
        let l = new Matrix3(dimension, dimension);
        let positiveDefinite = true;
        let i, j, k;
        for (j = 0; j < dimension; j++) {
          let d = 0;
          for (k = 0; k < j; k++) {
            let s = 0;
            for (i = 0; i < k; i++) {
              s += l.get(k, i) * l.get(j, i);
            }
            s = (a.get(j, k) - s) / l.get(k, k);
            l.set(j, k, s);
            d = d + s * s;
          }
          d = a.get(j, j) - d;
          positiveDefinite &&= d > 0;
          l.set(j, j, Math.sqrt(Math.max(d, 0)));
          for (k = j + 1; k < dimension; k++) {
            l.set(j, k, 0);
          }
        }
        this.L = l;
        this.positiveDefinite = positiveDefinite;
      }
      isPositiveDefinite() {
        return this.positiveDefinite;
      }
      solve(value) {
        value = WrapperMatrix2D3.checkMatrix(value);
        let l = this.L;
        let dimension = l.rows;
        if (value.rows !== dimension) {
          throw new Error("Matrix dimensions do not match");
        }
        if (this.isPositiveDefinite() === false) {
          throw new Error("Matrix is not positive definite");
        }
        let count = value.columns;
        let B = value.clone();
        let i, j, k;
        for (k = 0; k < dimension; k++) {
          for (j = 0; j < count; j++) {
            for (i = 0; i < k; i++) {
              B.set(k, j, B.get(k, j) - B.get(i, j) * l.get(k, i));
            }
            B.set(k, j, B.get(k, j) / l.get(k, k));
          }
        }
        for (k = dimension - 1; k >= 0; k--) {
          for (j = 0; j < count; j++) {
            for (i = k + 1; i < dimension; i++) {
              B.set(k, j, B.get(k, j) - B.get(i, j) * l.get(i, k));
            }
            B.set(k, j, B.get(k, j) / l.get(k, k));
          }
        }
        return B;
      }
      get lowerTriangularMatrix() {
        return this.L;
      }
    };
    var nipals = class {
      constructor(X, options = {}) {
        X = WrapperMatrix2D3.checkMatrix(X);
        let { Y } = options;
        const {
          scaleScores = false,
          maxIterations = 1e3,
          terminationCriteria = 1e-10
        } = options;
        let u;
        if (Y) {
          if (isAnyArray.isAnyArray(Y) && typeof Y[0] === "number") {
            Y = Matrix3.columnVector(Y);
          } else {
            Y = WrapperMatrix2D3.checkMatrix(Y);
          }
          if (Y.rows !== X.rows) {
            throw new Error("Y should have the same number of rows as X");
          }
          u = Y.getColumnVector(0);
        } else {
          u = X.getColumnVector(0);
        }
        let diff = 1;
        let t, q, w, tOld;
        for (let counter = 0; counter < maxIterations && diff > terminationCriteria; counter++) {
          w = X.transpose().mmul(u).div(u.transpose().mmul(u).get(0, 0));
          w = w.div(w.norm());
          t = X.mmul(w).div(w.transpose().mmul(w).get(0, 0));
          if (counter > 0) {
            diff = t.clone().sub(tOld).pow(2).sum();
          }
          tOld = t.clone();
          if (Y) {
            q = Y.transpose().mmul(t).div(t.transpose().mmul(t).get(0, 0));
            q = q.div(q.norm());
            u = Y.mmul(q).div(q.transpose().mmul(q).get(0, 0));
          } else {
            u = t;
          }
        }
        if (Y) {
          let p = X.transpose().mmul(t).div(t.transpose().mmul(t).get(0, 0));
          p = p.div(p.norm());
          let xResidual = X.clone().sub(t.clone().mmul(p.transpose()));
          let residual = u.transpose().mmul(t).div(t.transpose().mmul(t).get(0, 0));
          let yResidual = Y.clone().sub(
            t.clone().mulS(residual.get(0, 0)).mmul(q.transpose())
          );
          this.t = t;
          this.p = p.transpose();
          this.w = w.transpose();
          this.q = q;
          this.u = u;
          this.s = t.transpose().mmul(t);
          this.xResidual = xResidual;
          this.yResidual = yResidual;
          this.betas = residual;
        } else {
          this.w = w.transpose();
          this.s = t.transpose().mmul(t).sqrt();
          if (scaleScores) {
            this.t = t.clone().div(this.s.get(0, 0));
          } else {
            this.t = t;
          }
          this.xResidual = X.sub(t.mmul(w.transpose()));
        }
      }
    };
    exports.AbstractMatrix = AbstractMatrix2;
    exports.CHO = CholeskyDecomposition3;
    exports.CholeskyDecomposition = CholeskyDecomposition3;
    exports.DistanceMatrix = DistanceMatrix2;
    exports.EVD = EigenvalueDecomposition3;
    exports.EigenvalueDecomposition = EigenvalueDecomposition3;
    exports.LU = LuDecomposition2;
    exports.LuDecomposition = LuDecomposition2;
    exports.Matrix = Matrix3;
    exports.MatrixColumnSelectionView = MatrixColumnSelectionView2;
    exports.MatrixColumnView = MatrixColumnView2;
    exports.MatrixFlipColumnView = MatrixFlipColumnView2;
    exports.MatrixFlipRowView = MatrixFlipRowView2;
    exports.MatrixRowSelectionView = MatrixRowSelectionView2;
    exports.MatrixRowView = MatrixRowView2;
    exports.MatrixSelectionView = MatrixSelectionView2;
    exports.MatrixSubView = MatrixSubView2;
    exports.MatrixTransposeView = MatrixTransposeView2;
    exports.NIPALS = nipals;
    exports.Nipals = nipals;
    exports.QR = QrDecomposition3;
    exports.QrDecomposition = QrDecomposition3;
    exports.SVD = SingularValueDecomposition3;
    exports.SingularValueDecomposition = SingularValueDecomposition3;
    exports.SymmetricMatrix = SymmetricMatrix2;
    exports.WrapperMatrix1D = WrapperMatrix1D2;
    exports.WrapperMatrix2D = WrapperMatrix2D3;
    exports.correlation = correlation2;
    exports.covariance = covariance2;
    exports.default = Matrix3;
    exports.determinant = determinant2;
    exports.inverse = inverse3;
    exports.linearDependencies = linearDependencies2;
    exports.pseudoInverse = pseudoInverse2;
    exports.solve = solve3;
    exports.wrap = wrap2;
  }
});

// src/lib/efa/backends/split-shader.mjs
var splitShader = `
struct Shape { rows: u32, cols: u32, pairs: u32, parameters: u32 }
@group(0) @binding(0) var<storage, read> a: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read> b: array<vec2<f32>>;
@group(0) @binding(2) var<storage, read> za: array<vec2<f32>>;
@group(0) @binding(3) var<storage, read> zb: array<vec2<f32>>;
@group(0) @binding(4) var<storage, read_write> out: array<vec4<f32>>;
@group(0) @binding(5) var<uniform> shape: Shape;
var<workgroup> tileA: array<vec2<f32>, 256>;
var<workgroup> tileB: array<vec2<f32>, 256>;
@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) group: vec3<u32>) {
  let row = gid.y; let col = gid.x; let t = lid.y * 16u + lid.x;
  let begin = group.z * 256u;
  var hi = 0.0; var lo = 0.0;
  for (var offset = begin; offset < min(begin + 256u, shape.pairs); offset += 16u) {
    tileA[t] = vec2<f32>(0.0); tileB[t] = vec2<f32>(0.0);
    if (row < shape.rows && offset + lid.x < shape.pairs) { tileA[t] = a[row * shape.pairs + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.pairs) { tileB[t] = b[bRow * shape.pairs + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) {
      let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k];
      let product = av.x * bv.x;
      let residual = fma(av.x, bv.x, -product) + av.x * bv.y + av.y * bv.x + av.y * bv.y;
      hi += product; lo += residual;
    }
    workgroupBarrier();
  }
  let aHi = hi; let aLo = lo; hi = 0.0; lo = 0.0;
  for (var offset = begin; offset < min(begin + 256u, shape.parameters); offset += 16u) {
    tileA[t] = vec2<f32>(0.0); tileB[t] = vec2<f32>(0.0);
    if (row < shape.rows && offset + lid.x < shape.parameters) { tileA[t] = za[row * shape.parameters + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.parameters) { tileB[t] = zb[bRow * shape.parameters + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) {
      let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k];
      let product = av.x * bv.x;
      let residual = fma(av.x, bv.x, -product) + av.x * bv.y + av.y * bv.x + av.y * bv.y;
      hi += product; lo += residual;
    }
    workgroupBarrier();
  }
  let chunks = (max(shape.pairs, shape.parameters) + 255u) / 256u;
  if (row < shape.rows && col < shape.cols) { out[(row * shape.cols + col) * chunks + group.z] = vec4<f32>(aHi, aLo, hi, lo); }
}`;
var replacements = [
  ["parameters: u32 }", "parameters: u32, leftStart: u32, rightStart: u32 }"],
  ["var<storage, read> a: array<vec2<f32>>;", "var<storage, read> codes: array<u32>;"],
  ["var<storage, read> b: array<vec2<f32>>;", "var<storage, read> pairs: array<vec4<u32>>;"],
  ["var<storage, read> za: array<vec2<f32>>;", "var<storage, read> lookup: array<vec2<f32>>;"],
  ["var<storage, read> zb: array<vec2<f32>>;", "var<storage, read> projection: array<vec2<f32>>;"],
  ["a[row * shape.pairs + offset + lid.x]", "ordinal(shape.leftStart + row, offset + lid.x)"],
  ["b[bRow * shape.pairs + offset + lid.x]", "ordinal(shape.rightStart + bRow, offset + lid.x)"],
  ["za[row * shape.parameters + offset + lid.x]", "projection[(shape.leftStart + row) * shape.parameters + offset + lid.x]"],
  ["zb[bRow * shape.parameters + offset + lid.x]", "projection[(shape.rightStart + bRow) * shape.parameters + offset + lid.x]"]
];
var residentShader = replacements.reduce((source, [before, after]) => {
  if (!source.includes(before)) throw new Error(`Resident shader template mismatch: ${before}`);
  return source.replace(before, after);
}, splitShader) + `
fn rank(index: u32) -> u32 { return (codes[index / 2u] >> ((index % 2u) * 16u)) & 65535u; }
fn ordinal(row: u32, pair: u32) -> vec2<f32> {
  let pairInfo = pairs[pair]; let x = rank(pairInfo.x + row); let y = rank(pairInfo.y + row);
  if (x == 65535u || y == 65535u) { return vec2<f32>(0.0); }
  return lookup[pairInfo.w + x * pairInfo.z + y];
}`;

// src/lib/efa/backends/panel-shader.mjs
var panelDotShader = splitShader.replace("parameters: u32 }", "parameters: u32, leftStart: u32, rightStart: u32 }").replace("za[row * shape.parameters + offset + lid.x]", "za[(shape.leftStart + row) * shape.parameters + offset + lid.x]").replace("zb[bRow * shape.parameters + offset + lid.x]", "zb[(shape.rightStart + bRow) * shape.parameters + offset + lid.x]");
var panelShader = `
struct Shape { rows: u32, start: u32, pairs: u32, unused: u32 }
@group(0) @binding(0) var<storage, read> codes: array<u32>;
@group(0) @binding(1) var<storage, read> pairs: array<vec4<u32>>;
@group(0) @binding(2) var<storage, read> lookup: array<vec2<f32>>;
@group(0) @binding(3) var<storage, read_write> panel: array<vec2<f32>>;
@group(0) @binding(4) var<uniform> shape: Shape;
fn rank(index: u32) -> u32 { return (codes[index / 2u] >> ((index % 2u) * 16u)) & 65535u; }
@compute @workgroup_size(256)
fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  let index = gid.x;
  if (index >= shape.rows * shape.pairs) { return; }
  let row = shape.start + index / shape.pairs; let pair = pairs[index % shape.pairs];
  let x = rank(pair.x + row); let y = rank(pair.y + row);
  var value = vec2<f32>(0.0);
  if (x != 65535u && y != 65535u) { value = lookup[pair.w + x * pair.z + y]; }
  panel[index] = value;
}`;

// src/lib/efa/backends/reduce-shader.mjs
var reduceShader = `
struct Shape { outputs: u32, chunks: u32, unused0: u32, dispatchWidth: u32 }
@group(0) @binding(0) var<storage, read> partials: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> result: array<vec4<f32>>;
@group(0) @binding(2) var<uniform> shape: Shape;
var<workgroup> sums: array<vec4<f32>, 256>;
fn pairAdd(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
  let sum = a.x + b.x;
  let delta = sum - a.x;
  let error = (a.x - (sum - delta)) + (b.x - delta) + a.y + b.y;
  let hi = sum + error;
  return vec2<f32>(hi, error - (hi - sum));
}
fn add(a: vec4<f32>, b: vec4<f32>) -> vec4<f32> {
  return vec4<f32>(pairAdd(a.xy, b.xy), pairAdd(a.zw, b.zw));
}
@compute @workgroup_size(256)
fn main(@builtin(local_invocation_id) local: vec3<u32>, @builtin(workgroup_id) group: vec3<u32>) {
  let output = group.y * shape.dispatchWidth + group.x;
  if (output >= shape.outputs) { return; }
  var value = vec4<f32>(0.0);
  for (var chunk = local.x; chunk < shape.chunks; chunk += 256u) {
    value = add(value, partials[output * shape.chunks + chunk]);
  }
  sums[local.x] = value;
  workgroupBarrier();
  for (var stride = 128u; stride > 0u; stride /= 2u) {
    if (local.x < stride) { sums[local.x] = add(sums[local.x], sums[local.x + stride]); }
    workgroupBarrier();
  }
  if (local.x == 0u) { result[output] = sums[0]; }
}`;
function compensateSplit(source) {
  const fragment = "hi += product; lo += residual;";
  if (source.split(fragment).length !== 3) throw new Error("Split compensation template mismatch");
  return source.replaceAll(fragment, `
      let next = hi + product;
      if (abs(hi) >= abs(product)) { lo += (hi - next) + product; }
      else { lo += (product - next) + hi; }
      lo += residual;
      hi = next;`);
}

// src/lib/efa/backends/portable-shader.mjs
var arithmetic = `
fn rounded(value: f32) -> f32 {
  return bitcast<f32>(bitcast<u32>(value) ^ shape.roundingMask);
}
fn fpAdd(a: f32, b: f32) -> f32 { return rounded(a + b); }
fn fpSub(a: f32, b: f32) -> f32 { return rounded(a - b); }
fn fpMul(a: f32, b: f32) -> f32 { return rounded(a * b); }
fn productError(a: f32, b: f32, product: f32) -> f32 {
  // Split each 24-bit significand into two <=12-bit pieces. Every component
  // product is representable in f32 in the normal range. Unlike fma(), these
  // error-recovery operations do not depend on optional fused evaluation.
  let ah = bitcast<f32>(bitcast<u32>(a) & 0xfffff000u);
  let bh = bitcast<f32>(bitcast<u32>(b) & 0xfffff000u);
  let al = fpSub(a, ah); let bl = fpSub(b, bh);
  let first = fpSub(fpMul(ah, bh), product);
  return fpAdd(fpAdd(fpAdd(first, fpMul(ah, bl)), fpMul(al, bh)), fpMul(al, bl));
}
`;
function portableDotShader(source, resident) {
  const declaration = resident ? "parameters: u32, leftStart: u32, rightStart: u32 }" : "parameters: u32 }";
  if (!source.includes(declaration)) throw new Error("Portable shape template mismatch");
  source = source.replace(declaration, declaration.replace(" }", ", roundingMask: u32 }"));
  const fragment = `let product = av.x * bv.x;
      let residual = fma(av.x, bv.x, -product) + av.x * bv.y + av.y * bv.x + av.y * bv.y;
      hi += product; lo += residual;`;
  if (source.split(fragment).length !== 3) throw new Error("Portable dot template mismatch");
  return source.replaceAll(fragment, `let product = fpMul(av.x, bv.x);
      let residual = fpAdd(fpAdd(fpAdd(productError(av.x, bv.x, product), fpMul(av.x, bv.y)), fpMul(av.y, bv.x)), fpMul(av.y, bv.y));
      let next = fpAdd(hi, product);
      if (abs(hi) >= abs(product)) { lo = fpAdd(lo, fpAdd(fpSub(hi, next), product)); }
      else { lo = fpAdd(lo, fpAdd(fpSub(product, next), hi)); }
      lo = fpAdd(lo, residual);
      hi = next;`) + arithmetic;
}
function portableReductionShader(source) {
  const start = source.indexOf("  let sum = a.x + b.x;");
  const end = source.indexOf("\n}", start);
  if (start < 0 || end < 0) throw new Error("Portable reduction template mismatch");
  return (source.slice(0, start) + `  let sum = fpAdd(a.x, b.x);
  let delta = fpSub(sum, a.x);
  let error = fpAdd(fpAdd(fpAdd(fpSub(a.x, fpSub(sum, delta)), fpSub(b.x, delta)), a.y), b.y);
  let hi = fpAdd(sum, error);
  return vec2<f32>(hi, fpSub(error, fpSub(hi, sum)));` + source.slice(end)).replace("unused0: u32", "roundingMask: u32") + arithmetic;
}
function tiledPortableShader(source) {
  if (source.split("productError(av.x, bv.x, product)").length !== 3) throw new Error("Portable tile template mismatch");
  return source.replaceAll("array<vec2<f32>, 256>", "array<vec4<f32>, 256>").replaceAll("tileA[t] = vec2<f32>(0.0); tileB[t] = vec2<f32>(0.0);", "tileA[t] = vec4<f32>(0.0); tileB[t] = vec4<f32>(0.0);").replace(/(tile[AB]\[t\] = )([^;]+)(; \})/g, "$1splitInput($2)$3").replaceAll("productError(av.x, bv.x, product)", "tileProductError(av, bv, product)") + `
fn splitInput(v: vec2<f32>) -> vec4<f32> {
  let high = bitcast<f32>(bitcast<u32>(v.x) & 0xfffff000u);
  return vec4<f32>(v, high, fpSub(v.x, high));
}
fn tileProductError(a: vec4<f32>, b: vec4<f32>, product: f32) -> f32 {
  let first = fpSub(fpMul(a.z, b.z), product);
  return fpAdd(fpAdd(fpAdd(first, fpMul(a.z, b.w)), fpMul(a.w, b.z)), fpMul(a.w, b.w));
}`;
}

// src/lib/efa/backends/webgpu-kernel.mjs
async function createGpuKernel({ compensated = true, split = false, resident = false, compensatedSplit = false, reduce = false, portable = false, strictMath, signal, dotChunkSize, materializePanels = false, preSplit = false, loading = "columnar" } = {}) {
  dotChunkSize ??= portable ? 1024 : 256;
  if (![64, 128, 256, 512, 1024, 2048].includes(dotChunkSize)) throw new Error("Unsupported dot chunk size");
  if (materializePanels && (!resident || !portable)) throw new Error("Panel expansion requires the portable resident kernel");
  if (preSplit && !portable) throw new Error("Tiled splitting requires portable arithmetic");
  if (!["columnar", "cooperative", "respondent"].includes(loading)) throw new Error("Unknown ordinal loading layout");
  if (loading !== "columnar" && (!resident || !portable || materializePanels || preSplit)) throw new Error("Layout experiments require the portable resident kernel without panel/pre-split experiments");
  split ||= resident;
  if (portable && (!split || strictMath !== void 0 || compensatedSplit)) throw new Error("Portable precision requires split inputs and no strictMath/alternate compensation");
  if ((compensatedSplit || reduce) && !split) throw new Error("Split precision is required for these experiments");
  const startup = performance.now();
  if (!navigator.gpu) throw new Error("WebGPU unavailable");
  const adapter = await navigator.gpu.requestAdapter({ powerPreference: "high-performance" });
  if (!adapter || adapter.info.isFallbackAdapter) throw new Error("No hardware WebGPU adapter");
  const timestamps = adapter.features.has("timestamp-query");
  const bindingLimit = Math.min(512 * 1024 ** 2, adapter.limits.maxStorageBufferBindingSize, adapter.limits.maxBufferSize);
  const device = await adapter.requestDevice({ requiredFeatures: timestamps ? ["timestamp-query"] : [], ...resident ? { requiredLimits: { maxStorageBufferBindingSize: bindingLimit, maxBufferSize: bindingLimit } } : {} });
  let lost;
  void device.lost.then((info2) => {
    lost = info2.message || "GPU device lost";
  });
  const abort = () => device.destroy();
  signal?.addEventListener("abort", abort, { once: true });
  const add = compensated ? "let t = av * bv - correction; let next = sum + t; correction = (next - sum) - t; sum = next;" : "sum += av * bv;";
  let code = materializePanels ? panelDotShader : resident ? residentShader : split ? splitShader : `
struct Shape { rows: u32, cols: u32, pairs: u32, parameters: u32 }
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read> za: array<f32>;
@group(0) @binding(3) var<storage, read> zb: array<f32>;
@group(0) @binding(4) var<storage, read_write> out: array<f32>;
@group(0) @binding(5) var<uniform> shape: Shape;
var<workgroup> tileA: array<f32, 256>;
var<workgroup> tileB: array<f32, 256>;
@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) group: vec3<u32>) {
  let row = gid.y; let col = gid.x; let t = lid.y * 16u + lid.x;
  var sum = 0.0; var correction = 0.0;
  for (var offset = 0u; offset < shape.pairs; offset += 16u) {
    tileA[t] = 0.0; tileB[t] = 0.0;
    if (row < shape.rows && offset + lid.x < shape.pairs) { tileA[t] = a[row * shape.pairs + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.pairs) { tileB[t] = b[bRow * shape.pairs + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) { let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k]; ${add} }
    workgroupBarrier();
  }
  let product = sum; sum = 0.0; correction = 0.0;
  for (var offset = 0u; offset < shape.parameters; offset += 16u) {
    tileA[t] = 0.0; tileB[t] = 0.0;
    if (row < shape.rows && offset + lid.x < shape.parameters) { tileA[t] = za[row * shape.parameters + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.parameters) { tileB[t] = zb[bRow * shape.parameters + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) { let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k]; ${add} }
    workgroupBarrier();
  }
  if (row < shape.rows && col < shape.cols) { out[row * shape.cols + col] = product - sum; }
}`;
  if (split) code = code.replaceAll("group.z * 256u", `group.z * ${dotChunkSize}u`).replaceAll("begin + 256u", `begin + ${dotChunkSize}u`).replace("(max(shape.pairs, shape.parameters) + 255u) / 256u", `(max(shape.pairs, shape.parameters) + ${dotChunkSize - 1}u) / ${dotChunkSize}u`);
  if (portable) code = portableDotShader(code, resident);
  if (loading === "respondent") code = code.replace("roundingMask: u32 }", "roundingMask: u32, items: u32 }").replace("rank(pairInfo.x + row)", "rank(row * shape.items + pairInfo.x)").replace("rank(pairInfo.y + row)", "rank(row * shape.items + pairInfo.y)");
  if (loading === "cooperative") {
    const before = `    if (row < shape.rows && offset + lid.x < shape.pairs) { tileA[t] = ordinal(shape.leftStart + row, offset + lid.x); }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.pairs) { tileB[t] = ordinal(shape.rightStart + bRow, offset + lid.x); }`;
    if (!code.includes(before)) throw new Error("Cooperative loader template mismatch");
    code = code.replace(before, `    let at = lid.x * 16u + lid.y;
    let aRow = group.y * 16u + lid.x; let bRow = group.x * 16u + lid.x;
    // Each lane initializes its transposed slot, including ragged tails.
    tileA[at] = vec2<f32>(0.0); tileB[at] = vec2<f32>(0.0);
    if (aRow < shape.rows && offset + lid.y < shape.pairs) { tileA[at] = ordinal(shape.leftStart + aRow, offset + lid.y); }
    if (bRow < shape.cols && offset + lid.y < shape.pairs) { tileB[at] = ordinal(shape.rightStart + bRow, offset + lid.y); }`).replace("    tileA[t] = vec2<f32>(0.0); tileB[t] = vec2<f32>(0.0);", "");
  }
  if (compensatedSplit) code = compensateSplit(code);
  if (preSplit) code = tiledPortableShader(code);
  const reductionCode = portable ? portableReductionShader(reduceShader) : reduceShader;
  let strictMathRecognized = strictMath === void 0 ? null : false;
  const createShaderModule = (code2) => {
    const descriptor = { code: code2 };
    if (strictMath !== void 0) Object.defineProperty(descriptor, "strictMath", { enumerable: true, get() {
      strictMathRecognized = true;
      return strictMath;
    } });
    const shader = device.createShaderModule(descriptor);
    if (strictMath === true && !strictMathRecognized) {
      device.destroy();
      throw new Error("strictMath was not recognized; this experiment requires the developer-only browser feature");
    }
    return shader;
  };
  const shaderModule = createShaderModule(code);
  const info = await shaderModule.getCompilationInfo();
  if (info.messages.some((m) => m.type === "error")) {
    device.destroy();
    throw new Error(info.messages.map((m) => m.message).join("\n"));
  }
  const pipeline = await device.createComputePipelineAsync({ layout: "auto", compute: { module: shaderModule, entryPoint: "main" } });
  const reductionPipeline = reduce ? await device.createComputePipelineAsync({ layout: "auto", compute: { module: createShaderModule(reductionCode), entryPoint: "main" } }) : void 0;
  const panelPipeline = materializePanels ? await device.createComputePipelineAsync({ layout: "auto", compute: { module: createShaderModule(panelShader), entryPoint: "main" } }) : void 0;
  const panels = [], panelCapacities = [0, 0], panelRanges = [];
  const panelShapes = materializePanels ? [0, 1].map(() => device.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST })) : [];
  const queryCount = materializePanels ? 6 : reduce ? 4 : 2, queryBytes = queryCount * 8;
  const query = timestamps ? device.createQuerySet({ type: "timestamp", count: queryCount }) : void 0;
  const queryResolve = timestamps ? device.createBuffer({ size: queryBytes, usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC }) : void 0;
  const queryRead = timestamps ? device.createBuffer({ size: queryBytes, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST }) : void 0;
  const reductionShape = reduce ? device.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST }) : void 0;
  let reduced, reducedCapacity = 0;
  let sourceByteEstimate = 0, dotBinding, dotBindingKey, reductionBinding, reductionBindingKey;
  let buffers = [], capacities = [], sourceSizes, currentSource, read, readSize = 0, dispatchObserver;
  const timings = { startupMs: performance.now() - startup, packMs: 0, uploadSubmitMs: 0, dispatchReadbackMs: 0, readMapWaitMs: 0, hostReductionMs: 0, gpuMs: timestamps ? 0 : null, reductionGpuMs: timestamps && reduce ? 0 : null, panelExpansions: 0, panelCacheHits: 0, panelGpuMs: timestamps && materializePanels ? 0 : null, calls: 0, uploadedBytes: 0, readbackBytes: 0, peakOwnedGpuBufferBytes: 0, sourceInitializations: 0, bindGroupCacheHits: 0 };
  const pack = (rows) => {
    const result = new Float32Array(rows.length * rows[0].length * (split ? 2 : 1));
    if (split) rows.forEach((row, i) => {
      for (let k = 0; k < row.length; k++) {
        const offset = 2 * (i * row.length + k), hi = Math.fround(row[k]);
        result[offset] = hi;
        result[offset + 1] = row[k] - hi;
      }
    });
    else rows.forEach((row, i) => result.set(row, i * row.length));
    return result;
  };
  const packSource = (source) => {
    const codes = new Uint32Array(Math.ceil(source.codes.length / 2));
    const items = source.codes.length / source.nRows;
    for (let i = 0; i < source.codes.length; i++) {
      const at2 = loading === "respondent" ? i % source.nRows * items + Math.floor(i / source.nRows) : i;
      codes[at2 >>> 1] |= (source.observed[i] ? source.codes[i] : 65535) << (at2 & 1) * 16;
    }
    const meta = new Uint32Array(source.pairs.length * 4);
    const lookup = new Float32Array(source.pairs.reduce((sum, pair) => sum + pair.values.length, 0) * 2);
    let at = 0;
    source.pairs.forEach((pair, i) => {
      meta.set([pair.i * (loading === "respondent" ? 1 : source.nRows), pair.j * (loading === "respondent" ? 1 : source.nRows), pair.columns, at / 2], 4 * i);
      for (const value of pair.values) {
        const scaled = value * source.rootWeights[i], hi = Math.fround(scaled);
        lookup[at++] = hi;
        lookup[at++] = scaled - hi;
      }
    });
    return [codes, meta, lookup, pack(source.projection)];
  };
  return {
    metadata: { backend: "webgpu", loading, dotChunkSize, materializePanels, preSplit, precision: split ? `${portable ? "explicit-rounding-dekker-" : compensatedSplit ? "compensated-" : ""}split-f32/${reduce ? "gpu-pair-reduction/host-f64" : "chunked-host-f64"}` : compensated ? "f32-compensated/host-f64" : "f32/host-f64", strictMathRequested: strictMath ?? null, strictMathRecognized, developerOnly: strictMath === true, transport: resident ? "Resident ordinal source and projections; per-block row ranges only" : "Expanded block inputs uploaded per call", ownedGpuBufferBudgetBytes: 1024 ** 3, adapter: { vendor: adapter.info.vendor, architecture: adapter.info.architecture, device: adapter.info.device, description: adapter.info.description }, timestamps, shader: code, panelShader: materializePanels ? panelShader : void 0, reductionShader: reduce ? reductionCode : void 0 },
    timings,
    setDispatchObserver(observer) {
      dispatchObserver = observer;
    },
    async run(block) {
      if (lost || signal?.aborted) throw new Error(lost || "Cancelled");
      const start = performance.now();
      if (resident && !block.ordinal) throw new Error("Resident GPU kernel requires an ordinal source");
      const ordinal = block.ordinal;
      const shape = resident ? new Uint32Array([ordinal.leftRows, ordinal.rightRows, ordinal.source.pairs.length, ordinal.source.projection[0].length, ordinal.leftStart, ordinal.rightStart, 0, ordinal.source.codes.length / ordinal.source.nRows]) : new Uint32Array([block.left.length, block.right.length, block.left[0].length, block.leftProjection[0].length, ...portable ? [0, 0, 0, 0] : []]);
      const chunks = split ? Math.ceil(Math.max(shape[2], shape[3]) / dotChunkSize) : 1;
      const outputBytes = shape[0] * shape[1] * 4 * chunks * (split ? 4 : 1);
      const panelSizes = materializePanels ? [shape[0] * shape[2] * 8, shape[1] * shape[2] * 8] : [];
      const panelOwned = panelSizes.reduce((sum, size, i) => sum + Math.max(size, panelCapacities[i]), 0) + panelShapes.length * 16;
      const reducedBytes = reduce ? shape[0] * shape[1] * 16 : 0;
      const readBytes = reduce ? reducedBytes : outputBytes;
      if (resident) {
        const source = ordinal.source;
        if (currentSource !== source) sourceByteEstimate = Math.ceil(source.codes.length / 2) * 4 + source.pairs.length * 16 + source.pairs.reduce((sum, pair) => sum + pair.values.length * 8, 0) + source.nRows * shape[3] * 8;
        const estimate = sourceByteEstimate + outputBytes + readBytes + reducedBytes + panelOwned + 128;
        if (estimate > 1024 ** 3) throw new Error("Resident GPU source and blocks exceed the explicit 1 GiB device-buffer budget");
      }
      const inputs = resident ? currentSource === ordinal.source ? void 0 : packSource(ordinal.source) : [pack(block.left), pack(block.right), pack(block.leftProjection), pack(block.rightProjection)];
      if (inputs) sourceSizes = inputs.map((v) => v.byteLength);
      timings.packMs += performance.now() - start;
      const sizes = [...sourceSizes, outputBytes, shape.byteLength];
      if ([...sizes, ...panelSizes].some((size) => size > device.limits.maxStorageBufferBindingSize)) throw new Error("Block exceeds GPU storage-buffer limit");
      const retainedBytes = panelOwned + sizes.reduce((sum, size, i) => sum + Math.max(size, capacities[i] ?? 0), 0) + Math.max(readSize, readBytes) + Math.max(reducedCapacity, reducedBytes) + (query ? queryBytes * 2 : 0) + (reduce ? 16 : 0);
      if (retainedBytes > 1024 ** 3) throw new Error("Retained GPU buffers exceed the explicit 1 GiB device-buffer budget");
      const beforeUpload = performance.now();
      panelSizes.forEach((size, i) => {
        if (panelCapacities[i] >= size) return;
        dotBinding = void 0;
        panels[i]?.destroy();
        panelRanges[i] = void 0;
        panelCapacities[i] = size;
        panels[i] = device.createBuffer({ size, usage: GPUBufferUsage.STORAGE });
      });
      sizes.forEach((size, i) => {
        if ((capacities[i] ?? 0) >= size) return;
        dotBinding = void 0;
        reductionBinding = void 0;
        buffers[i]?.destroy();
        capacities[i] = size;
        buffers[i] = device.createBuffer({ size, usage: i === 5 ? GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST : GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC });
      });
      if (readSize < readBytes) {
        read?.destroy();
        readSize = readBytes;
        read = device.createBuffer({ size: readSize, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST });
      }
      if (reduce && reducedCapacity < reducedBytes) {
        reductionBinding = void 0;
        reduced?.destroy();
        reducedCapacity = reducedBytes;
        reduced = device.createBuffer({ size: reducedCapacity, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC });
      }
      inputs?.forEach((input, i) => device.queue.writeBuffer(buffers[i], 0, input));
      if (materializePanels && inputs) panelRanges.length = 0;
      if (resident && inputs) {
        currentSource = ordinal.source;
        timings.sourceInitializations++;
      }
      device.queue.writeBuffer(buffers[5], 0, shape);
      const outputs = shape[0] * shape[1];
      const reductionRows = Math.ceil(outputs / device.limits.maxComputeWorkgroupsPerDimension);
      const reductionWidth = Math.ceil(outputs / reductionRows);
      if (reduce) device.queue.writeBuffer(reductionShape, 0, new Uint32Array([shape[0] * shape[1], chunks, 0, reductionWidth]));
      const dotBuffers = materializePanels ? [panels[0], panels[1], buffers[3], buffers[3], buffers[4], buffers[5]] : buffers;
      const dotSizes = materializePanels ? [panelSizes[0], panelSizes[1], sizes[3], sizes[3], sizes[4], sizes[5]] : sizes;
      const bindingKey = dotSizes.join(":");
      if (!dotBinding || dotBindingKey !== bindingKey) {
        dotBinding = device.createBindGroup({ layout: pipeline.getBindGroupLayout(0), entries: dotBuffers.map((buffer, binding) => ({ binding, resource: { buffer, size: dotSizes[binding] } })) });
        dotBindingKey = bindingKey;
      } else timings.bindGroupCacheHits++;
      const bindGroup = dotBinding;
      device.pushErrorScope("validation");
      const encoder = device.createCommandEncoder();
      if (materializePanels) {
        const expansion = encoder.beginComputePass(query ? { timestampWrites: { querySet: query, beginningOfPassWriteIndex: 4, endOfPassWriteIndex: 5 } } : {});
        expansion.setPipeline(panelPipeline);
        for (let i = 0; i < 2; i++) {
          const rows = shape[i], start2 = shape[4 + i], key = `${start2}:${rows}`;
          if (panelRanges[i] === key) {
            timings.panelCacheHits++;
            continue;
          }
          const groups = Math.ceil(rows * shape[2] / 256);
          if (groups > device.limits.maxComputeWorkgroupsPerDimension) throw new Error("Panel expansion exceeds dispatch limits");
          device.queue.writeBuffer(panelShapes[i], 0, new Uint32Array([rows, start2, shape[2], 0]));
          const expansionBuffers = [buffers[0], buffers[1], buffers[2], panels[i], panelShapes[i]];
          const expansionSizes = [sizes[0], sizes[1], sizes[2], panelSizes[i], 16];
          expansion.setBindGroup(0, device.createBindGroup({ layout: panelPipeline.getBindGroupLayout(0), entries: expansionBuffers.map((buffer, binding) => ({ binding, resource: { buffer, size: expansionSizes[binding] } })) }));
          expansion.dispatchWorkgroups(groups);
          panelRanges[i] = key;
          timings.panelExpansions++;
        }
        expansion.end();
      }
      const pass = encoder.beginComputePass(query ? { timestampWrites: { querySet: query, beginningOfPassWriteIndex: 0, endOfPassWriteIndex: 1 } } : {});
      pass.setPipeline(pipeline);
      pass.setBindGroup(0, bindGroup);
      pass.dispatchWorkgroups(Math.ceil(shape[1] / 16), Math.ceil(shape[0] / 16), chunks);
      pass.end();
      if (reduce) {
        const key = `${outputBytes}:${reducedBytes}`;
        if (!reductionBinding || reductionBindingKey !== key) {
          reductionBinding = device.createBindGroup({ layout: reductionPipeline.getBindGroupLayout(0), entries: [
            { binding: 0, resource: { buffer: buffers[4], size: outputBytes } },
            { binding: 1, resource: { buffer: reduced, size: reducedBytes } },
            { binding: 2, resource: { buffer: reductionShape } }
          ] });
          reductionBindingKey = key;
        } else timings.bindGroupCacheHits++;
        const bindings = reductionBinding;
        const reduction = encoder.beginComputePass(query ? { timestampWrites: { querySet: query, beginningOfPassWriteIndex: 2, endOfPassWriteIndex: 3 } } : {});
        reduction.setPipeline(reductionPipeline);
        reduction.setBindGroup(0, bindings);
        reduction.dispatchWorkgroups(reductionWidth, Math.ceil(shape[0] * shape[1] / reductionWidth));
        reduction.end();
      }
      encoder.copyBufferToBuffer(reduce ? reduced : buffers[4], 0, read, 0, readBytes);
      if (query) {
        encoder.resolveQuerySet(query, 0, queryCount, queryResolve, 0);
        encoder.copyBufferToBuffer(queryResolve, 0, queryRead, 0, queryBytes);
      }
      device.queue.submit([encoder.finish()]);
      dispatchObserver?.();
      timings.uploadSubmitMs += performance.now() - beforeUpload;
      const beforeRead = performance.now();
      await read.mapAsync(GPUMapMode.READ);
      timings.readMapWaitMs += performance.now() - beforeRead;
      const beforeReduce = performance.now();
      const partials = new Float32Array(read.getMappedRange(0, readBytes));
      const output = new Float64Array(shape[0] * shape[1]);
      if (reduce) for (let i = 0; i < output.length; i++) output[i] = partials[4 * i] + partials[4 * i + 1] - (partials[4 * i + 2] + partials[4 * i + 3]);
      else if (split) for (let i = 0; i < output.length; i++) {
        let a = 0, z = 0;
        for (let c = 0; c < chunks; c++) {
          const offset = 4 * (i * chunks + c);
          a += partials[offset] + partials[offset + 1];
          z += partials[offset + 2] + partials[offset + 3];
        }
        output[i] = a - z;
      }
      else output.set(partials);
      read.unmap();
      timings.hostReductionMs += performance.now() - beforeReduce;
      if (queryRead) {
        await queryRead.mapAsync(GPUMapMode.READ);
        const times = new BigUint64Array(queryRead.getMappedRange());
        timings.gpuMs += Number(times[1] - times[0]) / 1e6;
        if (reduce) {
          const elapsed = Number(times[3] - times[2]) / 1e6;
          timings.reductionGpuMs += elapsed;
          timings.gpuMs += elapsed;
        }
        if (materializePanels) {
          const elapsed = Number(times[5] - times[4]) / 1e6;
          timings.panelGpuMs += elapsed;
          timings.gpuMs += elapsed;
        }
        queryRead.unmap();
      }
      const error = await device.popErrorScope();
      if (error || lost || signal?.aborted) throw new Error(error?.message || lost || "Cancelled");
      timings.dispatchReadbackMs += performance.now() - beforeRead;
      timings.calls++;
      timings.uploadedBytes += (inputs?.reduce((sum, v) => sum + v.byteLength, 0) ?? 0) + shape.byteLength + (reduce ? 16 : 0);
      timings.readbackBytes += readBytes;
      timings.peakOwnedGpuBufferBytes = Math.max(timings.peakOwnedGpuBufferBytes, panelOwned + capacities.reduce((a, b) => a + b, 0) + readSize + reducedCapacity + (query ? queryBytes * 2 : 0) + (reduce ? 16 : 0));
      return output;
    },
    destroy() {
      signal?.removeEventListener("abort", abort);
      panels.forEach((buffer) => buffer.destroy());
      panelShapes.forEach((buffer) => buffer.destroy());
      buffers.forEach((buffer) => buffer.destroy());
      read?.destroy();
      reduced?.destroy();
      reductionShape?.destroy();
      query?.destroy();
      queryResolve?.destroy();
      queryRead?.destroy();
      device.destroy();
    }
  };
}

// src/lib/efa/backends/native-protocol.ts
function encodeOrdinalRange(block) {
  if (!block.ordinal) throw new Error("Resident kernel requires an ordinal source");
  const { leftStart, rightStart, leftRows, rightRows } = block.ordinal;
  const bytes = new ArrayBuffer(20), view = new DataView(bytes);
  [1162232115, leftStart, rightStart, leftRows, rightRows].forEach((v, i) => view.setUint32(i * 4, v, true));
  return bytes;
}
var SOURCE_CHUNK_BYTES = 4 * 1024 ** 2;
function ordinalSourceSize(source) {
  const lookups = source.pairs.reduce((sum, pair) => sum + pair.values.length, 0);
  const size = 24 + source.codes.length * 2 + source.pairs.length * 16 + lookups * 8 + source.nRows * source.projection[0].length * 8;
  if (size > 512 * 1024 ** 2) throw new Error("Resident source exceeds the explicit 512 MiB transfer budget");
  return size;
}
function* ordinalSourceChunks(source, chunkBytes = SOURCE_CHUNK_BYTES) {
  ordinalSourceSize(source);
  if (!Number.isSafeInteger(chunkBytes) || chunkBytes < 24 || chunkBytes % 16 || chunkBytes > SOURCE_CHUNK_BYTES) throw new Error("Invalid source chunk size");
  const header = new ArrayBuffer(24), h = new DataView(header);
  [1162232114, source.nRows, source.codes.length, source.pairs.length, source.projection[0].length, source.pairs.reduce((sum, pair) => sum + pair.values.length, 0)].forEach((v, i) => h.setUint32(i * 4, v, true));
  yield header;
  for (let start = 0; start < source.codes.length; start += chunkBytes / 2) {
    const count = Math.min(chunkBytes / 2, source.codes.length - start), bytes2 = new ArrayBuffer(count * 2), view2 = new DataView(bytes2);
    for (let i = 0; i < count; i++) view2.setUint16(i * 2, source.observed[start + i] ? source.codes[start + i] : 65535, true);
    yield bytes2;
  }
  let lookup = 0;
  for (let start = 0; start < source.pairs.length; start += chunkBytes / 16) {
    const count = Math.min(chunkBytes / 16, source.pairs.length - start), bytes2 = new ArrayBuffer(count * 16), view2 = new DataView(bytes2);
    for (let i = 0; i < count; i++) {
      const pair = source.pairs[start + i];
      [pair.i * source.nRows, pair.j * source.nRows, pair.columns, lookup].forEach((v, j) => view2.setUint32(i * 16 + j * 4, v, true));
      lookup += pair.values.length;
    }
    yield bytes2;
  }
  let bytes = new ArrayBuffer(chunkBytes), view = new DataView(bytes), at = 0;
  for (let i = 0; i < source.pairs.length; i++) for (const value of source.pairs[i].values) {
    view.setFloat64(at, value * source.rootWeights[i], true);
    at += 8;
    if (at === chunkBytes) {
      yield bytes;
      bytes = new ArrayBuffer(chunkBytes);
      view = new DataView(bytes);
      at = 0;
    }
  }
  for (const row of source.projection) for (const value of row) {
    view.setFloat64(at, value, true);
    at += 8;
    if (at === chunkBytes) {
      yield bytes;
      bytes = new ArrayBuffer(chunkBytes);
      view = new DataView(bytes);
      at = 0;
    }
  }
  if (at) yield bytes.slice(0, at);
}

// src/lib/efa/types.ts
var EfaError = class extends Error {
  constructor(code, message, diagnostics = []) {
    super(message);
    this.code = code;
    this.diagnostics = diagnostics;
    this.name = "EfaError";
  }
};
var EFA_ENGINE = "scatter-efa/7";

// src/lib/efa/backends/types.ts
function computeSettings(spec) {
  if (spec.compute !== void 0 && (!spec.compute || typeof spec.compute !== "object" || Array.isArray(spec.compute) || Object.keys(spec.compute).some((key) => !["backend", "blockSize", "memoryMiB"].includes(key)) || !spec.compute.backend))
    throw new EfaError("backend-settings", "Compute settings accept only backend, blockSize and memoryMiB. Pairing is session-only.");
  const settings = spec.compute, backend = settings?.backend ?? "cpu";
  if (!["cpu", "webgpu", "scala"].includes(backend)) throw new EfaError("backend", "Unknown EFA compute backend.");
  if (backend !== "cpu" && spec.extraction !== "wlsmv") throw new EfaError("backend-method", "WebGPU and Scala accelerate WLSMV trace corrections. Select WLSMV or Browser CPU.");
  if (settings?.blockSize !== void 0 && ![32, 64, 128, 256].includes(settings.blockSize) || settings?.memoryMiB !== void 0 && !Number.isInteger(settings.memoryMiB))
    throw new EfaError("backend-budget", "Use integer block and memory settings.");
  const blockSize = settings?.blockSize ?? (backend === "scala" ? 256 : backend === "webgpu" ? 128 : 32);
  const memoryMiB = settings?.memoryMiB ?? (backend === "cpu" ? 1024 : 1536);
  if (![32, 64, 128, 256].includes(blockSize) || !Number.isInteger(memoryMiB) || memoryMiB < 256 || memoryMiB > 4096)
    throw new EfaError("backend-budget", "Choose a supported block size and a memory budget between 256 and 4096 MiB.");
  return { backend, blockSize, budgetBytes: memoryMiB * 1024 ** 2, ...backend === "cpu" ? {} : { space: "cases" } };
}
var NATIVE_KERNEL_SHA = "21136cac2832c38efd222afa1da3d4828427590785dca5d270f00543c5554ed9";

// src/lib/efa/backends/companion.ts
function validateConnection(connection) {
  let url;
  try {
    url = new URL(connection.url);
  } catch {
    throw new EfaError("companion", "Enter the local companion URL and pairing token.");
  }
  if (url.protocol !== "http:" || url.hostname !== "127.0.0.1" || !url.port || url.username || url.password || url.pathname !== "/" || url.search || url.hash || !/^[a-f0-9]{64}$/.test(connection.token))
    throw new EfaError("companion", "The companion must use http://127.0.0.1:PORT and its 64-character pairing token.");
  return { url: url.origin, token: connection.token };
}
async function companionRequest(connection, path, method = "GET", body, timeoutMs = 3e4) {
  const verified = validateConnection(connection);
  try {
    const response = await fetch(verified.url + path, {
      method,
      body,
      redirect: "error",
      credentials: "omit",
      cache: "no-store",
      headers: { Authorization: `Bearer ${verified.token}`, ...body ? { "Content-Type": "application/octet-stream" } : {} },
      signal: AbortSignal.timeout(timeoutMs)
    });
    if (!response.ok) {
      const detail = {
        401: "The pairing token was rejected. Reconnect using the token from the running companion.",
        403: "The companion rejected this workbench origin. Restart it with the exact --origin shown in setup.",
        409: "The companion is busy or this session was stopped. Wait for process cleanup and rerun explicitly.",
        413: "The request exceeds the companion transport limits.",
        422: "The companion rejected a source or block, or its native process failed. This run was stopped.",
        503: "The Scala JVM could not start with native BLAS. Check Java and the companion's native BLAS installation."
      };
      throw new EfaError("companion-unavailable", detail[response.status] ?? "The companion request failed. Check the local process and rerun explicitly.");
    }
    return response;
  } catch (error) {
    if (error instanceof EfaError) throw error;
    throw new EfaError("companion-unavailable", "Local Scala companion request failed. Check pairing, allowed origin, browser local-network permission and the companion process. No backend substitution was made.");
  }
}

// src/lib/efa/trace-kernel.ts
function cpuTraceBlock(block) {
  const { left, right, leftProjection, rightProjection, diagonal } = block;
  const output = new Float64Array(left.length * right.length);
  for (let a = 0; a < left.length; a++)
    for (let b = 0; b < right.length; b++) {
      if (diagonal && b > a) continue;
      let h = 0, correction = 0;
      for (let pair = 0; pair < left[a].length; pair++) {
        const term = left[a][pair] * right[b][pair] - correction, sum = h + term;
        correction = sum - h - term;
        h = sum;
      }
      for (let v = 0; v < leftProjection[a].length; v++)
        h -= leftProjection[a][v] * rightProjection[b][v];
      output[a * right.length + b] = h;
    }
  return output;
}

// src/lib/efa/backends/self-check.ts
function checkSource(items, rows) {
  const codes = new Uint16Array(items * rows), observed = new Uint8Array(codes.length);
  for (let j = 0; j < items; j++) for (let r = 0; r < rows; r++) {
    codes[j * rows + r] = (r * 7 + j * 3 + Math.floor(r / 3)) % (2 + j % 4);
    observed[j * rows + r] = (r * 11 + j) % 17 ? 1 : 0;
  }
  const pairs = [];
  for (let i = 0; i < items; i++) for (let j = i + 1; j < items; j++) pairs.push({
    i,
    j,
    n: rows,
    columns: 2 + j % 4,
    variance: 1,
    values: Float64Array.from({ length: (2 + i % 4) * (2 + j % 4) }, (_, c) => Math.sin(c + i * 0.4 - j) * (1 + (i + j) % 7))
  });
  return {
    nRows: rows,
    codes,
    observed,
    pairs,
    rootWeights: Float64Array.from(pairs, (_, i) => 0.2 + i % 13 / 7),
    projection: Array.from({ length: rows }, (_, r) => Float64Array.from({ length: 11 }, (_2, q) => Math.cos(r * 0.3 + q) * 3))
  };
}
function checkBlock(source, leftStart, rightStart, leftRows, rightRows) {
  const panel = (start, rows) => Array.from({ length: rows }, (_, r) => Float64Array.from(source.pairs, (pair, index) => {
    const a = pair.i * source.nRows + start + r, b = pair.j * source.nRows + start + r;
    return source.observed[a] && source.observed[b] ? pair.values[source.codes[a] * pair.columns + source.codes[b]] * source.rootWeights[index] : 0;
  }));
  return {
    left: panel(leftStart, leftRows),
    right: panel(rightStart, rightRows),
    leftProjection: source.projection.slice(leftStart, leftStart + leftRows),
    rightProjection: source.projection.slice(rightStart, rightStart + rightRows),
    diagonal: leftStart === rightStart,
    ordinal: { source, leftStart, rightStart, leftRows, rightRows }
  };
}
async function numericalSelfCheck(kernel, blockSize, progress) {
  const start = performance.now(), wide = checkSource(64, 19), tall = checkSource(8, blockSize + 3);
  const blocks = [
    checkBlock(wide, 0, 0, 17, 17),
    checkBlock(wide, 3, 1, 16, 9),
    checkBlock(tall, 0, 0, blockSize, blockSize),
    checkBlock(tall, 3, 0, blockSize, blockSize),
    checkBlock(tall, blockSize, 1, 3, 7)
  ];
  let maxScaledError = 0, checks = 0;
  for (const block of blocks) {
    const expected = cpuTraceBlock(block), actual = await kernel(block);
    if (actual.length !== expected.length) throw new EfaError("backend-self-check", "Backend self-check failed: wrong output shape. No analysis was run on this backend.");
    for (let i = 0; i < expected.length; i++) {
      if (block.diagonal && i % block.right.length > Math.floor(i / block.right.length)) continue;
      const error = Math.abs(actual[i] - expected[i]) / Math.max(1, Math.abs(expected[i]));
      if (!Number.isFinite(error) || error > 1e-10) throw new EfaError("backend-self-check", "Backend self-check failed the 1e-10 numerical tolerance. No analysis was run on this backend.");
      maxScaledError = Math.max(maxScaledError, error);
      checks++;
    }
    progress?.(blocks.indexOf(block) + 1, blocks.length);
  }
  return { version: "ordinal-trace/1", passed: true, checks, tolerance: 1e-10, maxScaledError, elapsedMs: performance.now() - start };
}

// src/lib/efa/backends/runtime.ts
async function createBackend(spec, session, publish, progress) {
  const settings = computeSettings(spec);
  let destroy = () => {
  };
  const execution2 = { backend: settings.backend, blockSize: settings.blockSize, budgetBytes: settings.budgetBytes, state: "initializing", precision: settings.backend === "scala" ? "float64 / native BLAS" : "portable split-f32 / host-f64", kernelVersion: "ordinal-trace/1" };
  const emit = () => publish(structuredClone(execution2));
  emit();
  try {
    let kernel;
    if (settings.backend === "webgpu") {
      const gpu = await createGpuKernel({ split: true, resident: true, portable: true, reduce: true, dotChunkSize: 1024 });
      destroy = () => gpu.destroy();
      execution2.precision = gpu.metadata.precision;
      execution2.adapter = Object.values(gpu.metadata.adapter).join(" / ").slice(0, 400);
      execution2.kernelSha256 = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(gpu.metadata.shader + (gpu.metadata.reductionShader ?? ""))))).map((v) => v.toString(16).padStart(2, "0")).join("");
      execution2.timings = gpu.timings;
      kernel = (block) => gpu.run(block);
    } else if (settings.backend === "scala" && session) {
      let resident;
      const timings = { packMs: 0, roundTripMs: 0, nativeMs: 0, materializeMs: 0, blasMs: 0, calls: 0, sentBytes: 0 };
      execution2.kernelSha256 = NATIVE_KERNEL_SHA;
      const identity = await (await companionRequest(session, `/v1/jobs/${session.id}`)).json();
      execution2.runtime = String(identity.runtime).slice(0, 400);
      execution2.timings = timings;
      const request = async (path, body) => {
        const at = performance.now();
        const reply = await (await companionRequest(session, `/v1/jobs/${session.id}/${path}`, "POST", body, 12e4)).arrayBuffer();
        timings.roundTripMs += performance.now() - at;
        timings.sentBytes += body.byteLength;
        return reply;
      };
      kernel = async (block) => {
        if (!block.ordinal) throw new Error("Missing ordinal block");
        if (resident !== block.ordinal.source) {
          const source = block.ordinal.source, size = ordinalSourceSize(source);
          const header = new ArrayBuffer(4);
          new DataView(header).setUint32(0, size, true);
          await request("source-start", header);
          let offset = 0;
          const chunks = ordinalSourceChunks(source);
          while (true) {
            const at = performance.now(), chunk = chunks.next();
            if (chunk.done) break;
            const packet = new Uint8Array(chunk.value.byteLength + 4);
            new DataView(packet.buffer).setUint32(0, offset, true);
            packet.set(new Uint8Array(chunk.value), 4);
            timings.packMs += performance.now() - at;
            await request("source-chunk", packet.buffer);
            offset += chunk.value.byteLength;
            if (execution2.state !== "self-check") progress({ stage: "Scala resident source upload", completed: offset, total: size });
          }
          await request("source-finish", new ArrayBuffer(4));
          resident = source;
        }
        const reply = await request("block", encodeOrdinalRange(block));
        const count = block.ordinal.leftRows * block.ordinal.rightRows;
        if (reply.byteLength !== 24 + count * 8) throw new Error("Invalid native result");
        const view = new DataView(reply), out = new Float64Array(count);
        timings.nativeMs += view.getFloat64(0, true);
        timings.materializeMs += view.getFloat64(8, true);
        timings.blasMs += view.getFloat64(16, true);
        timings.calls++;
        for (let i = 0; i < count; i++) out[i] = view.getFloat64(24 + i * 8, true);
        return out;
      };
    } else throw new EfaError("companion-unavailable", "Connect the Scala companion before running this analysis.");
    execution2.state = "self-check";
    emit();
    execution2.selfCheck = await numericalSelfCheck(kernel, settings.blockSize, (completed, total) => progress({ stage: "Backend numerical self-check", completed, total }));
    execution2.state = "ready";
    emit();
    let last = 0;
    return {
      async run(block) {
        try {
          execution2.state = "running";
          const result = await kernel(block);
          if (result.length !== block.ordinal.leftRows * block.ordinal.rightRows || result.some((v) => !Number.isFinite(v))) throw new Error("Invalid backend result");
          if (performance.now() - last > 500) {
            emit();
            last = performance.now();
          }
          return result;
        } catch {
          execution2.state = "failed";
          execution2.failure = "backend-computation";
          emit();
          throw new EfaError("backend-computation", "The selected backend failed during trace computation. No result was published. Check the companion or GPU availability and rerun explicitly.");
        }
      },
      finish() {
        execution2.state = "completed";
        emit();
        return structuredClone(execution2);
      },
      destroy
    };
  } catch (error) {
    destroy();
    execution2.state = "failed";
    execution2.failure = error instanceof EfaError ? error.code : "backend-initialization";
    emit();
    if (error instanceof EfaError) throw error;
    throw new EfaError("backend-initialization", "The selected backend could not initialize. WebGPU requires a supported browser, device and secure origin. Scala requires a paired local companion. No fallback was used.");
  }
}

// node_modules/ml-matrix/matrix.mjs
var matrix = __toESM(require_matrix(), 1);
var CholeskyDecomposition2 = matrix.CholeskyDecomposition;
var EigenvalueDecomposition2 = matrix.EigenvalueDecomposition;
var Matrix2 = matrix.Matrix;
var QrDecomposition2 = matrix.QrDecomposition;
var SingularValueDecomposition2 = matrix.SingularValueDecomposition;
var WrapperMatrix2D2 = matrix.WrapperMatrix2D;
var matrix_default = matrix.default.Matrix ? matrix.default.Matrix : matrix.Matrix;
var inverse2 = matrix.inverse;
var solve2 = matrix.solve;

// src/lib/efa/weighted-linalg.ts
function projectCases(data, moments, identified, progress, tileRows = 32) {
  if (!Number.isSafeInteger(tileRows) || tileRows < 1 || tileRows > 256)
    throw new EfaError("weighted-budget", "Invalid case projection tile size.");
  const n = data.nRows, q = identified.free.length, k = identified.loadings[0].length, pairs = moments.pairs, starts = new Uint32Array(pairs.length + 1);
  let count = 0;
  for (let a = 0; a < pairs.length; a++) {
    starts[a] = count;
    const { i, j } = pairs[a];
    for (let f = 0; f < k; f++) {
      if (identified.index[i][f] >= 0) count++;
      if (identified.index[j][f] >= 0) count++;
    }
  }
  starts[pairs.length] = count;
  const indices = new Uint32Array(count), values = new Float64Array(count);
  let at = 0;
  for (const { i, j } of pairs) {
    for (let f = 0; f < k; f++) {
      if (identified.index[i][f] >= 0) {
        indices[at] = identified.index[i][f];
        values[at++] = identified.loadings[j][f];
      }
      if (identified.index[j][f] >= 0) {
        indices[at] = identified.index[j][f];
        values[at++] = identified.loadings[i][f];
      }
    }
  }
  const z = Array.from({ length: n }, () => new Float64Array(q));
  const { codes, observed } = data;
  progress?.({ stage: "Robust case projections", completed: 0, total: n });
  for (let start = 0; start < n; start += tileRows) {
    const end = Math.min(n, start + tileRows);
    for (let a = 0; a < pairs.length; a++) {
      const pair = pairs[a], xOffset = pair.i * n, yOffset = pair.j * n, columns = pair.columns, lookup = pair.values, w = moments.weights[a], first = starts[a], last = starts[a + 1];
      for (let row = start; row < end; row++) {
        if (!observed[xOffset + row] || !observed[yOffset + row]) continue;
        const s = lookup[codes[xOffset + row] * columns + codes[yOffset + row]] * w;
        if (s) {
          const target = z[row];
          for (let entry = first; entry < last; entry++) target[indices[entry]] += s * values[entry];
        }
      }
    }
    progress?.({ stage: "Robust case projections", completed: end, total: n });
  }
  return z;
}
function normalizeCaseProjections(z, lower, progress) {
  const q = lower.rows, n = z.length, rootN = Math.sqrt(n), rows = Array.from({ length: q }, (_, a) => Float64Array.from(lower.getRow(a))), meat = Array.from({ length: q }, () => new Float64Array(q));
  progress?.({ stage: "Robust parameter covariance", completed: 0, total: n });
  for (let row = 0; row < n; row++) {
    const v = z[row];
    for (let a = 0; a < q; a++) {
      const coefficients = rows[a];
      let x = v[a];
      for (let b = 0; b < a; b++) x -= coefficients[b] * v[b];
      v[a] = x / coefficients[a];
    }
    for (let a = 0; a < q; a++) v[a] /= rootN;
    for (let a = 0; a < q; a++) {
      const target = meat[a], va = v[a];
      for (let b = 0; b <= a; b++) target[b] += va * v[b];
    }
    if ((row + 1) % 32 === 0 || row + 1 === n)
      progress?.({ stage: "Robust parameter covariance", completed: row + 1, total: n });
  }
  for (let a = 0; a < q; a++)
    for (let b = 0; b < a; b++) meat[b][a] = meat[a][b];
  const inverse3 = Array.from({ length: q }, () => new Float64Array(q));
  progress?.({ stage: "Covariance inverse transform", completed: 0, total: q });
  for (let a = 0; a < q; a++) {
    const target = inverse3[a], coefficients = rows[a];
    target[a] = 1;
    for (let b = 0; b < a; b++) {
      const coefficient = coefficients[b], previous = inverse3[b];
      for (let c = 0; c <= b; c++) target[c] -= coefficient * previous[c];
    }
    for (let c = 0; c <= a; c++) target[c] /= coefficients[a];
    if ((a + 1) % 16 === 0 || a + 1 === q)
      progress?.({ stage: "Covariance inverse transform", completed: a + 1, total: q });
  }
  return { meat: new WrapperMatrix2D2(meat), inverseLower: new WrapperMatrix2D2(inverse3) };
}
function covarianceQuadraticForms(covariance2, derivatives, progress) {
  const q = covariance2.rows;
  if (covariance2.columns !== q || derivatives.some((row) => row.length !== q))
    throw new EfaError("weighted-covariance", "Covariance propagation dimensions differ.");
  const packed = new Float64Array(q * (q + 1) / 2), offsets = new Uint32Array(q);
  let at = 0;
  for (let a = 0; a < q; a++) {
    offsets[a] = at;
    for (let b = 0; b <= a; b++) {
      const value = a === b ? covariance2.get(a, a) : covariance2.get(a, b) + covariance2.get(b, a);
      if (!Number.isFinite(value)) throw new EfaError("weighted-covariance", "Non-finite covariance propagation input.");
      packed[at++] = value;
    }
  }
  const results = new Float64Array(derivatives.length), dense = [];
  let completed = 0;
  const report = () => progress?.({ stage: "Rotated covariance propagation", completed, total: derivatives.length });
  report();
  derivatives.forEach((row, output) => {
    const nonzero = [];
    for (let i = 0; i < q; i++) {
      if (!Number.isFinite(row[i])) throw new EfaError("weighted-covariance", "Non-finite covariance derivative.");
      if (row[i] !== 0) nonzero.push(i);
    }
    if (nonzero.length > q / 4) {
      dense.push(output);
      return;
    }
    let variance = 0;
    for (let a = 0; a < nonzero.length; a++) {
      const i = nonzero[a], offset = offsets[i];
      let v = packed[offset + i] * row[i];
      for (let b = 0; b < a; b++) {
        const j = nonzero[b];
        v += packed[offset + j] * row[j];
      }
      variance += row[i] * v;
    }
    results[output] = variance;
    completed++;
  });
  report();
  const zero = new Float64Array(q);
  for (let output = 0; output < dense.length; output += 4) {
    const d0 = derivatives[dense[output]], d1 = derivatives[dense[output + 1]] ?? zero, d2 = derivatives[dense[output + 2]] ?? zero, d3 = derivatives[dense[output + 3]] ?? zero;
    let s0 = 0, s1 = 0, s2 = 0, s3 = 0;
    for (let a = 0; a < q; a++) {
      const offset = offsets[a], diagonal = packed[offset + a];
      let v0 = diagonal * d0[a], v1 = diagonal * d1[a], v2 = diagonal * d2[a], v3 = diagonal * d3[a];
      for (let b = 0; b < a; b++) {
        const value = packed[offset + b];
        v0 += value * d0[b];
        v1 += value * d1[b];
        v2 += value * d2[b];
        v3 += value * d3[b];
      }
      s0 += d0[a] * v0;
      s1 += d1[a] * v1;
      s2 += d2[a] * v2;
      s3 += d3[a] * v3;
    }
    results[dense[output]] = s0;
    if (output + 1 < dense.length) results[dense[output + 1]] = s1;
    if (output + 2 < dense.length) results[dense[output + 2]] = s2;
    if (output + 3 < dense.length) results[dense[output + 3]] = s3;
    completed += Math.min(4, dense.length - output);
    if (completed % 32 < 4 || completed === derivatives.length) report();
  }
  return results;
}

// src/lib/efa/math.ts
var dot = (a, b) => a.reduce((s, v, i) => s + v * b[i], 0);
var clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
function eigen(a) {
  const e = new EigenvalueDecomposition2(a, { assumeSymmetric: true });
  const order = e.realEigenvalues.map((_, i) => i).sort((i, j) => e.realEigenvalues[j] - e.realEigenvalues[i]);
  return {
    values: order.map((i) => e.realEigenvalues[i]),
    vectors: e.eigenvectorMatrix.subMatrixColumn(order)
  };
}
function normalCDF(x) {
  if (x <= -8.3) return 0;
  if (x >= 8.3) return 1;
  let sum = x, term = x;
  for (let i = 1; i < 200; i++) {
    term *= x * x / (2 * i + 1);
    sum += term;
    if (Math.abs(term) < Math.abs(sum) * 1e-16) break;
  }
  return 0.5 + sum * Math.exp(-x * x / 2) / Math.sqrt(2 * Math.PI);
}
function normalQuantile(p) {
  if (p <= 0) return -Infinity;
  if (p >= 1) return Infinity;
  let lo = -8.3, hi = 8.3;
  for (let i = 0; i < 55; i++) {
    const m = (lo + hi) / 2;
    if (normalCDF(m) < p) lo = m;
    else hi = m;
  }
  return (lo + hi) / 2;
}
function gaussLegendre(n) {
  const x = [], w = [];
  for (let i = 0; i < n; i++) {
    let z = Math.cos(Math.PI * (i + 0.75) / (n + 0.5)), derivative = 0;
    for (let it = 0; it < 30; it++) {
      let p = 1, prev = 0;
      for (let j = 1; j <= n; j++) {
        const next = ((2 * j - 1) * z * p - (j - 1) * prev) / j;
        prev = p;
        p = next;
      }
      derivative = n * (z * p - prev) / (z * z - 1);
      const step = p / derivative;
      z -= step;
      if (Math.abs(step) < 1e-15) break;
    }
    x.push(z);
    w.push(2 / ((1 - z * z) * derivative * derivative));
  }
  return { x, w };
}
var quadrature = gaussLegendre(24);
function bivariateGrid(xs, ys, rho, px, py) {
  const end = Math.asin(rho), segments = Math.abs(rho) > 0.98 ? 8 : Math.abs(rho) > 0.9 ? 3 : 1;
  const nodes = [];
  for (let s = 0; s < segments; s++) {
    const half = end / (2 * segments), mid = (s + 0.5) * end / segments;
    for (let q = 0; q < quadrature.x.length; q++) {
      const angle = mid + half * quadrature.x[q], cos = Math.cos(angle);
      nodes.push({
        sin: Math.sin(angle),
        denominator: 1 / (2 * cos * cos),
        weight: half * quadrature.w[q] / (2 * Math.PI)
      });
    }
  }
  return xs.map(
    (h, i) => ys.map((k, j) => {
      if (h === -Infinity || k === -Infinity) return 0;
      if (h === Infinity) return py[j];
      if (k === Infinity) return px[i];
      const sumSquares = h * h + k * k, twiceProduct = 2 * h * k;
      let probability = px[i] * py[j];
      for (const node of nodes)
        probability += node.weight * Math.exp(-(sumSquares - twiceProduct * node.sin) * node.denominator);
      return clamp(probability, 0, 1);
    })
  );
}
function brent(f, lower, upper, tolerance = Math.pow(Number.EPSILON, 0.25)) {
  const golden = (3 - Math.sqrt(5)) / 2;
  let a = lower, b = upper, x = a + golden * (b - a), w = x, v = x, fx = f(x), fw = fx, fv = fx, d = 0, e = 0;
  for (let iteration = 0; iteration < 200; iteration++) {
    const mid = (a + b) / 2, tol = Math.sqrt(Number.EPSILON) * Math.abs(x) + tolerance / 3;
    if (Math.abs(x - mid) <= 2 * tol - (b - a) / 2)
      return { x, value: fx, iterations: iteration };
    let p = 0, q = 0, r = 0;
    if (Math.abs(e) > tol) {
      r = (x - w) * (fx - fv);
      q = (x - v) * (fx - fw);
      p = (x - v) * q - (x - w) * r;
      q = 2 * (q - r);
      if (q > 0) p = -p;
      else q = -q;
      r = e;
      e = d;
      if (Math.abs(p) < Math.abs(q * r / 2) && p > q * (a - x) && p < q * (b - x)) {
        d = p / q;
        const u2 = x + d;
        if (u2 - a < 2 * tol || b - u2 < 2 * tol) d = x < mid ? tol : -tol;
      } else {
        e = x < mid ? b - x : a - x;
        d = golden * e;
      }
    } else {
      e = x < mid ? b - x : a - x;
      d = golden * e;
    }
    const u = x + (Math.abs(d) >= tol ? d : d > 0 ? tol : -tol), fu = f(u);
    if (fu <= fx) {
      if (u < x) b = x;
      else a = x;
      v = w;
      fv = fw;
      w = x;
      fw = fx;
      x = u;
      fx = fu;
    } else {
      if (u < x) a = u;
      else b = u;
      if (fu <= fw || w === x) {
        v = w;
        fv = fw;
        w = u;
        fw = fu;
      } else if (fu <= fv || v === x || v === w) {
        v = u;
        fv = fu;
      }
    }
  }
  throw new Error("Correlation likelihood did not converge.");
}

// src/lib/efa/weighted-moments.ts
var ORDINAL_UNCERTAINTY_METHOD = "Two-step pair-margin polychoric influence functions; empirical score-product sensitivity; estimated-threshold correction; common eligible-N scale; zero contribution for pair-missing rows; no cell correction";
var density = (x) => Number.isFinite(x) ? Math.exp(-x * x / 2) / Math.sqrt(2 * Math.PI) : 0;
var density2 = (x, y, rho) => Number.isFinite(x) && Number.isFinite(y) ? Math.exp(-(x * x + y * y - 2 * rho * x * y) / (2 * (1 - rho * rho))) / (2 * Math.PI * Math.sqrt(1 - rho * rho)) : 0;
function pairInfluence(data, pair) {
  const {
    i,
    j,
    n,
    rho,
    observedCategoriesX: cx,
    observedCategoriesY: cy
  } = pair, nx = cx.length, ny = cy.length, fullY = data.items[j].categories.length, counts = new Uint32Array(nx * ny), mapX = new Map(cx.map((v, a) => [v, a])), mapY = new Map(cy.map((v, a) => [v, a]));
  let observed = 0;
  for (let row = 0; row < data.nRows; row++) {
    if (!data.observed[i * data.nRows + row] || !data.observed[j * data.nRows + row])
      continue;
    const a = mapX.get(data.codes[i * data.nRows + row]), b = mapY.get(data.codes[j * data.nRows + row]);
    if (a === void 0 || b === void 0)
      throw new EfaError(
        "weighted-snapshot",
        "Pair categories do not match the fitting snapshot."
      );
    counts[a * ny + b]++;
    observed++;
  }
  if (observed !== n || n < 3)
    throw new EfaError(
      "weighted-snapshot",
      "Pair sample size does not match the fitting snapshot."
    );
  if (pair.boundary)
    throw new EfaError(
      "weighted-boundary",
      "A near-boundary polychoric estimate cannot support reliable score-based uncertainty. Review the pair diagnostics."
    );
  const xs = [-Infinity, ...pair.thresholdsX, Infinity], ys = [-Infinity, ...pair.thresholdsY, Infinity], px = xs.map(normalCDF), py = ys.map(normalCDF), grid = bivariateGrid(xs, ys, rho, px, py), root = Math.sqrt(1 - rho * rho), scores = new Float64Array(nx * ny), crossX = new Float64Array(nx - 1), crossY = new Float64Array(ny - 1);
  let information = 0;
  for (let a = 0; a < nx; a++)
    for (let b = 0; b < ny; b++) {
      const cell = a * ny + b, count = counts[cell];
      if (!count) continue;
      const probability = grid[a + 1][b + 1] - grid[a][b + 1] - grid[a + 1][b] + grid[a][b];
      if (!(probability > Math.sqrt(Number.EPSILON)))
        throw new EfaError(
          "weighted-probability",
          "An observed ordinal cell has a probability too small for stable uncertainty estimation. Review sparse categories and pair correlations."
        );
      const score = (density2(xs[a + 1], ys[b + 1], rho) - density2(xs[a], ys[b + 1], rho) - density2(xs[a + 1], ys[b], rho) + density2(xs[a], ys[b], rho)) / probability;
      scores[cell] = score;
      information += count * score * score;
      const bx = (t) => density(t) * (normalCDF((ys[b + 1] - rho * t) / root) - normalCDF((ys[b] - rho * t) / root)) / probability;
      const by = (t) => density(t) * (normalCDF((xs[a + 1] - rho * t) / root) - normalCDF((xs[a] - rho * t) / root)) / probability;
      if (a < nx - 1) crossX[a] += count * score * bx(xs[a + 1]);
      if (a > 0) crossX[a - 1] -= count * score * bx(xs[a]);
      if (b < ny - 1) crossY[b] += count * score * by(ys[b + 1]);
      if (b > 0) crossY[b - 1] -= count * score * by(ys[b]);
    }
  if (!(information > 0) || !Number.isFinite(information))
    throw new EfaError(
      "weighted-information",
      "The pair has singular correlation sensitivity."
    );
  const values = new Float64Array(data.items[i].categories.length * fullY);
  let variance = 0;
  for (let a = 0; a < nx; a++)
    for (let b = 0; b < ny; b++) {
      const cell = a * ny + b;
      if (!counts[cell]) continue;
      let corrected = scores[cell];
      for (let t = 0; t < nx - 1; t++)
        corrected -= crossX[t] / n * ((a <= t ? 1 : 0) - px[t + 1]) / density(xs[t + 1]);
      for (let t = 0; t < ny - 1; t++)
        corrected -= crossY[t] / n * ((b <= t ? 1 : 0) - py[t + 1]) / density(ys[t + 1]);
      const value = data.nRows * corrected / information;
      values[cx[a] * fullY + cy[b]] = value;
      variance += counts[cell] * value * value / data.nRows;
    }
  if (!(variance > 0) || !Number.isFinite(variance))
    throw new EfaError(
      "weighted-variance",
      "The pair has invalid sampling variance."
    );
  return { i, j, n, columns: fullY, values, variance };
}
function weightedMoments(data, correlation2, progress) {
  const pairs = correlation2.pairs.map((pair, index) => {
    const value = pairInfluence(data, pair);
    if (index % 32 === 0 || index + 1 === correlation2.pairs.length)
      progress?.({
        stage: "Ordinal uncertainty",
        completed: index + 1,
        total: correlation2.pairs.length
      });
    return value;
  });
  return {
    pairs,
    weights: Float64Array.from(pairs, (p) => 1 / p.variance),
    nRows: data.nRows,
    method: ORDINAL_UNCERTAINTY_METHOD
  };
}
function influenceAt(data, pair, row) {
  const x = pair.i * data.nRows + row, y = pair.j * data.nRows + row;
  return data.observed[x] && data.observed[y] ? pair.values[data.codes[x] * pair.columns + data.codes[y]] : 0;
}

// src/lib/statTests.ts
var LANCZOS = [
  0.9999999999998099,
  676.5203681218851,
  -1259.1392167224028,
  771.3234287776531,
  -176.6150291621406,
  12.507343278686905,
  -0.13857109526572012,
  9984369578019572e-21,
  15056327351493116e-23
];
var logGamma = (x) => {
  if (x < 0.5) {
    return Math.log(Math.PI / Math.sin(Math.PI * x)) - logGamma(1 - x);
  }
  x -= 1;
  let a = LANCZOS[0];
  const t = x + 7.5;
  for (let i = 1; i < 9; i++) a += LANCZOS[i] / (x + i);
  return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
};
var lowerGammaP = (s, x) => {
  if (x <= 0) return 0;
  if (x < s + 1) {
    let sum = 1 / s, term = sum, a = s;
    for (let i = 0; i < 500; i++) {
      a += 1;
      term *= x / a;
      sum += term;
      if (Math.abs(term) < Math.abs(sum) * 1e-15) break;
    }
    return sum * Math.exp(-x + s * Math.log(x) - logGamma(s));
  }
  const FPMIN = 1e-300;
  let b = x + 1 - s, c = 1 / FPMIN, d = 1 / b, h = d;
  for (let i = 1; i <= 500; i++) {
    const an = -i * (i - s);
    b += 2;
    d = an * d + b;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    c = b + an / c;
    if (Math.abs(c) < FPMIN) c = FPMIN;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 1e-15) break;
  }
  return 1 - Math.exp(-x + s * Math.log(x) - logGamma(s)) * h;
};
var chiSquareSf = (x, df) => Math.min(1, Math.max(0, 1 - lowerGammaP(df / 2, x / 2)));

// src/lib/efa/weighted-inference.ts
function identifyLoadings(loadings) {
  const p = loadings.length, k = loadings[0].length, residual = loadings.map((row) => row.slice()), basis = [], anchors = [];
  for (let f = 0; f < k; f++) {
    let best = -1, norm = 0;
    for (let i = 0; i < p; i++) {
      const s = residual[i].reduce((sum, v2) => sum + v2 * v2, 0);
      if (s > norm) {
        best = i;
        norm = s;
      }
    }
    if (best < 0 || norm < 1e-12)
      throw new EfaError(
        "weighted-rank",
        "The fitted loadings do not have enough independent directions for uncertainty estimation."
      );
    const v = residual[best].map((x) => x / Math.sqrt(norm));
    basis.push(v);
    anchors.push(best);
    for (let i = 0; i < p; i++) {
      const projection = residual[i].reduce((sum, x, j) => sum + x * v[j], 0);
      for (let j = 0; j < k; j++) residual[i][j] -= projection * v[j];
    }
  }
  const canonical = loadings.map(
    (row) => basis.map((v) => row.reduce((sum, x, j) => sum + x * v[j], 0))
  ), index = Array.from({ length: p }, () => Array(k).fill(-1)), free = [];
  for (let i = 0; i < p; i++)
    for (let f = 0; f < k; f++) {
      const anchor = anchors.indexOf(i);
      if (anchor >= 0 && f > anchor) {
        canonical[i][f] = 0;
        continue;
      }
      index[i][f] = free.length;
      free.push([i, f]);
    }
  return { loadings: canonical, anchors, free, index };
}
function planWeightedInference(p, k, n, lookupCells = 25 * p * (p - 1) / 2, options = {}) {
  const m = p * (p - 1) / 2, q = p * k - k * (k - 1) / 2, blockSize = options.blockSize ?? 32, budgetBytes = options.budgetBytes ?? 1024 ** 3;
  if (!Number.isInteger(p) || p < 3 || !Number.isInteger(k) || k < 1 || q > m || !Number.isInteger(n) || n < 3 || !Number.isInteger(blockSize) || blockSize < 1 || blockSize > 256 || !Number.isFinite(budgetBytes) || budgetBytes <= 0)
    throw new EfaError(
      "weighted-budget",
      "Invalid dimensions or memory budget for weighted uncertainty."
    );
  const common = 6 * q * q * 8 + 3 * p * n + 8 * lookupCells + 16 * p * k + 16 * blockSize * m;
  const momentBytes = 1.2 * (common + 8 * (5 * m * m + 4 * m * q)), caseBytes = 1.2 * (common + 8 * n * q + 8 * q * q + 24 * m * k + 4 * (m + 1));
  const space = options.space ?? (m < n && momentBytes <= budgetBytes ? "moments" : "cases"), estimatedBytes = space === "moments" ? momentBytes : caseBytes;
  if (estimatedBytes > budgetBytes)
    throw new EfaError(
      "weighted-budget",
      `Exact WLSMV uncertainty needs an estimated ${Math.ceil(estimatedBytes / 1024 ** 2)} MiB, above the ${Math.floor(budgetBytes / 1024 ** 2)} MiB worker budget. Reduce the item/factor set or run DWLS point fitting explicitly. No method was substituted.`
    );
  return {
    space,
    parameters: q,
    pairs: m,
    rows: n,
    blockSize,
    estimatedBytes,
    budgetBytes,
    approximateMultiplyAdds: space === "moments" ? n * m * m / 2 + 2 * m * m * q + 2 * q * q * m : n * n * (m + q) / 2 + n * q * q + 2 * q * q * q
  };
}
function jacobian(identified, i, j) {
  const entries = [];
  for (let f = 0; f < identified.loadings[0].length; f++) {
    if (identified.index[i][f] >= 0)
      entries.push([identified.index[i][f], identified.loadings[j][f]]);
    if (identified.index[j][f] >= 0)
      entries.push([identified.index[j][f], identified.loadings[i][f]]);
  }
  return entries;
}
function testResult(objective, n, df, trace, traceSquared) {
  if (!Number.isFinite(trace) || !Number.isFinite(traceSquared) || trace < -1e-8 || traceSquared < -1e-8 || df > 0 && !(traceSquared > 0))
    throw new EfaError(
      "weighted-test",
      "The robust test correction is numerically inadmissible."
    );
  const scalingFactor = df > 0 ? Math.sqrt(traceSquared / df) : null, shift = scalingFactor ? df - trace / scalingFactor : null, rawStatistic = (n - 1) * objective;
  return {
    rawStatistic,
    df,
    trace,
    traceSquared,
    scalingFactor,
    shift,
    statistic: scalingFactor ? rawStatistic / scalingFactor + shift : null,
    denominator: n - 1,
    pValue: scalingFactor ? chiSquareSf(rawStatistic / scalingFactor + shift, df) : null
  };
}
function* weightedInferenceSteps(data, moments, loadings, objective, progress, options = {}) {
  const p = loadings.length, k = loadings[0].length, n = data.nRows, m = moments.pairs.length, plan = planWeightedInference(
    p,
    k,
    n,
    moments.pairs.reduce((s, v) => s + v.values.length, 0),
    options
  ), identified = identifyLoadings(loadings), q = identified.free.length, information = Matrix2.zeros(q, q);
  if (m !== plan.pairs || moments.nRows !== n)
    throw new EfaError(
      "weighted-snapshot",
      "Uncertainty moments do not match the fitting snapshot."
    );
  progress?.({ stage: "Weighted information matrix", completed: 0, total: m });
  for (let a = 0; a < m; a++) {
    const { i, j } = moments.pairs[a], entries = jacobian(identified, i, j), w = moments.weights[a];
    for (const [u, x] of entries)
      for (const [v, y] of entries)
        if (u >= v) information.set(u, v, information.get(u, v) + w * x * y);
  }
  progress?.({ stage: "Weighted information matrix", completed: m, total: m });
  progress?.({ stage: "Information factorization", completed: 0, total: 1 });
  for (let a = 0; a < q; a++)
    for (let b = 0; b < a; b++) information.set(b, a, information.get(a, b));
  const cholesky = new CholeskyDecomposition2(information);
  if (!cholesky.isPositiveDefinite())
    throw new EfaError(
      "weighted-information",
      "The identified weighted information is singular. Review the factor count and weak or redundant factors."
    );
  const lower = cholesky.lowerTriangularMatrix, diagonal = lower.diag();
  if (Math.min(...diagonal) / Math.max(...diagonal) < 1e-7)
    throw new EfaError(
      "weighted-information",
      "The identified weighted information is too ill-conditioned for stable uncertainty."
    );
  progress?.({ stage: "Information factorization", completed: 1, total: 1 });
  let covariance2, trace = 0, traceSquared = 0;
  if (plan.space === "moments") {
    const gamma = Matrix2.zeros(m, m), wj = Matrix2.zeros(m, q);
    for (let row = 0; row < n; row++) {
      const scores = moments.pairs.map((pair) => influenceAt(data, pair, row));
      for (let a = 0; a < m; a++)
        for (let b = 0; b <= a; b++)
          gamma.set(a, b, gamma.get(a, b) + scores[a] * scores[b] / n);
      if (row % 128 === 0)
        progress?.({
          stage: "Robust moment covariance",
          completed: row,
          total: n
        });
    }
    for (let a = 0; a < m; a++) {
      for (let b = 0; b < a; b++) gamma.set(b, a, gamma.get(a, b));
      for (const [v, x] of jacobian(
        identified,
        moments.pairs[a].i,
        moments.pairs[a].j
      ))
        wj.set(a, v, moments.weights[a] * x);
    }
    const influence = cholesky.solve(wj.transpose()), u = wj.mmul(influence).neg();
    for (let a = 0; a < m; a++) u.set(a, a, u.get(a, a) + moments.weights[a]);
    covariance2 = influence.mmul(gamma).mmul(influence.transpose()).div(n - 1);
    const product = u.mmul(gamma);
    for (let a = 0; a < m; a++) {
      trace += product.get(a, a);
      for (let b = 0; b < m; b++)
        traceSquared += product.get(a, b) * product.get(b, a);
    }
  } else {
    const z = projectCases(data, moments, identified, progress);
    const { meat, inverseLower } = normalizeCaseProjections(z, lower, progress);
    progress?.({ stage: "Covariance matrix products", completed: 0, total: 2 });
    covariance2 = inverseLower.transpose().mmul(meat);
    progress?.({ stage: "Covariance matrix products", completed: 1, total: 2 });
    covariance2 = covariance2.mmul(inverseLower).div(n - 1);
    progress?.({ stage: "Covariance matrix products", completed: 2, total: 2 });
    const rootWeights = Float64Array.from(moments.weights, (weight) => Math.sqrt(weight / n));
    const source = { nRows: n, codes: data.codes, observed: data.observed, pairs: moments.pairs, rootWeights, projection: z };
    const block = (start) => Array.from(
      { length: Math.min(plan.blockSize, n - start) },
      (_, offset) => Float64Array.from(
        moments.pairs,
        (pair, a) => influenceAt(data, pair, start + offset) * rootWeights[a]
      )
    ), blocks = Math.ceil(n / plan.blockSize), total = blocks * (blocks + 1) / 2;
    let completed = 0;
    progress?.({ stage: "Exact robust trace blocks", completed, total });
    for (let start = 0; start < n; start += plan.blockSize) {
      const aLength = Math.min(plan.blockSize, n - start);
      let aBlock;
      for (let next = 0; next <= start; next += plan.blockSize) {
        const bLength = Math.min(plan.blockSize, n - next);
        let bBlock;
        const values = yield {
          get left() {
            return aBlock ??= block(start);
          },
          get right() {
            return next === start ? aBlock ??= block(start) : bBlock ??= block(next);
          },
          leftProjection: z.slice(start, start + aLength),
          rightProjection: z.slice(next, next + bLength),
          diagonal: next === start,
          ordinal: { source, leftStart: start, rightStart: next, leftRows: aLength, rightRows: bLength }
        };
        if (values.length !== aLength * bLength)
          throw new EfaError("weighted-kernel", "The trace kernel returned an incorrect block shape.");
        for (let a = 0; a < aLength; a++)
          for (let b = 0; b < bLength; b++) {
            if (next === start && b > a) continue;
            const h = values[a * bLength + b];
            if (!Number.isFinite(h)) throw new EfaError("weighted-kernel", "The trace kernel returned a non-finite value.");
            const diagonal2 = start + a === next + b;
            if (diagonal2) trace += h;
            traceSquared += (diagonal2 ? 1 : 2) * h * h;
          }
        progress?.({
          stage: "Exact robust trace blocks",
          completed: ++completed,
          total
        });
      }
    }
  }
  if (covariance2.diag().some((v) => !Number.isFinite(v) || v < 0))
    throw new EfaError(
      "weighted-covariance",
      "Robust parameter covariance is numerically inadmissible."
    );
  return {
    identified,
    covariance: covariance2,
    test: testResult(objective, n, m - q, trace, traceSquared),
    plan
  };
}
function weightedInference(...args) {
  const steps = weightedInferenceSteps(...args);
  let state = steps.next();
  while (!state.done) state = steps.next(cpuTraceBlock(state.value));
  return state.value;
}
async function weightedInferenceWithKernel(kernel, ...args) {
  const steps = weightedInferenceSteps(...args);
  try {
    let state = steps.next();
    while (!state.done) state = steps.next(await kernel(state.value));
    return state.value;
  } finally {
    steps.return(void 0);
  }
}

// src/lib/efa/prepare.ts
function validateSpec(spec) {
  if (!spec || !Array.isArray(spec.items) || typeof spec.label !== "string" || !spec.label.trim() || !spec.sample || !["all", "development", "holdout"].includes(spec.sample.partition))
    throw new EfaError(
      "spec",
      "Supply a run label, items and an explicit sample partition."
    );
  computeSettings(spec);
  const p = spec.items.length, k = spec.nFactors;
  if (p < 3 || p > 500)
    throw new EfaError("items", "Select between 3 and 500 ordered items.");
  if (!Number.isInteger(k) || k < 1 || k >= p || (p - k) ** 2 - p - k < 0)
    throw new EfaError(
      "identification",
      `${k} factors are underidentified for ${p} items. Reduce the factor count or add items.`
    );
  if (!["pairwise", "complete"].includes(spec.missing) || !["minres", "dwls", "wlsmv"].includes(spec.extraction ?? "minres") || !["oblimin", "varimax", "promax"].includes(spec.rotation))
    throw new EfaError("method", "Unsupported EFA method.");
  if (!Number.isSafeInteger(spec.seed))
    throw new EfaError("seed", "Use an integer seed.");
  if (new Set(spec.items.map((i) => i.column)).size !== p)
    throw new EfaError("items", "Selected items must be unique.");
  for (const item of spec.items) {
    if (item.categories.length < 2 || item.categories.length > 65535 || new Set(item.categories).size !== item.categories.length || item.categories.some(
      (v) => typeof v !== "string" && typeof v !== "number" || v === "" || typeof v === "number" && !Number.isFinite(v)
    ))
      throw new EfaError(
        "category-order",
        `Specify a unique, explicit category order for ${item.column}.`
      );
  }
}
function prepareEfa(table, spec, eligibleRows) {
  validateSpec(spec);
  if (new Set(eligibleRows).size !== eligibleRows.length || eligibleRows.some((r) => !Number.isInteger(r) || r < 0 || r >= table.nRows))
    throw new EfaError("rows", "Invalid fitting row membership.");
  const maps = spec.items.map(
    (item) => new Map(
      item.categories.map((v, i) => [
        v,
        item.reverse ? item.categories.length - 1 - i : i
      ])
    )
  );
  for (const item of spec.items)
    if (!table.columns.includes(item.column))
      throw new EfaError("column", `Item ${item.column} no longer exists.`);
  const rows = spec.missing === "complete" ? eligibleRows.filter(
    (r) => spec.items.every(
      (item) => table.data[item.column][r] != null && table.data[item.column][r] !== ""
    )
  ) : eligibleRows.slice();
  if (rows.length < 3)
    throw new EfaError(
      "sample",
      "Fewer than three eligible respondents remain."
    );
  const n = rows.length, p = spec.items.length, codes = new Uint16Array(n * p), observed = new Uint8Array(n * p), means = [], sds = [], counts = [];
  for (let j = 0; j < p; j++) {
    const item = spec.items[j], freq = Array(item.categories.length).fill(0);
    let mean = 0, m2 = 0, total = 0;
    for (let i = 0; i < n; i++) {
      const v = table.data[item.column][rows[i]];
      if (v == null || v === "") continue;
      const code = maps[j].get(v);
      if (code === void 0)
        throw new EfaError(
          "category-order",
          `Observed value ${String(v)} is absent from the category order for ${item.column}.`
        );
      const at = j * n + i;
      codes[at] = code;
      observed[at] = 1;
      freq[code]++;
      total++;
      const delta = code + 1 - mean;
      mean += delta / total;
      m2 += delta * (code + 1 - mean);
    }
    if (freq.filter((x) => x > 0).length < 2)
      throw new EfaError(
        "constant",
        `${item.column} has fewer than two observed categories in this sample.`
      );
    means.push(mean);
    sds.push(Math.sqrt(m2 / (total - 1)));
    counts.push(freq);
  }
  return {
    items: structuredClone(spec.items),
    nRows: n,
    originalRowCount: table.nRows,
    rows,
    codes,
    observed,
    means,
    sds,
    counts,
    diagnostics: []
  };
}

// src/lib/efa/correlation.ts
function polychoric(data, i, j) {
  const n = data.nRows, kx = data.items[i].categories.length, ky = data.items[j].categories.length;
  if (kx * ky > 4096)
    throw new EfaError(
      "category-budget",
      `Too many category combinations for ${data.items[i].column} \xD7 ${data.items[j].column}. This ordinal workflow supports at most 4,096 cells per pair; check category metadata and whether a continuous method is appropriate.`
    );
  const tab = new Float64Array(kx * ky), mx = new Uint32Array(kx), my = new Uint32Array(ky);
  let total = 0;
  for (let row = 0; row < n; row++)
    if (data.observed[i * n + row] && data.observed[j * n + row]) {
      const x = data.codes[i * n + row], y = data.codes[j * n + row];
      tab[x * ky + y]++;
      mx[x]++;
      my[y]++;
      total++;
    }
  const cx = Array.from(mx.keys()).filter((q) => mx[q] > 0), cy = Array.from(my.keys()).filter((q) => my[q] > 0);
  if (cx.length < 2 || cy.length < 2 || total < 3)
    throw new EfaError(
      "unestimable-pair",
      `Cannot estimate ${data.items[i].column} \xD7 ${data.items[j].column}: ${total} jointly observed rows and ${cx.length} \xD7 ${cy.length} observed categories.`,
      [
        {
          code: "unestimable-pair",
          message: "Review category coverage and missingness.",
          items: [data.items[i].column, data.items[j].column],
          count: total
        }
      ]
    );
  const cuts = (categories, m) => {
    let acc = 0;
    return categories.slice(0, -1).map((c) => {
      acc += m[c];
      return normalQuantile(acc / total);
    });
  };
  const tx = cuts(cx, mx), ty = cuts(cy, my), xs = [-Infinity, ...tx, Infinity], ys = [-Infinity, ...ty, Infinity];
  const px = xs.map(normalCDF), py = ys.map(normalCDF);
  const objective = (rho) => {
    const cdf = bivariateGrid(xs, ys, rho, px, py);
    let loss = 0;
    for (let a = 0; a < cx.length; a++)
      for (let b = 0; b < cy.length; b++) {
        const count = tab[cx[a] * ky + cy[b]];
        if (!count) continue;
        const probability = cdf[a + 1][b + 1] - cdf[a][b + 1] - cdf[a + 1][b] + cdf[a][b];
        if (probability <= 0) return Infinity;
        loss -= count * Math.log(probability);
      }
    return loss;
  };
  const fit = brent(objective, -0.9999, 0.9999);
  if (!Number.isFinite(fit.value))
    throw new EfaError("likelihood", "Polychoric likelihood is not finite.");
  return {
    i,
    j,
    n: total,
    rho: fit.x,
    thresholdsX: tx,
    thresholdsY: ty,
    observedCategoriesX: cx,
    observedCategoriesY: cy,
    sparseCells: cx.reduce(
      (s, a) => s + cy.filter((b) => tab[a * ky + b] < 5).length,
      0
    ),
    boundary: Math.abs(fit.x) > 0.995
  };
}
function assembleCorrelations(data, pairs) {
  const p = data.items.length, matrix2 = Array.from(
    { length: p },
    (_, i) => Array.from({ length: p }, (_2, j) => i === j ? 1 : NaN)
  );
  if (pairs.length !== p * (p - 1) / 2)
    throw new EfaError("pairs", "Correlation job is incomplete.");
  for (const pair of pairs)
    matrix2[pair.i][pair.j] = matrix2[pair.j][pair.i] = pair.rho;
  const sparse = pairs.filter((x) => x.sparseCells), boundary = pairs.filter((x) => x.boundary);
  const emptyMargins = pairs.filter(
    (x) => x.observedCategoriesX.length < data.items[x.i].categories.length || x.observedCategoriesY.length < data.items[x.j].categories.length
  );
  return {
    matrix: matrix2,
    pairs,
    counts: data.counts.map((f) => f.reduce((a, b) => a + b, 0)),
    diagnostics: [
      ...sparse.length ? [
        {
          code: "sparse",
          message: `${sparse.length} item pairs contain cells with fewer than five responses. Inspect pair diagnostics.`,
          count: sparse.length
        }
      ] : [],
      ...boundary.length ? [
        {
          code: "boundary-correlation",
          message: `${boundary.length} estimated correlations are near \xB11.`,
          count: boundary.length
        }
      ] : [],
      ...emptyMargins.length ? [
        {
          code: "empty-pair-margins",
          message: `${emptyMargins.length} pairs have unobserved category margins. Their likelihoods use the observed levels, matching polycor; the original category order and observed level indices are retained.`,
          count: emptyMargins.length
        }
      ] : []
    ]
  };
}
function correlate(data, progress) {
  const pairs = [], p = data.items.length, total = p * (p - 1) / 2;
  for (let i = 0; i < p - 1; i++)
    for (let j = i + 1; j < p; j++) {
      pairs.push(polychoric(data, i, j));
      if (pairs.length % 32 === 0)
        progress?.({ stage: "Correlations", completed: pairs.length, total });
    }
  progress?.({ stage: "Correlations", completed: total, total });
  return assembleCorrelations(data, pairs);
}

// src/lib/efa/extraction.ts
var MINRES_METHOD = "MINRES compensated lower-triangle objective; analytic spectral gradient; projected BFGS; lower-objective SMC/unit-uniqueness initialization; uniqueness [.005,1]; gradient tolerance 1e-8";
function checkCorrelation(r) {
  const p = r.length;
  if (p < 3 || r.some(
    (row, i) => row.length !== p || row.some(
      (v, j) => !Number.isFinite(v) || Math.abs(v) > 1 + 1e-10 || Math.abs(v - r[j]?.[i]) > 1e-10
    ) || Math.abs(row[i] - 1) > 1e-10
  ))
    throw new EfaError(
      "matrix",
      "Expected a finite, symmetric correlation matrix with unit diagonal."
    );
  const e = eigen(new Matrix2(r)), last = e.values[p - 1];
  if (last <= 1e-8)
    throw new EfaError(
      "inadmissible-matrix",
      `Correlation matrix is ${last < 0 ? "indefinite" : "singular"} (minimum eigenvalue ${last.toPrecision(5)}). Review missingness, redundant items, and sparse categories. No smoothing was applied.`
    );
  return { eigenvalues: e.values, conditionNumber: e.values[0] / last };
}
function minresObjective(r, k, psi) {
  const p = r.rows, b = r.clone();
  for (let i = 0; i < p; i++) b.set(i, i, 1 - psi[i]);
  const { values, vectors: u } = eigen(b);
  if (values[k - 1] <= 0)
    throw new EfaError(
      "rank",
      "The requested factor count exceeds the positive common-factor rank."
    );
  const loadings = u.subMatrix(0, p - 1, 0, k - 1);
  for (let a = 0; a < k; a++) loadings.mulColumn(a, Math.sqrt(values[a]));
  const model = loadings.mmul(loadings.transpose()), d = Array.from({ length: p }, (_, i) => 1 - psi[i] - model.get(i, i));
  let objective = 0, compensation = 0;
  for (let i = 0; i < p; i++)
    for (let j = 0; j < i; j++) {
      const term = (model.get(i, j) - r.get(i, j)) ** 2 - compensation, next = objective + term;
      compensation = next - objective - term;
      objective = next;
    }
  const gradient = Array(p).fill(0);
  for (let a = 0; a < k; a++)
    for (let c = a; c < p; c++) {
      let eh = 0;
      for (let i = 0; i < p; i++) eh += u.get(i, a) * d[i] * u.get(i, c);
      const divided = c < k ? 1 : values[a] / (values[a] - values[c]);
      for (let i = 0; i < p; i++)
        gradient[i] -= (a === c ? 1 : 2) * divided * eh * u.get(i, a) * u.get(i, c);
    }
  return { objective, gradient, loadings: loadings.to2DArray(), values };
}
function extractMinres(correlation2, k, progress, maxIterations = Math.max(500, 4 * correlation2.length)) {
  const p = correlation2.length;
  if (!Number.isInteger(k) || k < 1 || (p - k) ** 2 - p - k < 0)
    throw new EfaError("identification", "Underidentified factor count.");
  const { eigenvalues } = checkCorrelation(correlation2), r = new Matrix2(correlation2), ri = inverse2(r);
  let x = Array.from(
    { length: p },
    (_, i) => clamp(1 / ri.get(i, i), 5e-3, 1)
  ), state = minresObjective(r, k, x);
  const initialization = {
    selected: "smc",
    smcObjective: state.objective,
    unitUniquenessObjective: null
  };
  if (eigenvalues[k - 1] > 1 + 1e-12) {
    const unitUniqueness = Array(p).fill(1), trial = minresObjective(r, k, unitUniqueness);
    initialization.unitUniquenessObjective = trial.objective;
    if (trial.objective < state.objective) {
      initialization.selected = "unit-uniqueness";
      x = unitUniqueness;
      state = trial;
    }
  }
  const curvature = new Float64Array(p * p);
  for (let i = 0; i < p; i++) curvature[i * p + i] = 1;
  let converged = false, iteration = 0, pgNorm = Infinity;
  for (; iteration < maxIterations; iteration++) {
    const pg = state.gradient.map(
      (g, i) => x[i] <= 5e-3 + 1e-12 && g > 0 || x[i] >= 1 - 1e-12 && g < 0 ? 0 : g
    );
    pgNorm = Math.max(...pg.map(Math.abs));
    progress?.({
      stage: `MINRES \xB7 projected gradient ${pgNorm.toExponential(3)}`,
      completed: iteration,
      total: maxIterations
    });
    if (pgNorm < 1e-8) {
      converged = true;
      break;
    }
    let direction = Array.from({ length: p }, (_, i) => {
      let value = 0;
      for (let j = 0; j < p; j++) value -= curvature[i * p + j] * pg[j];
      return value;
    });
    direction = direction.map(
      (v, i) => pg[i] === 0 || x[i] <= 5e-3 + 1e-12 && v < 0 || x[i] >= 1 - 1e-12 && v > 0 ? 0 : v
    );
    if (dot(direction, state.gradient) >= 0) direction = pg.map((v) => -v);
    let step = 1, accepted = false, next = state, nx = x;
    for (let ls = 0; ls < 40; ls++) {
      nx = x.map((v, i) => clamp(v + step * direction[i], 5e-3, 1));
      next = minresObjective(r, k, nx);
      const nextNorm = Math.max(
        ...next.gradient.map(
          (g, i) => nx[i] <= 5e-3 + 1e-12 && g > 0 || nx[i] >= 1 - 1e-12 && g < 0 ? 0 : Math.abs(g)
        )
      );
      const roundoff = 64 * Number.EPSILON * Math.max(1, state.objective);
      if (next.objective <= state.objective + 1e-4 * dot(
        state.gradient,
        nx.map((v, i) => v - x[i])
      ) || next.objective <= state.objective + roundoff && nextNorm < pgNorm * 0.99) {
        accepted = true;
        break;
      }
      step *= 0.5;
    }
    if (!accepted) break;
    if (nx.every((v, i) => v === x[i])) break;
    const s = nx.map((v, i) => v - x[i]), y = next.gradient.map((v, i) => v - state.gradient[i]), sy = dot(s, y);
    if (sy > 1e-18) {
      if (iteration === 0) {
        const scale = sy / dot(y, y);
        curvature.fill(0);
        for (let i = 0; i < p; i++) curvature[i * p + i] = scale;
      }
      const hy = Array.from({ length: p }, (_, i) => {
        let value = 0;
        for (let j = 0; j < p; j++) value += curvature[i * p + j] * y[j];
        return value;
      });
      const coefficient = (sy + dot(y, hy)) / (sy * sy);
      for (let i = 0; i < p; i++)
        for (let j = 0; j <= i; j++) {
          const value = curvature[i * p + j] + coefficient * s[i] * s[j] - (hy[i] * s[j] + s[i] * hy[j]) / sy;
          curvature[i * p + j] = value;
          curvature[j * p + i] = value;
        }
    }
    x = nx;
    state = next;
  }
  if (!converged) {
    pgNorm = Math.max(
      ...state.gradient.map(
        (g, i) => x[i] <= 5e-3 + 1e-12 && g > 0 || x[i] >= 1 - 1e-12 && g < 0 ? 0 : Math.abs(g)
      )
    );
    converged = pgNorm < 1e-8;
  }
  if (!converged)
    throw new EfaError(
      "minres-nonconvergence",
      `MINRES did not converge after ${iteration} iterations (objective ${state.objective}, projected gradient ${pgNorm}). No alternative extractor was used.`
    );
  return {
    estimator: "minres",
    method: `${MINRES_METHOD}; selected ${initialization.selected}`,
    initialization,
    loadings: state.loadings,
    uniquenessParameters: x,
    eigenvalues,
    boundaryItems: x.flatMap(
      (v, i) => v < 5001e-6 || v > 0.999999 ? [i] : []
    ),
    convergence: {
      converged,
      iterations: iteration,
      objective: state.objective,
      gradient: pgNorm,
      maxIterations
    }
  };
}

// src/lib/random.ts
var mulberry32 = (seed) => () => {
  seed |= 0;
  seed = seed + 1831565813 | 0;
  let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
  t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
};

// src/lib/efa/rotation.ts
function polar(a) {
  const s = new SingularValueDecomposition2(a);
  return s.leftSingularVectors.mmul(s.rightSingularVectors.transpose());
}
function normalizeColumns(a) {
  for (let j = 0; j < a.columns; j++) {
    const n = Math.hypot(...a.getColumn(j));
    if (n < 1e-12) throw new Error("Singular rotation");
    a.mulColumn(j, 1 / n);
  }
  return a;
}
function quartimin(l) {
  const g = l.clone();
  let objective = 0, compensation = 0;
  for (let i = 0; i < l.rows; i++) {
    let sum = 0;
    for (let j = 0; j < l.columns; j++) sum += l.get(i, j) ** 2;
    for (let j = 0; j < l.columns; j++) {
      const v = l.get(i, j), other = sum - v * v;
      g.set(i, j, v * other);
      const term = v * v * other / 4 - compensation, next = objective + term;
      compensation = next - objective - term;
      objective = next;
    }
  }
  return { objective, g };
}
function projectedRotationGradient(t, inv, l, gradient) {
  const g = l.transpose().mmul(gradient).mmul(inv).transpose().neg(), pg = g.clone();
  for (let j = 0; j < t.columns; j++) {
    let projection = 0;
    for (let i = 0; i < t.rows; i++) projection += t.get(i, j) * g.get(i, j);
    for (let i = 0; i < t.rows; i++)
      pg.set(i, j, g.get(i, j) - t.get(i, j) * projection);
  }
  return pg;
}
function oblimin(a, start) {
  let t = start, inv = inverse2(t), l = a.mmul(inv.transpose()), state = quartimin(l), step = 1, gn = Infinity, iteration = 0;
  for (; iteration < 4e3; iteration++) {
    const pg = projectedRotationGradient(t, inv, l, state.g);
    gn = pg.norm();
    if (gn < 1e-8) break;
    step = Math.min(step * 2, 100);
    let accepted = false;
    for (let ls = 0; ls < 40; ls++) {
      try {
        const nt = normalizeColumns(Matrix2.sub(t, Matrix2.mul(pg, step))), ni = inverse2(nt), nl = a.mmul(ni.transpose()), ns = quartimin(nl);
        if (ns.objective <= state.objective - 0.5 * step * gn * gn || ns.objective <= state.objective + 64 * Number.EPSILON * Math.max(1, Math.abs(state.objective)) && projectedRotationGradient(nt, ni, nl, ns.g).norm() < gn * 0.99) {
          t = nt;
          inv = ni;
          l = nl;
          state = ns;
          accepted = true;
          break;
        }
      } catch {
      }
      step *= 0.5;
    }
    if (!accepted) break;
  }
  gn = projectedRotationGradient(t, inv, l, state.g).norm();
  return {
    pattern: l.to2DArray(),
    phi: t.transpose().mmul(t).to2DArray(),
    starts: 1,
    convergence: {
      converged: gn < 1e-8,
      iterations: iteration,
      objective: state.objective,
      gradient: gn,
      maxIterations: 4e3
    }
  };
}
function varimax(a, initial = Matrix2.eye(a.columns), tolerance = 1e-9) {
  const norm = a.to2DArray().map((row) => Math.hypot(...row)), x = a.clone();
  for (let i = 0; i < a.rows; i++) if (norm[i] > 0) x.mulRow(i, 1 / norm[i]);
  let t = initial, d = 0, iteration = 0, converged = false;
  for (; iteration < 2e3; iteration++) {
    const l = x.mmul(t), target = l.clone(), ss = l.to2DArray().reduce(
      (s, row) => s.map((v, j) => v + row[j] ** 2),
      Array(a.columns).fill(0)
    );
    for (let i = 0; i < l.rows; i++)
      for (let j = 0; j < l.columns; j++)
        target.set(i, j, l.get(i, j) ** 3 - l.get(i, j) * ss[j] / l.rows);
    const svd = new SingularValueDecomposition2(x.transpose().mmul(target));
    t = svd.leftSingularVectors.mmul(svd.rightSingularVectors.transpose());
    const next = svd.diagonal.reduce((s, v) => s + v, 0);
    if (next < d * (1 + tolerance)) {
      converged = true;
      d = next;
      break;
    }
    d = next;
  }
  return {
    pattern: a.mmul(t).to2DArray(),
    phi: Matrix2.eye(a.columns).to2DArray(),
    transform: t,
    starts: 1,
    convergence: {
      converged,
      iterations: iteration,
      objective: -d,
      gradient: 0
    }
  };
}
function rotate(loadings, method, seed = 73021, starts = 4, derivativePrecision = false) {
  const a = new Matrix2(loadings), k = a.columns;
  if (k === 1)
    return {
      pattern: loadings.map((row) => row.slice()),
      phi: [[1]],
      starts: 1,
      convergence: {
        converged: true,
        iterations: 0,
        objective: 0,
        gradient: 0
      }
    };
  if (method === "promax") {
    const v = varimax(a, Matrix2.eye(k), derivativePrecision ? 1e-14 : 1e-5);
    if (!v.convergence.converged)
      throw new EfaError(
        "rotation-nonconvergence",
        "Promax initial varimax failed to converge."
      );
    const l = new Matrix2(v.pattern), target = l.clone();
    for (let i = 0; i < l.rows; i++)
      for (let j = 0; j < k; j++)
        target.set(i, j, l.get(i, j) * Math.abs(l.get(i, j)) ** 3);
    const u = solve2(l.transpose().mmul(l), l.transpose().mmul(target)), ui = inverse2(u.transpose().mmul(u));
    for (let j = 0; j < k; j++) u.mulColumn(j, Math.sqrt(ui.get(j, j)));
    const transform = v.transform.mmul(u), ti = inverse2(transform);
    return {
      pattern: a.mmul(transform).to2DArray(),
      phi: ti.mmul(ti.transpose()).to2DArray(),
      starts: 1,
      convergence: {
        ...v.convergence,
        objective: Matrix2.sub(l.mmul(u), target).norm() ** 2
      }
    };
  }
  const random = mulberry32(seed);
  let best;
  const attempts = [];
  for (let s = 0; s < starts; s++) {
    const initial = s === 0 ? Matrix2.eye(k) : polar(
      new Matrix2(
        Array.from(
          { length: k },
          () => Array.from({ length: k }, () => random() * 2 - 1)
        )
      )
    );
    const candidate = method === "oblimin" ? oblimin(a, initial) : varimax(a, initial, derivativePrecision ? 1e-14 : 1e-9);
    attempts.push(candidate.convergence);
    if (candidate.convergence.converged && (!best || candidate.convergence.objective < best.convergence.objective))
      best = candidate;
  }
  if (!best)
    throw new EfaError(
      "rotation-nonconvergence",
      `${method} did not converge in ${starts} deterministic starts.`,
      attempts.map((attempt, i) => ({
        code: "rotation-start",
        message: `Start ${i + 1}: ${attempt.iterations} iterations, objective ${attempt.objective}, gradient ${attempt.gradient}.`
      }))
    );
  return {
    pattern: best.pattern,
    phi: best.phi,
    convergence: best.convergence,
    starts
  };
}

// src/lib/efa/optimize.ts
var infinityNorm = (values) => values.reduce((norm, value) => Math.max(norm, Math.abs(value)), 0);
function minimize(objective, initial, maxIterations = 500, tolerance = 1e-8, context) {
  let parameters = initial.slice(), state = objective(parameters), iteration = 0;
  const history = [];
  for (; iteration < maxIterations; iteration++) {
    const norm = infinityNorm(state.gradient);
    context?.progress?.({
      stage: `${context.label} \xB7 gradient ${norm.toExponential(3)}`,
      completed: iteration,
      total: maxIterations
    });
    if (Number.isFinite(state.value) && norm < tolerance)
      return {
        parameters,
        ...state,
        iterations: iteration,
        gradientNorm: norm
      };
    let direction = state.gradient.slice();
    const alpha = [];
    for (let h = history.length - 1; h >= 0; h--) {
      const v = history[h];
      alpha[h] = v.rho * dot(v.s, direction);
      direction = direction.map((x, i) => x - alpha[h] * v.y[i]);
    }
    const last = history.at(-1), scale = last ? dot(last.s, last.y) / dot(last.y, last.y) : 1;
    direction = direction.map((x) => x * scale);
    for (let h = 0; h < history.length; h++) {
      const v = history[h], beta = v.rho * dot(v.y, direction);
      direction = direction.map((x, i) => x + v.s[i] * (alpha[h] - beta));
    }
    direction = direction.map((x) => -x);
    if (dot(direction, state.gradient) >= 0)
      direction = state.gradient.map((x) => -x);
    let step = 1, next = state, candidate = parameters, accepted = false;
    const slope = dot(direction, state.gradient);
    for (let line = 0; line < 45; line++) {
      candidate = parameters.map((x, i) => x + step * direction[i]);
      next = objective(candidate);
      const nextNorm = infinityNorm(next.gradient);
      if (Number.isFinite(next.value) && (next.value <= state.value + 1e-4 * step * slope || next.value <= state.value + 64 * Number.EPSILON * Math.max(1, Math.abs(state.value)) && nextNorm < norm * 0.99)) {
        accepted = true;
        break;
      }
      step *= 0.5;
    }
    if (!accepted) break;
    if (candidate.every((v, i) => v === parameters[i])) break;
    const s = candidate.map((x, i) => x - parameters[i]), y = next.gradient.map((x, i) => x - state.gradient[i]), sy = dot(s, y);
    if (sy > 1e-20) {
      history.push({ s, y, rho: 1 / sy });
      if (history.length > 12) history.shift();
    }
    parameters = candidate;
    state = next;
  }
  const finalNorm = infinityNorm(state.gradient);
  if (Number.isFinite(state.value) && finalNorm < tolerance)
    return {
      parameters,
      ...state,
      iterations: iteration,
      gradientNorm: finalNorm
    };
  throw new EfaError(
    context?.code ?? "regression-nonconvergence",
    `${context?.label ?? "Conditional regression"} did not converge after ${iteration} iterations (gradient ${finalNorm}). No alternative model was substituted.`
  );
}

// src/lib/efa/dwls.ts
var DWLS_METHOD = "DWLS pair correlations; reciprocal diagonal two-step sampling variances; analytic loading gradient; L-BFGS tolerance 1e-8; spectral start; unconstrained uniquenesses; no estimator substitution";
function dwlsObjective(correlation2, moments, k, parameters) {
  let value = 0, correction = 0;
  const gradient = Array(parameters.length).fill(0);
  for (let a = 0; a < moments.pairs.length; a++) {
    const { i, j } = moments.pairs[a], weight = moments.weights[a];
    let predicted = 0;
    for (let f = 0; f < k; f++)
      predicted += parameters[i * k + f] * parameters[j * k + f];
    const residual = predicted - correlation2[i][j], term = weight * residual * residual - correction, next = value + term;
    correction = next - value - term;
    value = next;
    for (let f = 0; f < k; f++) {
      gradient[i * k + f] += 2 * weight * residual * parameters[j * k + f];
      gradient[j * k + f] += 2 * weight * residual * parameters[i * k + f];
    }
  }
  return { value, gradient };
}
function extractDwls(correlation2, moments, k, progress, maxIterations = 2e3) {
  const p = correlation2.length;
  if (!Number.isInteger(k) || k < 1 || (p - k) ** 2 - p - k < 0)
    throw new EfaError("identification", "Underidentified factor count.");
  checkCorrelation(correlation2);
  if (moments.pairs.length !== p * (p - 1) / 2 || moments.weights.length !== moments.pairs.length || Array.from(moments.weights).some((w) => !(w > 0) || !Number.isFinite(w)))
    throw new EfaError(
      "weighted-moments",
      "DWLS requires one finite, positive variance weight for every item pair."
    );
  const { values, vectors } = eigen(new Matrix2(correlation2)), initial = Array.from(
    { length: p * k },
    (_, a) => vectors.get(Math.floor(a / k), a % k) * Math.sqrt(Math.max(0.01, values[a % k] - 0.5))
  ), optimized = minimize(
    (x) => dwlsObjective(correlation2, moments, k, x),
    initial,
    maxIterations,
    1e-8,
    { code: "dwls-nonconvergence", label: "DWLS", progress }
  ), loadings = Array.from(
    { length: p },
    (_, i) => optimized.parameters.slice(i * k, (i + 1) * k)
  );
  return {
    estimator: "dwls",
    method: DWLS_METHOD,
    loadings,
    uniquenessParameters: loadings.map(
      (row) => 1 - row.reduce((s, v) => s + v * v, 0)
    ),
    eigenvalues: values,
    boundaryItems: [],
    convergence: {
      converged: true,
      iterations: optimized.iterations,
      objective: optimized.value,
      gradient: optimized.gradientNorm,
      maxIterations
    }
  };
}

// src/lib/efa/compare.ts
function matchFactors(reference, candidate) {
  const ka = reference[0]?.length ?? 0, kb = candidate[0]?.length ?? 0, n = Math.max(ka, kb);
  const congruence = Array.from(
    { length: ka },
    (_, a) => Array.from({ length: kb }, (_2, b) => {
      let xy = 0, xx = 0, yy = 0;
      for (let i = 0; i < reference.length; i++) {
        const x = reference[i][a], y = candidate[i][b];
        xy += x * y;
        xx += x * x;
        yy += y * y;
      }
      return xx * yy > 0 ? xy / Math.sqrt(xx * yy) : 0;
    })
  );
  const u = Array(n + 1).fill(0), v = Array(n + 1).fill(0), p = Array(n + 1).fill(0), way = Array(n + 1).fill(0);
  for (let i = 1; i <= n; i++) {
    p[0] = i;
    let j0 = 0;
    const min = Array(n + 1).fill(Infinity), used = Array(n + 1).fill(false);
    do {
      used[j0] = true;
      const i0 = p[j0];
      let delta = Infinity, j1 = 0;
      for (let j = 1; j <= n; j++)
        if (!used[j]) {
          const cost = 1 - Math.abs(congruence[i0 - 1]?.[j - 1] ?? 0) - u[i0] - v[j];
          if (cost < min[j]) {
            min[j] = cost;
            way[j] = j0;
          }
          if (min[j] < delta) {
            delta = min[j];
            j1 = j;
          }
        }
      for (let j = 0; j <= n; j++)
        if (used[j]) {
          u[p[j]] += delta;
          v[j] -= delta;
        } else min[j] -= delta;
      j0 = j1;
    } while (p[j0] !== 0);
    do {
      const j1 = way[j0];
      p[j0] = p[j1];
      j0 = j1;
    } while (j0 !== 0);
  }
  const mapping = Array(ka).fill(null);
  for (let j = 1; j <= n; j++)
    if (p[j] <= ka && j <= kb) mapping[p[j] - 1] = j - 1;
  const signs = mapping.map(
    (b, a) => b === null ? 1 : congruence[a][b] < 0 ? -1 : 1
  );
  return {
    mapping,
    signs,
    congruence: mapping.map(
      (b, a) => b === null ? null : Math.abs(congruence[a][b])
    ),
    unmatchedCandidate: Array.from({ length: kb }, (_, i) => i).filter(
      (i) => !mapping.includes(i)
    )
  };
}

// src/lib/efa/weighted-rotation.ts
function rotationDerivativeContext(identified, reference, method, seed) {
  return { identified: { loadings: identified.loadings, free: identified.free }, referencePattern: reference.pattern, method, seed };
}
function dimensions(context) {
  const p = context.identified.loadings.length, k = context.identified.loadings[0].length, q = context.identified.free.length, outputs = 2 * p * k + k * k + p;
  if (8 * outputs * q + 24 * q * q > 1024 ** 3)
    throw new EfaError("weighted-budget", "Rotated uncertainty exceeds the worker memory budget. Reduce the item/factor set.");
  return { p, k, q, outputs };
}
function rotationDerivativeBatch(context, start, count, progress) {
  const { identified, referencePattern, method, seed } = context;
  const { q, outputs } = dimensions(context);
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(count) || start < 0 || count < 1 || count > 16 || start + count > q)
    throw new EfaError("weighted-rotation-batch", "Invalid rotation derivative range.");
  const values = new Float64Array(count * outputs);
  const evaluate = (parameter, change) => {
    const loading = identified.loadings.map((row) => row.slice()), [i, f] = identified.free[parameter];
    loading[i][f] += change;
    const rotation = rotate(loading, method, seed, 4, true), match = matchFactors(referencePattern, rotation.pattern);
    if (match.mapping.some((v) => v === null) || match.congruence.some((v) => v === null || v < 0.99))
      throw new EfaError(
        "weighted-rotation",
        "Rotation is not locally stable enough for standard errors. Inspect resampling stability; no fixed-rotation covariance was substituted."
      );
    const pattern = rotation.pattern.map(
      (row) => match.mapping.map((j, a) => row[j] * match.signs[a])
    ), phi = match.mapping.map(
      (i2, a) => match.mapping.map(
        (j, b) => rotation.phi[i2][j] * match.signs[a] * match.signs[b]
      )
    ), structure = new Matrix2(pattern).mmul(new Matrix2(phi)).to2DArray(), communalities = loading.map((row) => row.reduce((s, v) => s + v * v, 0));
    return [
      ...pattern.flat(),
      ...structure.flat(),
      ...phi.flat(),
      ...communalities
    ];
  };
  let maxChange = 0;
  for (let a = start; a < start + count; a++) {
    const [i, f] = identified.free[a], h = 1e-3 * (1 + Math.abs(identified.loadings[i][f])), hi = evaluate(a, h), lo = evaluate(a, -h), halfHi = evaluate(a, h / 2), halfLo = evaluate(a, -h / 2);
    for (let o = 0; o < outputs; o++) {
      const full = (hi[o] - lo[o]) / (2 * h), half = (halfHi[o] - halfLo[o]) / h, change = Math.abs(full - half) / Math.max(1, Math.abs(half));
      if (!Number.isFinite(change) || change > 5e-3)
        throw new EfaError(
          "weighted-rotation",
          "Rotated standard errors failed the derivative step-stability check. No uncertainty estimate was published."
        );
      maxChange = Math.max(maxChange, change);
      values[(a - start) * outputs + o] = (4 * half - full) / 3;
    }
    progress?.({
      stage: "Rotated standard errors",
      completed: a + 1,
      total: q
    });
  }
  return { start, count, values, maxChange };
}
var RotationDerivativeAccumulator = class {
  constructor(context) {
    this.context = context;
    this.maxChange = 0;
    this.completed = 0;
    const { q, outputs } = dimensions(context);
    this.derivatives = Array.from({ length: outputs }, () => new Float64Array(q));
    this.received = new Uint8Array(q);
  }
  add(batch) {
    const { start, count, values, maxChange } = batch, { q, outputs } = dimensions(this.context);
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(count) || start < 0 || count < 1 || count > 16 || start + count > q || !(values instanceof Float64Array) || values.length !== count * outputs || values.some((v) => !Number.isFinite(v)) || !Number.isFinite(maxChange) || maxChange < 0 || maxChange > 5e-3 || this.received.subarray(start, start + count).some(Boolean))
      throw new EfaError("weighted-rotation-batch", "Malformed or duplicate rotation derivative batch.");
    for (let a = 0; a < count; a++) {
      for (let o = 0; o < outputs; o++) this.derivatives[o][start + a] = values[a * outputs + o];
      this.received[start + a] = 1;
    }
    this.maxChange = Math.max(this.maxChange, maxChange);
    this.completed += count;
  }
  finish(covariance2, progress) {
    const { p, k, q, outputs } = dimensions(this.context);
    if (this.completed !== q) throw new EfaError("weighted-rotation-batch", "Rotation derivatives are incomplete.");
    progress?.({ stage: "Rotated covariance propagation", completed: 0, total: outputs });
    const variances = covarianceQuadraticForms(covariance2, this.derivatives, progress);
    const se = Array.from(variances, (variance) => {
      if (!Number.isFinite(variance) || variance < -1e-12)
        throw new EfaError(
          "weighted-covariance",
          "Rotated uncertainty produced an inadmissible variance."
        );
      const value = Math.sqrt(Math.max(0, variance));
      return value;
    });
    let offset = 0;
    const matrix2 = (rows, cols) => Array.from({ length: rows }, () => {
      const row = se.slice(offset, offset + cols);
      offset += cols;
      return row;
    });
    const pattern = matrix2(p, k), structure = matrix2(p, k), phi = matrix2(k, k), communalities = se.slice(offset);
    return {
      pattern,
      structure,
      phi,
      communalities,
      uniquenesses: communalities.slice(),
      derivativeMaxRelativeChange: this.maxChange,
      method: "Robust delta standard errors; full seeded rotation map with varimax convergence 1e-14 for derivatives; central differences h=.001*(1+abs(parameter)), half-step check and Richardson extrapolation; sign/permutation alignment only; denominator N-1"
    };
  }
};
function rotatedUncertainty(identified, covariance2, reference, method, seed, progress) {
  const context = rotationDerivativeContext(identified, reference, method, seed), accumulator2 = new RotationDerivativeAccumulator(context), q = identified.free.length;
  progress?.({ stage: "Rotated standard errors", completed: 0, total: q });
  for (let start = 0; start < q; start += 8)
    accumulator2.add(rotationDerivativeBatch(context, start, Math.min(8, q - start), progress));
  return accumulator2.finish(covariance2, progress);
}

// src/lib/efa/fit.ts
function* fitEfaSteps(data, correlation2, spec, progress, extraction, invariant2, capture) {
  const settings = computeSettings(spec);
  const { conditionNumber } = checkCorrelation(correlation2.matrix);
  const estimator = spec.extraction ?? "minres", pointEstimator = estimator === "minres" ? "minres" : "dwls";
  if (!["minres", "dwls", "wlsmv"].includes(estimator))
    throw new EfaError("method", "Unsupported EFA extractor.");
  if (extraction && (extraction.estimator ?? "minres") !== pointEstimator)
    throw new EfaError(
      "extraction-reuse",
      "A saved extraction can only be reused with its original point estimator."
    );
  if (estimator === "wlsmv")
    planWeightedInference(
      data.items.length,
      spec.nFactors,
      data.nRows,
      correlation2.pairs.reduce(
        (sum, pair) => sum + data.items[pair.i].categories.length * data.items[pair.j].categories.length,
        0
      ),
      settings
    );
  const moments = estimator === "minres" || invariant2 ? void 0 : weightedMoments(data, correlation2, progress);
  const unrotated = invariant2?.extraction ?? extraction ?? (moments ? extractDwls(correlation2.matrix, moments, spec.nFactors, progress) : extractMinres(correlation2.matrix, spec.nFactors, progress));
  progress?.({ stage: "Rotation", completed: 0, total: 1 });
  const rotation = rotate(
    unrotated.loadings,
    spec.rotation,
    spec.seed,
    4,
    estimator !== "minres"
  ), l = new Matrix2(rotation.pattern), phi = new Matrix2(rotation.phi), s = l.mmul(phi), model = s.mmul(l.transpose());
  const reproduced = model.to2DArray(), communalities = model.diag(), uniquenesses = communalities.map((v) => 1 - v), residuals = correlation2.matrix.map(
    (row, i) => row.map((v, j) => i === j ? 0 : v - reproduced[i][j])
  );
  const p = l.rows, rmsr = Math.sqrt(
    residuals.reduce(
      (sum, row) => sum + row.reduce((s2, v) => s2 + v * v, 0),
      0
    ) / (p * (p - 1))
  );
  const weights = solve2(new Matrix2(correlation2.matrix), s).to2DArray();
  let weighted;
  if (moments || invariant2) {
    weighted = invariant2 ? { ...invariant2.weighted } : {
      estimator,
      samplingVariances: moments.pairs.map((pair) => pair.variance),
      fittingWeights: Array.from(moments.weights),
      uncertaintyMethod: moments.method,
      rawStatistic: (data.nRows - 1) * unrotated.convergence.objective,
      df: p * (p - 1) / 2 - (p * spec.nFactors - spec.nFactors * (spec.nFactors - 1) / 2)
    };
    capture?.({ extraction: unrotated, weighted: { ...weighted } });
    if (estimator === "wlsmv") {
      const saved = invariant2?.inference;
      const inference = saved ? { ...saved, covariance: Matrix2.from1DArray(saved.identified.free.length, saved.identified.free.length, saved.covariance) } : yield {
        kind: "inference",
        args: [data, moments, unrotated.loadings, unrotated.convergence.objective, progress, settings]
      };
      weighted.robust = {
        test: inference.test,
        plan: inference.plan,
        standardErrors: yield {
          kind: "rotation",
          context: rotationDerivativeContext(inference.identified, rotation, spec.rotation, spec.seed),
          covariance: inference.covariance
        }
      };
    }
  }
  return {
    ...weighted ? { weighted } : {},
    correlation: correlation2,
    extraction: unrotated,
    rotation,
    structure: s.to2DArray(),
    communalities,
    uniquenesses,
    reproduced,
    residuals,
    rmsr,
    means: data.means,
    sds: data.sds,
    weights,
    categoryCounts: data.counts,
    fittingRows: data.rows,
    originalRowCount: data.originalRowCount,
    conditionNumber,
    diagnostics: [
      ...data.diagnostics,
      ...correlation2.diagnostics,
      ...conditionNumber > 1e6 ? [
        {
          code: "conditioning",
          message: `Ill-conditioned matrix (condition number ${conditionNumber.toPrecision(4)}).`
        }
      ] : [],
      ...unrotated.boundaryItems.length ? [
        {
          code: "uniqueness-boundary",
          message: "One or more optimized uniquenesses reached a bound.",
          items: unrotated.boundaryItems.map((i) => spec.items[i].column)
        }
      ] : [],
      ...uniquenesses.some((v) => v < 0) ? [
        {
          code: "improper",
          message: "Improper solution: one or more communalities exceed one."
        }
      ] : []
    ],
    provenance: {
      inputSha256: data.fingerprint,
      engine: EFA_ENGINE,
      matrix: "ml-matrix/6.12.1",
      correlation: "two-step polychoric; pair margins; maxcor=.9999; no smoothing",
      extraction: unrotated.method ?? "Reused saved MINRES extraction; see the originating run for optimizer provenance",
      rotation: `${spec.rotation}; oblimin delta=0 unnormalized; varimax normalized; promax power=4${estimator !== "minres" ? "; weighted varimax convergence 1e-14; no additional observed-variable rescaling" : ""}`,
      scoring: "linear regression approximation: ordinal ranks standardized on fitting sample; R^-1 \xD7 structure; complete rows only",
      seed: spec.seed
    }
  };
}
function fitEfa(data, correlation2, spec, progress, extraction) {
  const steps = fitEfaSteps(data, correlation2, spec, progress, extraction);
  if (computeSettings(spec).backend !== "cpu")
    throw new EfaError("backend-async", "Accelerated fits require the asynchronous EFA service.");
  let step = steps.next();
  while (!step.done) {
    const task = step.value;
    if (task.kind === "inference") step = steps.next(weightedInference(...task.args));
    else {
      const { context, covariance: covariance2 } = task;
      step = steps.next(rotatedUncertainty(
        context.identified,
        covariance2,
        { pattern: context.referencePattern },
        context.method,
        context.seed,
        progress
      ));
    }
  }
  return step.value;
}
function scoreEfa(data, result) {
  const k = result.weights[0].length, p = data.items.length, n = data.nRows, scores = Array.from(
    { length: data.originalRowCount },
    () => Array(k).fill(null)
  );
  for (let row = 0; row < n; row++) {
    let complete = true;
    for (let j = 0; j < p; j++)
      if (!data.observed[j * n + row]) {
        complete = false;
        break;
      }
    if (!complete) continue;
    const values = Array(k).fill(0);
    for (let j = 0; j < p; j++) {
      const z = (data.codes[j * n + row] + 1 - result.means[j]) / result.sds[j];
      for (let f = 0; f < k; f++) values[f] += z * result.weights[j][f];
    }
    scores[data.rows[row]] = values;
  }
  return scores;
}

// src/lib/efa/parallel.ts
function factorEigenvalues(r, progress) {
  const one = extractMinres(r, 1, progress), reduced = new Matrix2(r);
  one.loadings.forEach((row, i) => reduced.set(i, i, row[0] ** 2));
  return eigen(reduced).values;
}
function permutedData(data, seed) {
  const codes = data.codes.slice(), random = mulberry32(seed), n = data.nRows;
  for (let j = 0; j < data.items.length; j++) {
    const indices = [];
    for (let i = 0; i < n; i++)
      if (data.observed[j * n + i]) indices.push(j * n + i);
    for (let i = indices.length - 1; i > 0; i--) {
      const k = Math.floor(random() * (i + 1)), a = indices[i], b = indices[k];
      [codes[a], codes[b]] = [codes[b], codes[a]];
    }
  }
  return { ...data, codes };
}
function parallelAnalysis(data, seed, replicates = 100, progress, minimumPairN = 0) {
  validateReplicates(replicates, seed);
  const observed = parallelObserved(data, minimumPairN, progress), nullEigenvalues = [], failures = [];
  for (let i = 0; i < replicates; i++) {
    try {
      nullEigenvalues.push(parallelReplicate(data, seed + i));
    } catch (error) {
      failures.push({
        replicate: i,
        error: error instanceof Error ? error.message : String(error)
      });
    }
    progress?.({
      stage: "Parallel analysis",
      completed: i + 1,
      total: replicates
    });
  }
  return summarizeParallel(
    observed,
    nullEigenvalues,
    failures,
    seed,
    replicates,
    data.fingerprint
  );
}
function validateReplicates(replicates, seed) {
  if (!Number.isInteger(replicates) || replicates < 1 || replicates > 1e3)
    throw new EfaError(
      "replicates",
      "Use 1\u20131000 parallel-analysis permutations."
    );
  if (seed !== void 0 && (!Number.isSafeInteger(seed) || !Number.isSafeInteger(seed + (replicates - 1))))
    throw new EfaError(
      "seed",
      "Choose an integer seed whose full sequence of permutation offsets stays within JavaScript's safe integer range."
    );
}
function parallelObserved(data, minimumPairN = 0, progress) {
  const correlation2 = correlate(data, progress);
  if (data.rows.length < minimumPairN || correlation2.pairs.some((pair) => pair.n < minimumPairN))
    throw new EfaError(
      "privacy",
      "This simulation includes item pairs below the private aggregate floor."
    );
  return factorEigenvalues(correlation2.matrix, progress);
}
function parallelReplicate(data, seed, progress) {
  return factorEigenvalues(
    correlate(permutedData(data, seed), progress).matrix,
    progress
  );
}
function summarizeParallel(observed, nullEigenvalues, failures, seed, replicates, inputSha256) {
  if (nullEigenvalues.length + failures.length !== replicates)
    throw new EfaError(
      "incomplete-simulation",
      "A simulation result must account for every requested replicate."
    );
  const reference = observed.map((_, j) => {
    const sorted = nullEigenvalues.map((row) => row[j]).sort((a, b) => a - b);
    if (!sorted.length) return null;
    const index = 0.95 * (sorted.length - 1), lo = Math.floor(index);
    return sorted[lo] + (sorted[Math.ceil(index)] - sorted[lo]) * (index - lo);
  });
  let suggestion = 0;
  while (suggestion < observed.length && reference[suggestion] !== null && observed[suggestion] > reference[suggestion])
    suggestion++;
  return {
    provenance: {
      inputSha256,
      engine: EFA_ENGINE,
      correlation: "Two-step pair-margin polychoric; maxcor=.9999",
      extraction: MINRES_METHOD,
      nullModel: "Within-item observed-response permutations with fixed missingness masks",
      communalityConvention: "One-factor MINRES squared loadings replace correlation diagonals for observed and null spectra",
      generator: "mulberry32; replicate seed = batch seed + zero-based replicate index",
      percentile: "95th percentile; linear interpolation (R type 7)"
    },
    seed,
    requested: replicates,
    completed: nullEigenvalues.length,
    percentile: 0.95,
    observed,
    nullEigenvalues,
    reference,
    failures,
    suggested: failures.length ? null : suggestion
  };
}

// src/lib/efa/ordinal-regression.ts
var MAX_CONDITIONAL_LEVELS = 50;
var logistic = (x) => x >= 0 ? 1 / (1 + Math.exp(-x)) : Math.exp(x) / (1 + Math.exp(x));
var softplus = (x) => Math.max(x, 0) + Math.log1p(Math.exp(-Math.abs(x)));
var logLogistic = (x) => -softplus(-x);
function augmentConditional(x, y, levels) {
  const n = x.length, d = x[0]?.length ?? 0;
  if (!n || y.length !== n || levels < 2 || !Number.isInteger(levels) || levels > MAX_CONDITIONAL_LEVELS || x.some((row) => row.length !== d || row.some((v) => !Number.isFinite(v))) || y.some((v) => v !== null && (!Number.isInteger(v) || v < 0 || v >= levels)))
    throw new EfaError(
      "conditional-data",
      "Invalid conditional regression inputs."
    );
  const observed = y.flatMap((v, i) => v === null ? [] : [i]);
  if (new Set(observed.map((i) => y[i])).size !== levels)
    throw new EfaError(
      "empty-imputation-category",
      "Every declared outcome category needs observed responses in the fitting sample."
    );
  const train = {
    x: observed.map((i) => x[i]),
    y: observed.map((i) => y[i]),
    weights: observed.map(() => 1),
    augmented: 0
  };
  if (!d || n - observed.length === 1) return train;
  const means = Array(d).fill(0), sds = Array(d).fill(0), lo = Array(d).fill(Infinity), hi = Array(d).fill(-Infinity);
  for (const row of x)
    for (let j = 0; j < d; j++) {
      means[j] += row[j] / n;
      lo[j] = Math.min(lo[j], row[j]);
      hi[j] = Math.max(hi[j], row[j]);
    }
  for (const row of x)
    for (let j = 0; j < d; j++) sds[j] += (row[j] - means[j]) ** 2 / (n - 1);
  for (let j = 0; j < d; j++) {
    if (sds[j] <= 1e-14)
      throw new EfaError(
        "constant-predictor",
        `Imputation predictor ${j + 1} is constant. Revise the predictor specification.`
      );
    for (let c = 0; c < levels; c++)
      for (const sign of [1, -1]) {
        const row = means.slice();
        row[j] = Math.max(
          lo[j],
          Math.min(hi[j], means[j] + sign * 0.5 * Math.sqrt(sds[j]))
        );
        train.x.push(row);
        train.y.push(c);
        train.weights.push((d + 1) / (2 * d * levels));
        train.augmented++;
      }
  }
  return train;
}
function ordinalObjective(data, levels) {
  const d = data.x[0]?.length ?? 0, total = data.weights.reduce((a, b) => a + b, 0);
  return (parameters) => {
    const thresholds = [parameters[d]];
    for (let c = 1; c < levels - 1; c++)
      thresholds.push(thresholds[c - 1] + Math.exp(parameters[d + c]));
    const gradient = Array(parameters.length).fill(0), cuts = Array(levels - 1).fill(0);
    let value = 0, compensation = 0;
    for (let i = 0; i < data.x.length; i++) {
      const row = data.x[i], c = data.y[i], w = data.weights[i] / total;
      let eta = 0;
      for (let j = 0; j < d; j++) eta += row[j] * parameters[j];
      const upper = c === levels - 1 ? Infinity : thresholds[c] - eta, lower = c === 0 ? -Infinity : thresholds[c - 1] - eta, delta = upper - lower;
      const logProbability = c === 0 ? logLogistic(upper) : c === levels - 1 ? logLogistic(-lower) : lower + (delta > 50 ? delta : Math.log(Math.expm1(delta))) - softplus(upper) - softplus(lower);
      if (!Number.isFinite(logProbability))
        return { value: Infinity, gradient };
      const term = -w * logProbability - compensation, nextValue = value + term;
      compensation = nextValue - value - term;
      value = nextValue;
      const fu = c === levels - 1 ? 0 : Math.exp(
        logLogistic(upper) + logLogistic(-upper) - logProbability
      ), fl = c === 0 ? 0 : Math.exp(
        logLogistic(lower) + logLogistic(-lower) - logProbability
      ), slope = w * (fu - fl);
      for (let j = 0; j < d; j++) gradient[j] += row[j] * slope;
      if (c < levels - 1) cuts[c] -= w * fu;
      if (c > 0) cuts[c - 1] += w * fl;
    }
    let tail = 0;
    for (let c = levels - 2; c >= 0; c--) {
      tail += cuts[c];
      gradient[d + c] = tail * (c === 0 ? 1 : Math.exp(parameters[d + c]));
    }
    return { value, gradient };
  };
}
function fitOrdinal(x, y, levels) {
  const data = augmentConditional(x, y, levels), d = x[0].length, counts = Array(levels).fill(0);
  const means = Array.from(
    { length: d },
    (_, j) => x.reduce((s, row) => s + row[j], 0) / x.length
  ), sds = means.map(
    (mean, j) => Math.sqrt(
      x.reduce((s, row) => s + (row[j] - mean) ** 2, 0) / (x.length - 1)
    )
  );
  if (sds.some((sd) => !(sd > 0)))
    throw new EfaError(
      "constant-predictor",
      "An imputation predictor is constant. Revise the predictor specification."
    );
  const scaled = {
    ...data,
    x: data.x.map((row) => row.map((v, j) => (v - means[j]) / sds[j]))
  };
  data.y.forEach((c, i) => counts[c] += data.weights[i]);
  const total = counts.reduce((a, b) => a + b, 0), cuts = [];
  let sum = 0;
  for (let c = 0; c < levels - 1; c++) {
    sum += counts[c];
    cuts.push(Math.log(sum / (total - sum)));
  }
  const initial = [
    ...Array(d).fill(0),
    cuts[0],
    ...cuts.slice(1).map((v, i) => Math.log(v - cuts[i]))
  ], fit = minimize(ordinalObjective(scaled, levels), initial);
  const thresholds = [fit.parameters[d]];
  for (let c = 1; c < levels - 1; c++)
    thresholds.push(thresholds[c - 1] + Math.exp(fit.parameters[d + c]));
  const coefficients = fit.parameters.slice(0, d).map((v, j) => v / sds[j]), offset = dot(coefficients, means);
  return {
    coefficients,
    thresholds: thresholds.map((t) => t + offset),
    objective: fit.value * total,
    iterations: fit.iterations,
    gradient: fit.gradientNorm,
    augmented: data.augmented
  };
}
function ordinalProbabilities(fit, x) {
  return x.map((row) => {
    const eta = dot(row, fit.coefficients), cdf = [0, ...fit.thresholds.map((t) => logistic(t - eta)), 1];
    return cdf.slice(1).map((v, i) => v - cdf[i]);
  });
}
function drawOrdinal(probabilities, uniforms) {
  if (probabilities.length !== uniforms.length || uniforms.some((u) => !Number.isFinite(u) || u < 0 || u >= 1) || probabilities.some(
    (row) => !row.length || row.some((p) => !Number.isFinite(p) || p < 0) || Math.abs(row.reduce((a, b) => a + b, 0) - 1) > 1e-10
  ))
    throw new EfaError("draws", "Invalid saved imputation draws.");
  return probabilities.map((row, i) => {
    let cumulative = 0;
    for (let c = 0; c < row.length; c++) {
      cumulative += row[c];
      if (uniforms[i] < cumulative) return c;
    }
    return row.length - 1;
  });
}
function binaryConditionalDraw(x, y, normals, uniforms) {
  const fit = fitOrdinal(x, y, 2), data = augmentConditional(x, y, 2), d = x[0].length + 1;
  if (normals.length !== d || normals.some((v) => !Number.isFinite(v)))
    throw new EfaError(
      "draws",
      "Binary regression needs one normal draw per coefficient."
    );
  const beta = [-fit.thresholds[0], ...fit.coefficients], information = Matrix2.zeros(d, d);
  for (let i = 0; i < data.x.length; i++) {
    const row = [1, ...data.x[i]], p = logistic(dot(row, beta)), w = data.weights[i] * p * (1 - p);
    for (let j = 0; j < d; j++)
      for (let k = 0; k < d; k++)
        information.set(j, k, information.get(j, k) + w * row[j] * row[k]);
  }
  let covariance2, lower;
  try {
    covariance2 = inverse2(information);
    for (let j = 0; j < d; j++)
      for (let k = 0; k < j; k++) {
        const v = (covariance2.get(j, k) + covariance2.get(k, j)) / 2;
        covariance2.set(j, k, v);
        covariance2.set(k, j, v);
      }
    lower = new CholeskyDecomposition2(covariance2).lowerTriangularMatrix;
  } catch {
    throw new EfaError(
      "singular-imputation-model",
      "The binary imputation information matrix is singular. Revise predictors."
    );
  }
  const sampled = beta.map(
    (b, j) => b + normals.reduce((s, z, k) => s + lower.get(j, k) * z, 0)
  );
  const missing = y.flatMap((v, i) => v === null ? [i] : []);
  if (uniforms.length !== missing.length || uniforms.some((u) => u < 0 || u >= 1))
    throw new EfaError("draws", "Invalid binary imputation draws.");
  return {
    fit,
    beta,
    covariance: covariance2.to2DArray(),
    sampled,
    probabilities: missing.map((i) => logistic(dot([1, ...x[i]], sampled))),
    draws: missing.map(
      (i, j) => uniforms[j] <= logistic(dot([1, ...x[i]], sampled)) ? 1 : 0
    )
  };
}

// src/lib/efa/prepared-sample.ts
function preparedSample(source, codes, observed, rows = source.rows, originalRowCount = source.originalRowCount) {
  const n = rows.length, p = source.items.length, means = Array(p).fill(0), sds = Array(p).fill(0), counts = source.items.map((item) => Array(item.categories.length).fill(0));
  if (codes.length !== n * p || observed.length !== codes.length)
    throw new EfaError("sample", "Invalid prepared response dimensions.");
  for (let j = 0; j < p; j++) {
    let count = 0;
    for (let i = 0; i < n; i++)
      if (observed[j * n + i]) {
        const c = codes[j * n + i];
        if (c >= counts[j].length)
          throw new EfaError("category", "Invalid resampled category.");
        counts[j][c]++;
        means[j] += c + 1;
        count++;
      }
    if (count < 2 || counts[j].filter((c) => c > 0).length < 2)
      throw new EfaError(
        "constant-item",
        `Item ${source.items[j].column} is constant or unobserved in this sample.`
      );
    means[j] /= count;
    for (let i = 0; i < n; i++)
      if (observed[j * n + i]) sds[j] += (codes[j * n + i] + 1 - means[j]) ** 2;
    sds[j] = Math.sqrt(sds[j] / (count - 1));
  }
  return {
    ...source,
    fingerprint: void 0,
    codes,
    observed,
    rows: rows.slice(),
    nRows: n,
    originalRowCount,
    means,
    sds,
    counts
  };
}

// src/lib/efa/mice.ts
function validateMiceOptions(options, p) {
  if (!Number.isInteger(options.imputations) || options.imputations < 2 || options.imputations > 100 || !Number.isInteger(options.iterations) || options.iterations < 1 || options.iterations > 100 || !Number.isSafeInteger(options.seed) || !Number.isSafeInteger(options.seed + (options.imputations - 1) * 104729))
    throw new EfaError(
      "mice-settings",
      "Use 2\u2013100 imputations, 1\u2013100 iterations and an integer seed whose chain offsets stay within JavaScript's safe integer range."
    );
  if (!Array.isArray(options.predictors) || options.predictors.length !== p || options.predictors.some(
    (row, j) => !Array.isArray(row) || new Set(row).size !== row.length || row.some((i) => !Number.isInteger(i) || i < 0 || i >= p || i === j)
  ))
    throw new EfaError(
      "predictors",
      "Specify unique valid predictors for each item, excluding the target itself."
    );
  if (!["ordered-polynomial", "rank"].includes(
    options.predictorEncoding ?? "ordered-polynomial"
  ))
    throw new EfaError(
      "predictor-encoding",
      "Choose ordered-polynomial contrasts or ordinal ranks explicitly."
    );
}
function ordinalContrasts(levels) {
  if (!Number.isInteger(levels) || levels < 2 || levels > MAX_CONDITIONAL_LEVELS)
    throw new EfaError(
      "mice-categories",
      `Ordered-polynomial MICE supports 2\u2013${MAX_CONDITIONAL_LEVELS} declared categories per item. Review the category metadata or explicitly choose rank predictors.`
    );
  if (levels === 2) return [[0], [1]];
  const grid = Array.from(
    { length: levels },
    (_, i) => (2 * i - levels + 1) / (levels - 1)
  );
  const q = new QrDecomposition2(
    new Matrix2(
      grid.map(
        (x) => Array.from({ length: levels }, (_, degree) => x ** degree)
      )
    )
  ).orthogonalMatrix;
  return grid.map(
    (_, i) => Array.from(
      { length: levels - 1 },
      (_2, j) => q.get(i, j + 1) * (q.get(levels - 1, j + 1) < 0 ? -1 : 1)
    )
  );
}
function imputeMice(source, options, progress, savedDraws, chainIndices) {
  const p = source.items.length, n = source.nRows;
  validateMiceOptions(options, p);
  const encoding = options.predictorEncoding ?? "ordered-polynomial";
  const contrasts = source.items.map(
    (item) => encoding === "rank" ? item.categories.map((_, i) => [i + 1]) : ordinalContrasts(item.categories.length)
  );
  const chains = chainIndices ?? Array.from({ length: options.imputations }, (_, i) => i);
  if (!chains.length || new Set(chains).size !== chains.length || chains.some(
    (i) => !Number.isInteger(i) || i < 0 || i >= options.imputations
  ))
    throw new EfaError("mice-chains", "Invalid imputation chain selection.");
  const missing = source.items.map(
    (_, j) => Array.from({ length: n }, (_2, i) => i).filter(
      (i) => !source.observed[j * n + i]
    )
  ), targets = missing.flatMap((rows, j) => rows.length ? [j] : []);
  if (!targets.length)
    throw new EfaError(
      "no-missing",
      "These selected items have no missing responses. Fit the observed data directly."
    );
  const result = {
    options: structuredClone({ ...options, predictorEncoding: encoding }),
    completed: [],
    failures: [],
    trace: [],
    missingPositions: targets.flatMap((j) => missing[j].map((i) => j * n + i)),
    provenance: {
      method: `mice 3.18 ordinal polr and binary logreg conditional conventions; ${encoding} predictors; no multinomial fallback`,
      generator: "mulberry32; independent chain seeds; saved draws supported for R qualification",
      seed: options.seed
    }
  };
  for (const m of chains) {
    const random = mulberry32(options.seed + m * 104729), codes = source.codes.slice();
    let iteration = 0, item = -1;
    const draws = (kind, count) => {
      const request = { imputation: m, iteration, item, kind, count };
      const values = savedDraws ? savedDraws(request) : Array.from(
        { length: count },
        () => kind === "normal" ? Math.sqrt(-2 * Math.log(Math.max(Number.MIN_VALUE, random()))) * Math.cos(2 * Math.PI * random()) : random()
      );
      if (values.length !== count || values.some(
        (v) => !Number.isFinite(v) || kind !== "normal" && (v < 0 || v >= 1)
      ))
        throw new EfaError("mice-draws", "Invalid imputation random draws.");
      return values;
    };
    try {
      for (item of targets) {
        const donors = Array.from({ length: n }, (_, i) => i).filter(
          (i) => source.observed[item * n + i]
        ), u = draws("initial", missing[item].length);
        if (!donors.length)
          throw new EfaError(
            "unobserved-item",
            "An all-missing item cannot be imputed from this fitting sample."
          );
        missing[item].forEach(
          (row, i) => codes[item * n + row] = source.codes[item * n + donors[Math.floor(u[i] * donors.length)]]
        );
      }
      for (iteration = 1; iteration <= options.iterations; iteration++)
        for (let visit = 0; visit < targets.length; visit++) {
          item = targets[visit];
          const predictors = options.predictors[item], x = Array.from(
            { length: n },
            (_, i) => predictors.flatMap((j) => contrasts[j][codes[j * n + i]])
          ), y = Array.from(
            { length: n },
            (_, i) => source.observed[item * n + i] ? source.codes[item * n + i] : null
          ), levels = source.items[item].categories.length;
          let values, iterations, gradient;
          if (levels === 2) {
            const normal = draws("normal", x[0].length + 1), uniform = draws("uniform", missing[item].length), fit = binaryConditionalDraw(x, y, normal, uniform);
            values = fit.draws;
            iterations = fit.fit.iterations;
            gradient = fit.fit.gradient;
          } else {
            const fit = fitOrdinal(x, y, levels), probabilities = ordinalProbabilities(
              fit,
              missing[item].map((i) => x[i])
            );
            values = drawOrdinal(
              probabilities,
              draws("uniform", missing[item].length)
            );
            iterations = fit.iterations;
            gradient = fit.gradient;
          }
          missing[item].forEach(
            (row, i) => codes[item * n + row] = values[i]
          );
          const mean = values.reduce((sum, c) => sum + c + 1, 0) / values.length, sd = values.length > 1 ? Math.sqrt(
            values.reduce((sum, c) => sum + (c + 1 - mean) ** 2, 0) / (values.length - 1)
          ) : 0, counts = Array(levels).fill(0);
          values.forEach((c) => counts[c]++);
          result.trace.push({
            imputation: m,
            iteration,
            item,
            mean,
            sd,
            counts,
            regressionIterations: iterations,
            gradient
          });
          progress?.({
            stage: `MICE \xB7 imputation ${m + 1}, iteration ${iteration}, item ${item + 1}`,
            completed: (m * options.iterations + iteration - 1) * targets.length + visit + 1,
            total: options.imputations * options.iterations * targets.length
          });
        }
      result.completed.push({
        imputation: m,
        data: preparedSample(
          source,
          codes,
          new Uint8Array(codes.length).fill(1)
        )
      });
    } catch (error) {
      result.failures.push({
        imputation: m,
        iteration,
        item,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
  return result;
}

// src/lib/efa/stability.ts
function alignReplica(reference, result, replicate) {
  const { mapping, signs, congruence } = matchFactors(
    reference.rotation.pattern,
    result.rotation.pattern
  );
  if (mapping.some((i) => i === null))
    throw new EfaError(
      "factor-matching",
      "A resampled fit has unmatched factors."
    );
  const aligned = (matrix2) => matrix2.map((row) => mapping.map((j, k) => row[j] * signs[k]));
  return {
    replicate,
    pattern: aligned(result.rotation.pattern),
    structure: aligned(result.structure),
    phi: mapping.map(
      (i, a) => mapping.map((j, b) => result.rotation.phi[i][j] * signs[a] * signs[b])
    ),
    communalities: result.communalities,
    uniquenesses: result.uniquenesses,
    congruence,
    rmsr: result.rmsr,
    diagnostics: {
      boundaryItems: result.extraction.boundaryItems.slice(),
      improper: result.uniquenesses.some((v) => v < 0),
      conditionNumber: result.conditionNumber
    }
  };
}
function bootstrapIndices(n, seed, groups) {
  const random = mulberry32(seed);
  if (!groups) return Array.from({ length: n }, () => Math.floor(random() * n));
  if (groups.length !== n || groups.some((g) => typeof g !== "string" || !g))
    throw new EfaError(
      "resampling-groups",
      "Every fitting respondent needs a group identifier."
    );
  const units = /* @__PURE__ */ new Map();
  groups.forEach((g, i) => {
    const rows = units.get(g) ?? [];
    rows.push(i);
    units.set(g, rows);
  });
  if (units.size < 2)
    throw new EfaError(
      "resampling-groups",
      "Group resampling requires at least two groups."
    );
  const entries = [...units.values()];
  return Array.from(
    { length: entries.length },
    () => entries[Math.floor(random() * entries.length)]
  ).flat();
}
function resampleData(source, indices) {
  const n = indices.length, p = source.items.length;
  if (n < 3 || indices.some((i) => !Number.isInteger(i) || i < 0 || i >= source.nRows))
    throw new EfaError("resample", "Invalid respondent resample.");
  const codes = new Uint16Array(n * p), observed = new Uint8Array(n * p);
  for (let j = 0; j < p; j++)
    for (let i = 0; i < n; i++) {
      codes[j * n + i] = source.codes[j * source.nRows + indices[i]];
      observed[j * n + i] = source.observed[j * source.nRows + indices[i]];
    }
  return preparedSample(
    source,
    codes,
    observed,
    indices.map((_, i) => i),
    n
  );
}
function stabilityReplicate(source, spec, reference, options, index, savedSample, progress) {
  const indices = savedSample?.slice() ?? bootstrapIndices(source.nRows, options.seed + index, options.groups);
  try {
    const sample = resampleData(source, indices), fit = fitEfa(
      sample,
      correlate(sample, progress),
      spec.extraction === "wlsmv" ? { ...spec, extraction: "dwls" } : spec,
      progress
    );
    return { indices, replica: alignReplica(reference, fit, index) };
  } catch (error) {
    return {
      indices,
      failure: {
        replicate: index,
        error: error instanceof Error ? error.message : String(error)
      }
    };
  }
}

// src/lib/efa/imputation-analysis.ts
function fitImputationChain(source, spec, options, imputation, progress, savedDraws) {
  const imputed = imputeMice(source, options, progress, savedDraws, [
    imputation
  ]);
  if (imputed.failures.length)
    return {
      trace: imputed.trace,
      failure: { ...imputed.failures[0], stage: "imputation" }
    };
  const complete = imputed.completed[0].data;
  try {
    const result = fitEfa(
      complete,
      correlate(complete, progress),
      spec,
      progress
    );
    return {
      trace: imputed.trace,
      fit: {
        imputation,
        replacements: imputed.missingPositions.map((i) => complete.codes[i]),
        result
      }
    };
  } catch (error) {
    return {
      trace: imputed.trace,
      failure: {
        imputation,
        stage: "fit",
        error: error instanceof Error ? error.message : String(error)
      }
    };
  }
}
function observedPairFloor(source) {
  let minimum = Math.min(
    5,
    ...source.counts.map((counts) => counts.reduce((a, b) => a + b, 0))
  );
  for (let i = 0; i < source.items.length && minimum > 0; i++)
    for (let j = i + 1; j < source.items.length && minimum > 0; j++) {
      let count = 0;
      for (let row = 0; row < source.nRows; row++)
        if (source.observed[i * source.nRows + row] && source.observed[j * source.nRows + row] && ++count >= minimum)
          break;
      minimum = Math.min(minimum, count);
    }
  return minimum;
}

// src/lib/efa/fingerprint.ts
async function fingerprintPrepared(data) {
  const meta = new TextEncoder().encode(
    JSON.stringify({
      items: data.items,
      rows: data.rows,
      originalRowCount: data.originalRowCount
    })
  );
  const bytes = new Uint8Array(
    meta.byteLength + data.codes.byteLength + data.observed.byteLength
  );
  bytes.set(meta);
  bytes.set(
    new Uint8Array(
      data.codes.buffer,
      data.codes.byteOffset,
      data.codes.byteLength
    ),
    meta.byteLength
  );
  bytes.set(data.observed, meta.byteLength + data.codes.byteLength);
  return Array.from(
    new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)),
    (b) => b.toString(16).padStart(2, "0")
  ).join("");
}

// src/lib/efa/telemetry.ts
function computeStageName(stage) {
  return stage.startsWith("MICE") ? "MICE" : stage.startsWith("Parallel analysis") ? "Parallel analysis" : stage.startsWith("Resampling stability") ? "Resampling stability" : stage.split(" \xB7 ")[0];
}
var WorkerStageTimer = class {
  constructor(stage) {
    this.stage = stage;
    this.started = performance.now();
    this.durations = {};
  }
  change(stage) {
    stage = computeStageName(stage);
    if (stage === this.stage) return;
    this.flush();
    this.stage = stage;
  }
  flush() {
    const now = performance.now();
    const key = Object.keys(this.durations).length < 127 || this.stage in this.durations ? this.stage : "Other stages";
    this.durations[key] = (this.durations[key] ?? 0) + now - this.started;
    this.started = now;
  }
  finish() {
    this.flush();
    return this.durations;
  }
};

// src/lib/efa/efa.worker.ts
var prepared;
var rotationContext;
var continuation;
var rotationTask;
var accumulator;
var execution;
var invariant;
var cachedInference;
self.onmessage = async (event) => {
  const request = event.data, id = request.id, started = performance.now();
  const timer = new WorkerStageTimer(request.op === "pairs" ? "Correlations" : request.op);
  const progress = (value) => {
    timer.change(value.stage);
    self.postMessage({ id, progress: value });
  };
  try {
    let value;
    if (request.op === "fit-cache") {
      if (!invariant || !cachedInference || continuation) throw new EfaError("worker", "No completed invariant fit state.");
      const q = cachedInference.covariance.rows, covariance2 = new Float64Array(q * q);
      for (let i = 0; i < q; i++) for (let j = 0; j < q; j++) covariance2[i * q + j] = cachedInference.covariance.get(i, j);
      value = { ...invariant, execution, inference: { ...cachedInference, covariance: covariance2 } };
      invariant = void 0;
      cachedInference = void 0;
    } else if (request.op === "rotation-initialize") {
      prepared = void 0;
      rotationContext = request.context;
      value = true;
    } else if (request.op === "rotation-batch") {
      if (!rotationContext) throw new EfaError("worker", "Rotation worker has not been initialized.");
      value = rotationDerivativeBatch(rotationContext, request.start, request.count);
    } else if (request.op === "rotation-accept") {
      if (!accumulator) throw new EfaError("worker", "No pending rotation uncertainty.");
      accumulator.add(request.batch);
      value = accumulator.completed;
    } else if (request.op === "fit-finish") {
      if (!continuation || !rotationTask || !accumulator) throw new EfaError("worker", "No pending fit continuation.");
      const done = continuation.next(accumulator.finish(rotationTask.covariance, progress));
      if (!done.done) throw new EfaError("worker", "Unexpected additional fit continuation.");
      if (execution) done.value.provenance.execution = execution;
      value = done.value;
      continuation = void 0;
      rotationTask = void 0;
      accumulator = void 0;
      rotationContext = void 0;
    } else if (request.op === "prepare") {
      prepared = prepareEfa(request.table, request.spec, request.rows);
      prepared.fingerprint = await fingerprintPrepared(prepared);
      value = prepared;
    } else if (request.op === "initialize") {
      prepared = request.data;
      value = true;
    } else {
      if (!prepared)
        throw new EfaError("worker", "Worker has not been prepared.");
      switch (request.op) {
        case "observed-support":
          value = observedPairFloor(prepared);
          break;
        case "imputation": {
          const chain = fitImputationChain(
            prepared,
            request.spec,
            request.options,
            request.index,
            progress
          );
          if (chain.fit) {
            const codes = prepared.codes.slice();
            let position = 0;
            for (let i = 0; i < codes.length; i++)
              if (!prepared.observed[i])
                codes[i] = chain.fit.replacements[position++];
            chain.fit.result.provenance.inputSha256 = await fingerprintPrepared(
              {
                ...prepared,
                codes,
                observed: new Uint8Array(codes.length).fill(1)
              }
            );
          }
          value = chain;
          break;
        }
        case "stability":
          value = stabilityReplicate(
            prepared,
            request.spec,
            request.reference,
            request.options,
            request.index,
            void 0,
            progress
          );
          break;
        case "parallel-observed":
          value = parallelObserved(prepared, request.minimumPairN, progress);
          break;
        case "parallel-replicate":
          value = parallelReplicate(prepared, request.seed, progress);
          break;
        case "pairs":
          value = request.pairs.map(([i, j]) => polychoric(prepared, i, j));
          break;
        case "fit":
          if (request.parallelDerivatives && request.spec.extraction === "wlsmv") {
            invariant = void 0;
            cachedInference = void 0;
            continuation = fitEfaSteps(prepared, request.correlation, request.spec, progress, request.extraction, request.invariant, (base) => {
              invariant = base;
            });
            const settings = computeSettings(request.spec);
            const backend = !request.invariant && settings.backend !== "cpu" ? await createBackend(
              request.spec,
              request.companion,
              (value2) => {
                execution = value2;
                self.postMessage({ id, execution: value2 });
              },
              progress
            ) : void 0;
            execution = request.invariant?.execution ? { ...request.invariant.execution, reusedFromJobId: request.invariant.sourceJobId, timings: void 0 } : backend ? execution : { ...settings, state: "running", precision: "float64" };
            if (request.invariant) self.postMessage({ id, execution });
            let step;
            try {
              step = continuation.next();
              if (!request.invariant) {
                if (step.done || step.value.kind !== "inference") throw new EfaError("worker", "Missing weighted inference task.");
                const inference = backend ? await weightedInferenceWithKernel((block) => backend.run(block), ...step.value.args) : weightedInference(...step.value.args);
                cachedInference = inference;
                if (backend) execution = backend.finish();
                else if (execution) execution.state = "completed";
                step = continuation.next(inference);
              }
            } finally {
              backend?.destroy();
            }
            if (step.done || step.value.kind !== "rotation") throw new EfaError("worker", "Missing weighted rotation task.");
            rotationTask = step.value;
            rotationContext = rotationTask.context;
            accumulator = new RotationDerivativeAccumulator(rotationContext);
            value = { rotationContext };
          } else value = fitEfa(prepared, request.correlation, request.spec, progress, request.extraction);
          break;
        case "score":
          if (prepared.fingerprint !== request.result.provenance.inputSha256)
            throw new EfaError(
              "changed-data",
              "The selected responses or row membership changed since this fit. Refit before adding scores."
            );
          value = scoreEfa(prepared, request.result);
          break;
        case "parallel":
          value = parallelAnalysis(
            prepared,
            request.seed,
            request.replicates,
            progress,
            request.minimumPairN
          );
          break;
      }
    }
    self.postMessage(
      { id, value, workerMs: performance.now() - started, workerStages: timer.finish() },
      { transfer: request.op === "fit-cache" ? [value.inference.covariance.buffer] : request.op === "rotation-batch" ? [value.values.buffer] : [] }
    );
  } catch (error) {
    continuation = void 0;
    rotationTask = void 0;
    accumulator = void 0;
    rotationContext = void 0;
    invariant = void 0;
    cachedInference = void 0;
    self.postMessage({
      id,
      workerMs: performance.now() - started,
      workerStages: timer.finish(),
      error: {
        code: error instanceof EfaError ? error.code : "worker",
        message: error instanceof Error ? error.message : String(error),
        diagnostics: error instanceof EfaError ? error.diagnostics : []
      }
    });
  }
};
