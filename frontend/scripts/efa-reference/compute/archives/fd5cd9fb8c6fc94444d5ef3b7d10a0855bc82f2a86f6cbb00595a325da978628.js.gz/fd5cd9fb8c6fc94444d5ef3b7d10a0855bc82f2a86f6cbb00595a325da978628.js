// scripts/efa-reference/compute/split-shader.mjs
var splitShader = `
struct Shape { rows: u32, cols: u32, pairs: u32, parameters: u32 }
@group(0) @binding(0) var<storage, read> a: array<vec2<f32>>;
@group(0) @binding(1) var<storage, read> b: array<vec2<f32>>;
@group(0) @binding(2) var<storage, read> za: array<vec2<f32>>;
@group(0) @binding(3) var<storage, read> zb: array<vec2<f32>>;
@group(0) @binding(4) var<storage, read_write> out: array<vec4<f32>>;
@group(0) @binding(5) var<uniform> shape: Shape;
var<workgroup> tileA: array<vec2<f32>, 256>;
var<workgroup> tileB: array<vec2<f32>, 256>;
@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) group: vec3<u32>) {
  let row = gid.y; let col = gid.x; let t = lid.y * 16u + lid.x;
  let begin = group.z * 256u;
  var hi = 0.0; var lo = 0.0;
  for (var offset = begin; offset < min(begin + 256u, shape.pairs); offset += 16u) {
    tileA[t] = vec2<f32>(0.0); tileB[t] = vec2<f32>(0.0);
    if (row < shape.rows && offset + lid.x < shape.pairs) { tileA[t] = a[row * shape.pairs + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.pairs) { tileB[t] = b[bRow * shape.pairs + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) {
      let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k];
      let product = av.x * bv.x;
      let residual = fma(av.x, bv.x, -product) + av.x * bv.y + av.y * bv.x + av.y * bv.y;
      hi += product; lo += residual;
    }
    workgroupBarrier();
  }
  let aHi = hi; let aLo = lo; hi = 0.0; lo = 0.0;
  for (var offset = begin; offset < min(begin + 256u, shape.parameters); offset += 16u) {
    tileA[t] = vec2<f32>(0.0); tileB[t] = vec2<f32>(0.0);
    if (row < shape.rows && offset + lid.x < shape.parameters) { tileA[t] = za[row * shape.parameters + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.parameters) { tileB[t] = zb[bRow * shape.parameters + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) {
      let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k];
      let product = av.x * bv.x;
      let residual = fma(av.x, bv.x, -product) + av.x * bv.y + av.y * bv.x + av.y * bv.y;
      hi += product; lo += residual;
    }
    workgroupBarrier();
  }
  let chunks = (max(shape.pairs, shape.parameters) + 255u) / 256u;
  if (row < shape.rows && col < shape.cols) { out[(row * shape.cols + col) * chunks + group.z] = vec4<f32>(aHi, aLo, hi, lo); }
}`;
var replacements = [
  ["parameters: u32 }", "parameters: u32, leftStart: u32, rightStart: u32 }"],
  ["var<storage, read> a: array<vec2<f32>>;", "var<storage, read> codes: array<u32>;"],
  ["var<storage, read> b: array<vec2<f32>>;", "var<storage, read> pairs: array<vec4<u32>>;"],
  ["var<storage, read> za: array<vec2<f32>>;", "var<storage, read> lookup: array<vec2<f32>>;"],
  ["var<storage, read> zb: array<vec2<f32>>;", "var<storage, read> projection: array<vec2<f32>>;"],
  ["a[row * shape.pairs + offset + lid.x]", "ordinal(shape.leftStart + row, offset + lid.x)"],
  ["b[bRow * shape.pairs + offset + lid.x]", "ordinal(shape.rightStart + bRow, offset + lid.x)"],
  ["za[row * shape.parameters + offset + lid.x]", "projection[(shape.leftStart + row) * shape.parameters + offset + lid.x]"],
  ["zb[bRow * shape.parameters + offset + lid.x]", "projection[(shape.rightStart + bRow) * shape.parameters + offset + lid.x]"]
];
var residentShader = replacements.reduce((source, [before, after]) => {
  if (!source.includes(before)) throw new Error(`Resident shader template mismatch: ${before}`);
  return source.replace(before, after);
}, splitShader) + `
fn rank(index: u32) -> u32 { return (codes[index / 2u] >> ((index % 2u) * 16u)) & 65535u; }
fn ordinal(row: u32, pair: u32) -> vec2<f32> {
  let pairInfo = pairs[pair]; let x = rank(pairInfo.x + row); let y = rank(pairInfo.y + row);
  if (x == 65535u || y == 65535u) { return vec2<f32>(0.0); }
  return lookup[pairInfo.w + x * pairInfo.z + y];
}`;

// scripts/efa-reference/compute/reduce-shader.mjs
var reduceShader = `
struct Shape { outputs: u32, chunks: u32, unused0: u32, unused1: u32 }
@group(0) @binding(0) var<storage, read> partials: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read_write> result: array<vec4<f32>>;
@group(0) @binding(2) var<uniform> shape: Shape;
var<workgroup> sums: array<vec4<f32>, 256>;
fn pairAdd(a: vec2<f32>, b: vec2<f32>) -> vec2<f32> {
  let sum = a.x + b.x;
  let delta = sum - a.x;
  let error = (a.x - (sum - delta)) + (b.x - delta) + a.y + b.y;
  let hi = sum + error;
  return vec2<f32>(hi, error - (hi - sum));
}
fn add(a: vec4<f32>, b: vec4<f32>) -> vec4<f32> {
  return vec4<f32>(pairAdd(a.xy, b.xy), pairAdd(a.zw, b.zw));
}
@compute @workgroup_size(256)
fn main(@builtin(local_invocation_id) local: vec3<u32>, @builtin(workgroup_id) group: vec3<u32>) {
  var value = vec4<f32>(0.0);
  for (var chunk = local.x; chunk < shape.chunks; chunk += 256u) {
    value = add(value, partials[group.x * shape.chunks + chunk]);
  }
  sums[local.x] = value;
  workgroupBarrier();
  for (var stride = 128u; stride > 0u; stride /= 2u) {
    if (local.x < stride) { sums[local.x] = add(sums[local.x], sums[local.x + stride]); }
    workgroupBarrier();
  }
  if (local.x == 0u) { result[group.x] = sums[0]; }
}`;
function compensateSplit(source) {
  const fragment = "hi += product; lo += residual;";
  if (source.split(fragment).length !== 3) throw new Error("Split compensation template mismatch");
  return source.replaceAll(fragment, `
      let next = hi + product;
      if (abs(hi) >= abs(product)) { lo += (hi - next) + product; }
      else { lo += (product - next) + hi; }
      lo += residual;
      hi = next;`);
}

// scripts/efa-reference/compute/webgpu-kernel.mjs
async function createGpuKernel({ compensated = true, split = false, resident = false, compensatedSplit = false, reduce = false, strictMath, signal } = {}) {
  split ||= resident;
  if ((compensatedSplit || reduce) && !split) throw new Error("Split precision is required for these experiments");
  const startup = performance.now();
  if (!navigator.gpu) throw new Error("WebGPU unavailable");
  const adapter = await navigator.gpu.requestAdapter({ powerPreference: "high-performance" });
  if (!adapter || adapter.info.isFallbackAdapter) throw new Error("No hardware WebGPU adapter");
  const timestamps = adapter.features.has("timestamp-query");
  const bindingLimit = Math.min(512 * 1024 ** 2, adapter.limits.maxStorageBufferBindingSize, adapter.limits.maxBufferSize);
  const device = await adapter.requestDevice({ requiredFeatures: timestamps ? ["timestamp-query"] : [], ...resident ? { requiredLimits: { maxStorageBufferBindingSize: bindingLimit, maxBufferSize: bindingLimit } } : {} });
  let lost;
  void device.lost.then((info2) => {
    lost = info2.message || "GPU device lost";
  });
  const abort = () => device.destroy();
  signal?.addEventListener("abort", abort, { once: true });
  const add = compensated ? "let t = av * bv - correction; let next = sum + t; correction = (next - sum) - t; sum = next;" : "sum += av * bv;";
  let code = resident ? residentShader : split ? splitShader : `
struct Shape { rows: u32, cols: u32, pairs: u32, parameters: u32 }
@group(0) @binding(0) var<storage, read> a: array<f32>;
@group(0) @binding(1) var<storage, read> b: array<f32>;
@group(0) @binding(2) var<storage, read> za: array<f32>;
@group(0) @binding(3) var<storage, read> zb: array<f32>;
@group(0) @binding(4) var<storage, read_write> out: array<f32>;
@group(0) @binding(5) var<uniform> shape: Shape;
var<workgroup> tileA: array<f32, 256>;
var<workgroup> tileB: array<f32, 256>;
@compute @workgroup_size(16, 16)
fn main(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) group: vec3<u32>) {
  let row = gid.y; let col = gid.x; let t = lid.y * 16u + lid.x;
  var sum = 0.0; var correction = 0.0;
  for (var offset = 0u; offset < shape.pairs; offset += 16u) {
    tileA[t] = 0.0; tileB[t] = 0.0;
    if (row < shape.rows && offset + lid.x < shape.pairs) { tileA[t] = a[row * shape.pairs + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.pairs) { tileB[t] = b[bRow * shape.pairs + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) { let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k]; ${add} }
    workgroupBarrier();
  }
  let product = sum; sum = 0.0; correction = 0.0;
  for (var offset = 0u; offset < shape.parameters; offset += 16u) {
    tileA[t] = 0.0; tileB[t] = 0.0;
    if (row < shape.rows && offset + lid.x < shape.parameters) { tileA[t] = za[row * shape.parameters + offset + lid.x]; }
    let bRow = group.x * 16u + lid.y;
    if (bRow < shape.cols && offset + lid.x < shape.parameters) { tileB[t] = zb[bRow * shape.parameters + offset + lid.x]; }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k++) { let av = tileA[lid.y * 16u + k]; let bv = tileB[lid.x * 16u + k]; ${add} }
    workgroupBarrier();
  }
  if (row < shape.rows && col < shape.cols) { out[row * shape.cols + col] = product - sum; }
}`;
  if (compensatedSplit) code = compensateSplit(code);
  let strictMathRecognized = strictMath === void 0 ? null : false;
  const module = (code2) => {
    const descriptor = { code: code2 };
    if (strictMath !== void 0) Object.defineProperty(descriptor, "strictMath", { enumerable: true, get() {
      strictMathRecognized = true;
      return strictMath;
    } });
    const shader = device.createShaderModule(descriptor);
    if (strictMath === true && !strictMathRecognized) {
      device.destroy();
      throw new Error("strictMath was not recognized; this experiment requires the developer-only browser feature");
    }
    return shader;
  };
  const shaderModule = module(code);
  const info = await shaderModule.getCompilationInfo();
  if (info.messages.some((m) => m.type === "error")) {
    device.destroy();
    throw new Error(info.messages.map((m) => m.message).join("\n"));
  }
  const pipeline = await device.createComputePipelineAsync({ layout: "auto", compute: { module: shaderModule, entryPoint: "main" } });
  const reductionPipeline = reduce ? await device.createComputePipelineAsync({ layout: "auto", compute: { module: module(reduceShader), entryPoint: "main" } }) : void 0;
  const queryCount = reduce ? 4 : 2, queryBytes = queryCount * 8;
  const query = timestamps ? device.createQuerySet({ type: "timestamp", count: queryCount }) : void 0;
  const queryResolve = timestamps ? device.createBuffer({ size: queryBytes, usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC }) : void 0;
  const queryRead = timestamps ? device.createBuffer({ size: queryBytes, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST }) : void 0;
  const reductionShape = reduce ? device.createBuffer({ size: 16, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST }) : void 0;
  let reduced, reducedCapacity = 0;
  let buffers = [], capacities = [], sourceSizes, currentSource, read, readSize = 0, dispatchObserver;
  const timings = { startupMs: performance.now() - startup, packMs: 0, uploadSubmitMs: 0, dispatchReadbackMs: 0, readMapWaitMs: 0, hostReductionMs: 0, gpuMs: timestamps ? 0 : null, reductionGpuMs: timestamps && reduce ? 0 : null, calls: 0, uploadedBytes: 0, readbackBytes: 0, peakOwnedGpuBufferBytes: 0, sourceInitializations: 0 };
  const pack = (rows) => {
    const result = new Float32Array(rows.length * rows[0].length * (split ? 2 : 1));
    if (split) rows.forEach((row, i) => {
      for (let k = 0; k < row.length; k++) {
        const offset = 2 * (i * row.length + k), hi = Math.fround(row[k]);
        result[offset] = hi;
        result[offset + 1] = row[k] - hi;
      }
    });
    else rows.forEach((row, i) => result.set(row, i * row.length));
    return result;
  };
  const packSource = (source) => {
    const codes = new Uint32Array(Math.ceil(source.codes.length / 2));
    for (let i = 0; i < source.codes.length; i++) codes[i >>> 1] |= (source.observed[i] ? source.codes[i] : 65535) << (i & 1) * 16;
    const meta = new Uint32Array(source.pairs.length * 4);
    const lookup = new Float32Array(source.pairs.reduce((sum, pair) => sum + pair.values.length, 0) * 2);
    let at = 0;
    source.pairs.forEach((pair, i) => {
      meta.set([pair.i * source.nRows, pair.j * source.nRows, pair.columns, at / 2], 4 * i);
      for (const value of pair.values) {
        const scaled = value * source.rootWeights[i], hi = Math.fround(scaled);
        lookup[at++] = hi;
        lookup[at++] = scaled - hi;
      }
    });
    return [codes, meta, lookup, pack(source.projection)];
  };
  return {
    metadata: { backend: "webgpu", precision: split ? `${compensatedSplit ? "compensated-" : ""}split-f32/${reduce ? "gpu-pair-reduction/host-f64" : "chunked-host-f64"}` : compensated ? "f32-compensated/host-f64" : "f32/host-f64", strictMathRequested: strictMath ?? null, strictMathRecognized, developerOnly: strictMath === true, transport: resident ? "Resident ordinal source and projections; per-block row ranges only" : "Expanded block inputs uploaded per call", ownedGpuBufferBudgetBytes: 1024 ** 3, adapter: { vendor: adapter.info.vendor, architecture: adapter.info.architecture, device: adapter.info.device, description: adapter.info.description }, timestamps, shader: code, reductionShader: reduce ? reduceShader : void 0 },
    timings,
    setDispatchObserver(observer) {
      dispatchObserver = observer;
    },
    async run(block) {
      if (lost || signal?.aborted) throw new Error(lost || "Cancelled");
      const start = performance.now();
      if (resident && !block.ordinal) throw new Error("Resident GPU kernel requires an ordinal source");
      const ordinal = block.ordinal;
      const shape = resident ? new Uint32Array([ordinal.leftRows, ordinal.rightRows, ordinal.source.pairs.length, ordinal.source.projection[0].length, ordinal.leftStart, ordinal.rightStart, 0, 0]) : new Uint32Array([block.left.length, block.right.length, block.left[0].length, block.leftProjection[0].length]);
      const chunks = split ? Math.ceil(Math.max(shape[2], shape[3]) / 256) : 1;
      const outputBytes = shape[0] * shape[1] * 4 * chunks * (split ? 4 : 1);
      const reducedBytes = reduce ? shape[0] * shape[1] * 16 : 0;
      const readBytes = reduce ? reducedBytes : outputBytes;
      if (resident) {
        const source = ordinal.source;
        const estimate = Math.ceil(source.codes.length / 2) * 4 + source.pairs.length * 16 + source.pairs.reduce((sum, pair) => sum + pair.values.length * 8, 0) + source.nRows * shape[3] * 8 + outputBytes + readBytes + reducedBytes + 128;
        if (estimate > 1024 ** 3) throw new Error("Resident GPU source and blocks exceed the explicit 1 GiB device-buffer budget");
      }
      const inputs = resident ? currentSource === ordinal.source ? void 0 : packSource(ordinal.source) : [pack(block.left), pack(block.right), pack(block.leftProjection), pack(block.rightProjection)];
      if (inputs) sourceSizes = inputs.map((v) => v.byteLength);
      timings.packMs += performance.now() - start;
      const sizes = [...sourceSizes, outputBytes, shape.byteLength];
      if (sizes.some((size) => size > device.limits.maxStorageBufferBindingSize)) throw new Error("Block exceeds GPU storage-buffer limit");
      const retainedBytes = sizes.reduce((sum, size, i) => sum + Math.max(size, capacities[i] ?? 0), 0) + Math.max(readSize, readBytes) + Math.max(reducedCapacity, reducedBytes) + (query ? queryBytes * 2 : 0) + (reduce ? 16 : 0);
      if (retainedBytes > 1024 ** 3) throw new Error("Retained GPU buffers exceed the explicit 1 GiB device-buffer budget");
      const beforeUpload = performance.now();
      sizes.forEach((size, i) => {
        if ((capacities[i] ?? 0) >= size) return;
        buffers[i]?.destroy();
        capacities[i] = size;
        buffers[i] = device.createBuffer({ size, usage: i === 5 ? GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST : GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC });
      });
      if (readSize < readBytes) {
        read?.destroy();
        readSize = readBytes;
        read = device.createBuffer({ size: readSize, usage: GPUBufferUsage.MAP_READ | GPUBufferUsage.COPY_DST });
      }
      if (reduce && reducedCapacity < reducedBytes) {
        reduced?.destroy();
        reducedCapacity = reducedBytes;
        reduced = device.createBuffer({ size: reducedCapacity, usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC });
      }
      inputs?.forEach((input, i) => device.queue.writeBuffer(buffers[i], 0, input));
      if (resident && inputs) {
        currentSource = ordinal.source;
        timings.sourceInitializations++;
      }
      device.queue.writeBuffer(buffers[5], 0, shape);
      if (reduce) device.queue.writeBuffer(reductionShape, 0, new Uint32Array([shape[0] * shape[1], chunks, 0, 0]));
      const bindGroup = device.createBindGroup({ layout: pipeline.getBindGroupLayout(0), entries: buffers.map((buffer, binding) => ({ binding, resource: { buffer, size: sizes[binding] } })) });
      device.pushErrorScope("validation");
      const encoder = device.createCommandEncoder();
      const pass = encoder.beginComputePass(query ? { timestampWrites: { querySet: query, beginningOfPassWriteIndex: 0, endOfPassWriteIndex: 1 } } : {});
      pass.setPipeline(pipeline);
      pass.setBindGroup(0, bindGroup);
      pass.dispatchWorkgroups(Math.ceil(shape[1] / 16), Math.ceil(shape[0] / 16), chunks);
      pass.end();
      if (reduce) {
        const bindings = device.createBindGroup({ layout: reductionPipeline.getBindGroupLayout(0), entries: [
          { binding: 0, resource: { buffer: buffers[4], size: outputBytes } },
          { binding: 1, resource: { buffer: reduced, size: reducedBytes } },
          { binding: 2, resource: { buffer: reductionShape } }
        ] });
        const reduction = encoder.beginComputePass(query ? { timestampWrites: { querySet: query, beginningOfPassWriteIndex: 2, endOfPassWriteIndex: 3 } } : {});
        reduction.setPipeline(reductionPipeline);
        reduction.setBindGroup(0, bindings);
        reduction.dispatchWorkgroups(shape[0] * shape[1]);
        reduction.end();
      }
      encoder.copyBufferToBuffer(reduce ? reduced : buffers[4], 0, read, 0, readBytes);
      if (query) {
        encoder.resolveQuerySet(query, 0, queryCount, queryResolve, 0);
        encoder.copyBufferToBuffer(queryResolve, 0, queryRead, 0, queryBytes);
      }
      device.queue.submit([encoder.finish()]);
      dispatchObserver?.();
      timings.uploadSubmitMs += performance.now() - beforeUpload;
      const beforeRead = performance.now();
      await read.mapAsync(GPUMapMode.READ);
      timings.readMapWaitMs += performance.now() - beforeRead;
      const beforeReduce = performance.now();
      const partials = new Float32Array(read.getMappedRange(0, readBytes));
      const output = new Float64Array(shape[0] * shape[1]);
      if (reduce) for (let i = 0; i < output.length; i++) output[i] = partials[4 * i] + partials[4 * i + 1] - (partials[4 * i + 2] + partials[4 * i + 3]);
      else if (split) for (let i = 0; i < output.length; i++) {
        let a = 0, z = 0;
        for (let c = 0; c < chunks; c++) {
          const offset = 4 * (i * chunks + c);
          a += partials[offset] + partials[offset + 1];
          z += partials[offset + 2] + partials[offset + 3];
        }
        output[i] = a - z;
      }
      else output.set(partials);
      read.unmap();
      timings.hostReductionMs += performance.now() - beforeReduce;
      if (queryRead) {
        await queryRead.mapAsync(GPUMapMode.READ);
        const times = new BigUint64Array(queryRead.getMappedRange());
        timings.gpuMs += Number(times[1] - times[0]) / 1e6;
        if (reduce) {
          const elapsed = Number(times[3] - times[2]) / 1e6;
          timings.reductionGpuMs += elapsed;
          timings.gpuMs += elapsed;
        }
        queryRead.unmap();
      }
      const error = await device.popErrorScope();
      if (error || lost || signal?.aborted) throw new Error(error?.message || lost || "Cancelled");
      timings.dispatchReadbackMs += performance.now() - beforeRead;
      timings.calls++;
      timings.uploadedBytes += (inputs?.reduce((sum, v) => sum + v.byteLength, 0) ?? 0) + shape.byteLength + (reduce ? 16 : 0);
      timings.readbackBytes += readBytes;
      timings.peakOwnedGpuBufferBytes = Math.max(timings.peakOwnedGpuBufferBytes, capacities.reduce((a, b) => a + b, 0) + readSize + reducedCapacity + (query ? queryBytes * 2 : 0) + (reduce ? 16 : 0));
      return output;
    },
    destroy() {
      signal?.removeEventListener("abort", abort);
      buffers.forEach((buffer) => buffer.destroy());
      read?.destroy();
      reduced?.destroy();
      reductionShape?.destroy();
      query?.destroy();
      queryResolve?.destroy();
      queryRead?.destroy();
      device.destroy();
    }
  };
}

// scripts/efa-reference/compute/binary.ts
function encodeOrdinalSource(source) {
  const cells = source.codes.length, pairs = source.pairs.length, parameters = source.projection[0].length;
  const lookups = source.pairs.reduce((sum, pair) => sum + pair.values.length, 0);
  const size = 24 + cells * 2 + pairs * 16 + lookups * 8 + source.nRows * parameters * 8;
  if (size > 512 * 1024 ** 2) throw new Error("Resident source exceeds the explicit 512 MiB transfer budget");
  const buffer = new ArrayBuffer(size), view = new DataView(buffer);
  [1162232114, source.nRows, cells, pairs, parameters, lookups].forEach((v, i) => view.setUint32(i * 4, v, true));
  let at = 24;
  for (let i = 0; i < cells; i++, at += 2) view.setUint16(at, source.observed[i] ? source.codes[i] : 65535, true);
  let lookup = 0;
  for (const pair of source.pairs) {
    for (const v of [pair.i * source.nRows, pair.j * source.nRows, pair.columns, lookup]) {
      view.setUint32(at, v, true);
      at += 4;
    }
    lookup += pair.values.length;
  }
  for (let i = 0; i < pairs; i++) for (const value of source.pairs[i].values) {
    view.setFloat64(at, value * source.rootWeights[i], true);
    at += 8;
  }
  for (const row of source.projection) for (const value of row) {
    view.setFloat64(at, value, true);
    at += 8;
  }
  return buffer;
}
function decodeBlock(buffer) {
  const view = new DataView(buffer);
  if (view.getUint32(0, true) !== 1162232113) throw new Error("Invalid fixture header");
  const [rows, cols, pairs, parameters, diagonal] = Array.from({ length: 5 }, (_, i) => view.getUint32(4 + i * 4, true));
  if (!rows || !cols || rows > 128 || cols > 128 || !pairs || !parameters || buffer.byteLength !== 24 + 8 * (rows + cols) * (pairs + parameters)) throw new Error("Invalid fixture dimensions");
  let offset = 24;
  const matrix = (n, width) => Array.from({ length: n }, () => {
    const row = new Float64Array(width);
    for (let k = 0; k < width; k++) {
      row[k] = view.getFloat64(offset, true);
      offset += 8;
    }
    return row;
  });
  return { left: matrix(rows, pairs), right: matrix(cols, pairs), leftProjection: matrix(rows, parameters), rightProjection: matrix(cols, parameters), diagonal: !!diagonal };
}
function difference(block, reference, actual, tolerance = 1e-5) {
  if (reference.length !== actual.length) throw new Error("Output shape mismatch");
  let maxAbs = 0, maxScaled = 0, failures = 0;
  for (let a = 0; a < block.left.length; a++) for (let b = 0; b < block.right.length; b++) {
    if (block.diagonal && b > a) continue;
    const i = a * block.right.length + b;
    const error = Math.abs(actual[i] - reference[i]);
    const scaled = error / Math.max(1, Math.abs(reference[i]));
    maxAbs = Math.max(maxAbs, error);
    maxScaled = Math.max(maxScaled, scaled);
    if (!Number.isFinite(actual[i]) || scaled > tolerance) failures++;
  }
  return { maxAbs, maxScaled, failures, tolerance, passed: failures === 0 };
}

// scripts/efa-reference/compute/resident-fixture.mjs
function residentFixture({ rows = 2e4, items = 500, factors = 5, seed = 20261101 } = {}) {
  if (!Number.isSafeInteger(rows) || rows < 512 || !Number.isSafeInteger(items) || items < 8 || !Number.isSafeInteger(factors) || factors < 1 || factors >= items) throw new Error("Invalid resident fixture shape");
  let state = seed >>> 0;
  const random = () => {
    state = state + 1831565813 | 0;
    let t = state;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
  const codes = new Uint16Array(rows * items), observed = new Uint8Array(rows * items);
  for (let i = 0; i < codes.length; i++) {
    codes[i] = Math.floor(random() * 5);
    observed[i] = random() >= 0.025 ? 1 : 0;
  }
  const pairs = [];
  for (let i = 0; i < items; i++) for (let j = i + 1; j < items; j++) pairs.push({
    i,
    j,
    columns: 5,
    values: Float64Array.from({ length: 25 }, () => (random() - 0.5) * 2)
  });
  const rootWeights = Float64Array.from({ length: pairs.length }, () => (0.5 + random()) / Math.sqrt(rows));
  const parameters = items * factors - factors * (factors - 1) / 2;
  const projection = Array.from({ length: rows }, () => Float64Array.from({ length: parameters }, () => (random() - 0.5) / Math.sqrt(rows)));
  const source = { nRows: rows, codes, observed, pairs, rootWeights, projection };
  const ranges = [
    [0, 0, 128, 128],
    [128, 0, 128, 128],
    [128, 128, 128, 128],
    [128, 256, 128, 128],
    [128, 384, 128, 128],
    [256, 0, 128, 128],
    [rows - 31, rows - 128, 31, 128],
    [rows - 31, rows - 31, 31, 31],
    // Revisit full blocks after ragged buffers to expose stale tails or strides.
    [128, 0, 128, 128],
    [0, 128, 128, 128]
  ];
  const materialize = (start, count) => Array.from({ length: count }, (_, offset) => Float64Array.from(pairs, (pair, index) => {
    const x = pair.i * rows + start + offset, y = pair.j * rows + start + offset;
    return observed[x] && observed[y] ? pair.values[codes[x] * pair.columns + codes[y]] * rootWeights[index] : 0;
  }));
  return {
    source,
    manifest: { schema: 1, seed, rows, items, factors, pairs: pairs.length, parameters, categories: 5, missingProbability: 0.025, ranges, scope: "Synthetic ordinal-source kernel inputs with arbitrary influence lookups and projections; not a fitted EFA model or an independent R reference." },
    blocks: ranges.map(([leftStart, rightStart, leftRows, rightRows]) => ({
      get left() {
        return materialize(leftStart, leftRows);
      },
      get right() {
        return materialize(rightStart, rightRows);
      },
      leftProjection: projection.slice(leftStart, leftStart + leftRows),
      rightProjection: projection.slice(rightStart, rightStart + rightRows),
      diagonal: leftStart === rightStart && leftRows === rightRows,
      ordinal: { source, leftStart, rightStart, leftRows, rightRows }
    }))
  };
}

// scripts/efa-reference/compute/optimization.worker.mjs
var hash = async (bytes) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), (value) => value.toString(16).padStart(2, "0")).join("");
var configurations = {
  "gpu-split": { split: true },
  "gpu-compensated-split": { split: true, compensatedSplit: true },
  "gpu-compensated-reduced": { split: true, compensatedSplit: true, reduce: true }
};
var flatErrors = (expected, actual, tolerance) => {
  if (expected.length !== actual.length) throw new Error("Output dimensions differ");
  let maxAbs = 0, maxScaled = 0, failures = 0;
  for (let i = 0; i < expected.length; i++) {
    const error = Math.abs(expected[i] - actual[i]), scaled = error / Math.max(1, Math.abs(expected[i]));
    maxAbs = Math.max(maxAbs, error);
    maxScaled = Math.max(maxScaled, scaled);
    if (!Number.isFinite(actual[i]) || !Number.isFinite(expected[i]) || scaled > tolerance) failures++;
  }
  return { maxAbs, maxScaled, failures, tolerance, passed: failures === 0 };
};
self.onmessage = async ({ data: options }) => {
  const results = [], metadata = [], mode = options.experimentMode ?? "kernels";
  let kernel;
  try {
    let resident, reference, sourceSha256;
    if (mode === "resident") {
      self.postMessage({ stage: "Preparing synthetic resident inputs" });
      resident = residentFixture();
      reference = await (await fetch("./optimization-reference.json")).json();
      let encoded = encodeOrdinalSource(resident.source);
      sourceSha256 = await hash(encoded);
      encoded = void 0;
      if (sourceSha256 !== reference.inputSha256) throw new Error("Resident input hash does not match the native Float64 reference");
    } else if (mode !== "kernels") throw new Error("Unknown optimization experiment");
    const manifest = mode === "kernels" ? await (await fetch("./fixtures/manifest.json")).json() : void 0;
    for (const backend of options.backends ?? Object.keys(configurations)) {
      if (!configurations[backend]) throw new Error(`Unknown experimental variant ${backend}`);
      try {
        kernel = await createGpuKernel({ ...configurations[backend], resident: mode === "resident", strictMath: options.strictMath ? true : void 0 });
        metadata.push({ ...kernel.metadata, variant: backend });
        const fixtures = mode === "kernels" ? manifest.fixtures : reference.results.map((value, index) => ({ name: `resident-range-${index}`, index, range: value.range }));
        for (const fixture of fixtures) {
          self.postMessage({ stage: `${backend}: ${fixture.name}` });
          let block, expected, inputSha256;
          if (mode === "kernels") {
            const raw = await (await fetch(`./fixtures/${fixture.name}.bin`)).arrayBuffer();
            const expectedBytes = await (await fetch(`./fixtures/${fixture.name}.reference.bin`)).arrayBuffer();
            inputSha256 = await hash(raw);
            if (inputSha256 !== fixture.inputSha256 || await hash(expectedBytes) !== fixture.referenceSha256) throw new Error("Kernel fixture hash mismatch");
            block = decodeBlock(raw);
            expected = new Float64Array(expectedBytes);
          } else {
            block = resident.blocks[fixture.index];
            expected = reference.results[fixture.index].output;
            inputSha256 = sourceSha256;
          }
          const before = { ...kernel.timings }, iterationMs = [];
          let output;
          for (let repeat = 0; repeat < 5; repeat++) {
            const started = performance.now();
            output = await kernel.run(block);
            iterationMs.push(performance.now() - started);
          }
          const compare = (tolerance) => mode === "kernels" ? difference(block, expected, output, tolerance) : flatErrors(expected, output, tolerance);
          const errors = compare(1e-10), baselineToleranceErrors = compare(1e-5);
          results.push({
            fixture: fixture.name,
            range: fixture.range,
            backend,
            precision: kernel.metadata.precision,
            inputSha256,
            iterationMs,
            errors,
            baselineToleranceErrors,
            passed: errors.passed,
            measurements: Object.fromEntries(Object.entries(kernel.timings).filter(([key]) => !["startupMs", "peakOwnedGpuBufferBytes"].includes(key)).map(([key, value]) => [key, value === null ? null : value - before[key]])),
            ownedGpuBufferBytes: kernel.timings.peakOwnedGpuBufferBytes,
            outputSha256: await hash(output.buffer),
            output: Array.from(output)
          });
        }
      } catch (error) {
        results.push({ backend, fixture: "experiment-failure", passed: false, error: String(error) });
      } finally {
        kernel?.destroy();
        kernel = void 0;
      }
    }
    self.postMessage({ result: { status: results.every((value) => value.passed) ? "passed" : "numerical-failures", mode, strictMathRequested: !!options.strictMath, developerOnly: !!options.strictMath, scope: "Targeted precision/readback experiments. Neither a completed full fit nor default-browser qualification when developer flags are required.", sourceSha256, metadata, results } });
  } catch (error) {
    kernel?.destroy();
    self.postMessage({ result: { status: "failed", error: String(error), mode, results, metadata } });
  }
};
