// src/lib/efa/math.ts
function gaussLegendre(n) {
  const x = [], w = [];
  for (let i = 0; i < n; i++) {
    let z = Math.cos(Math.PI * (i + 0.75) / (n + 0.5)), derivative = 0;
    for (let it = 0; it < 30; it++) {
      let p = 1, prev = 0;
      for (let j = 1; j <= n; j++) {
        const next = ((2 * j - 1) * z * p - (j - 1) * prev) / j;
        prev = p;
        p = next;
      }
      derivative = n * (z * p - prev) / (z * z - 1);
      const step = p / derivative;
      z -= step;
      if (Math.abs(step) < 1e-15) break;
    }
    x.push(z);
    w.push(2 / ((1 - z * z) * derivative * derivative));
  }
  return { x, w };
}
var quadrature = gaussLegendre(24);

// src/lib/efa/types.ts
var EfaError = class extends Error {
  constructor(code, message, diagnostics = []) {
    super(message);
    this.code = code;
    this.diagnostics = diagnostics;
    this.name = "EfaError";
  }
};

// src/lib/efa/correlation.ts
function assembleCorrelations(data, pairs) {
  const p = data.items.length, matrix = Array.from(
    { length: p },
    (_, i) => Array.from({ length: p }, (_2, j) => i === j ? 1 : NaN)
  );
  if (pairs.length !== p * (p - 1) / 2)
    throw new EfaError("pairs", "Correlation job is incomplete.");
  for (const pair of pairs)
    matrix[pair.i][pair.j] = matrix[pair.j][pair.i] = pair.rho;
  const sparse = pairs.filter((x) => x.sparseCells), boundary = pairs.filter((x) => x.boundary);
  const emptyMargins = pairs.filter(
    (x) => x.observedCategoriesX.length < data.items[x.i].categories.length || x.observedCategoriesY.length < data.items[x.j].categories.length
  );
  return {
    matrix,
    pairs,
    counts: data.counts.map((f) => f.reduce((a, b) => a + b, 0)),
    diagnostics: [
      ...sparse.length ? [
        {
          code: "sparse",
          message: `${sparse.length} item pairs contain cells with fewer than five responses. Inspect pair diagnostics.`,
          count: sparse.length
        }
      ] : [],
      ...boundary.length ? [
        {
          code: "boundary-correlation",
          message: `${boundary.length} estimated correlations are near \xB11.`,
          count: boundary.length
        }
      ] : [],
      ...emptyMargins.length ? [
        {
          code: "empty-pair-margins",
          message: `${emptyMargins.length} pairs have unobserved category margins. Their likelihoods use the observed levels, matching polycor; the original category order and observed level indices are retained.`,
          count: emptyMargins.length
        }
      ] : []
    ]
  };
}

// src/lib/random.ts
var mulberry32 = (seed) => () => {
  seed |= 0;
  seed = seed + 1831565813 | 0;
  let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
  t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
  return ((t ^ t >>> 14) >>> 0) / 4294967296;
};

// src/lib/efa/parallel.ts
function validateReplicates(replicates) {
  if (!Number.isInteger(replicates) || replicates < 1 || replicates > 1e3)
    throw new EfaError(
      "replicates",
      "Use 1\u20131000 parallel-analysis permutations."
    );
}
function summarizeParallel(observed, nullEigenvalues, failures, seed, replicates) {
  if (nullEigenvalues.length + failures.length !== replicates)
    throw new EfaError(
      "incomplete-simulation",
      "A simulation result must account for every requested replicate."
    );
  const reference = observed.map((_, j) => {
    const sorted = nullEigenvalues.map((row) => row[j]).sort((a, b) => a - b);
    if (!sorted.length) return null;
    const index = 0.95 * (sorted.length - 1), lo = Math.floor(index);
    return sorted[lo] + (sorted[Math.ceil(index)] - sorted[lo]) * (index - lo);
  });
  let suggestion = 0;
  while (suggestion < observed.length && reference[suggestion] !== null && observed[suggestion] > reference[suggestion])
    suggestion++;
  return {
    seed,
    requested: replicates,
    completed: nullEigenvalues.length,
    percentile: 0.95,
    observed,
    nullEigenvalues,
    reference,
    failures,
    suggested: failures.length ? null : suggestion
  };
}

// src/lib/efa/mice.ts
function validateMiceOptions(options, p) {
  if (!Number.isInteger(options.imputations) || options.imputations < 2 || options.imputations > 100 || !Number.isInteger(options.iterations) || options.iterations < 1 || options.iterations > 100 || !Number.isSafeInteger(options.seed))
    throw new EfaError(
      "mice-settings",
      "Use 2\u2013100 imputations, 1\u2013100 iterations and an integer seed."
    );
  if (!Array.isArray(options.predictors) || options.predictors.length !== p || options.predictors.some(
    (row, j) => !Array.isArray(row) || new Set(row).size !== row.length || row.some((i) => !Number.isInteger(i) || i < 0 || i >= p || i === j)
  ))
    throw new EfaError(
      "predictors",
      "Specify unique valid predictors for each item, excluding the target itself."
    );
  if (!["ordered-polynomial", "rank"].includes(
    options.predictorEncoding ?? "ordered-polynomial"
  ))
    throw new EfaError(
      "predictor-encoding",
      "Choose ordered-polynomial contrasts or ordinal ranks explicitly."
    );
}

// src/lib/efa/compare.ts
function matchFactors(reference, candidate) {
  const ka = reference[0]?.length ?? 0, kb = candidate[0]?.length ?? 0, n = Math.max(ka, kb);
  const congruence = Array.from(
    { length: ka },
    (_, a) => Array.from({ length: kb }, (_2, b) => {
      let xy = 0, xx = 0, yy = 0;
      for (let i = 0; i < reference.length; i++) {
        const x = reference[i][a], y = candidate[i][b];
        xy += x * y;
        xx += x * x;
        yy += y * y;
      }
      return xx * yy > 0 ? xy / Math.sqrt(xx * yy) : 0;
    })
  );
  const u = Array(n + 1).fill(0), v = Array(n + 1).fill(0), p = Array(n + 1).fill(0), way = Array(n + 1).fill(0);
  for (let i = 1; i <= n; i++) {
    p[0] = i;
    let j0 = 0;
    const min = Array(n + 1).fill(Infinity), used = Array(n + 1).fill(false);
    do {
      used[j0] = true;
      const i0 = p[j0];
      let delta = Infinity, j1 = 0;
      for (let j = 1; j <= n; j++)
        if (!used[j]) {
          const cost = 1 - Math.abs(congruence[i0 - 1]?.[j - 1] ?? 0) - u[i0] - v[j];
          if (cost < min[j]) {
            min[j] = cost;
            way[j] = j0;
          }
          if (min[j] < delta) {
            delta = min[j];
            j1 = j;
          }
        }
      for (let j = 0; j <= n; j++)
        if (used[j]) {
          u[p[j]] += delta;
          v[j] -= delta;
        } else min[j] -= delta;
      j0 = j1;
    } while (p[j0] !== 0);
    do {
      const j1 = way[j0];
      p[j0] = p[j1];
      j0 = j1;
    } while (j0 !== 0);
  }
  const mapping = Array(ka).fill(null);
  for (let j = 1; j <= n; j++)
    if (p[j] <= ka && j <= kb) mapping[p[j] - 1] = j - 1;
  const signs = mapping.map(
    (b, a) => b === null ? 1 : congruence[a][b] < 0 ? -1 : 1
  );
  return {
    mapping,
    signs,
    congruence: mapping.map(
      (b, a) => b === null ? null : Math.abs(congruence[a][b])
    ),
    unmatchedCandidate: Array.from({ length: kb }, (_, i) => i).filter(
      (i) => !mapping.includes(i)
    )
  };
}

// src/lib/efa/stability.ts
function alignReplica(reference, result, replicate) {
  const { mapping, signs, congruence } = matchFactors(
    reference.rotation.pattern,
    result.rotation.pattern
  );
  if (mapping.some((i) => i === null))
    throw new EfaError(
      "factor-matching",
      "A resampled fit has unmatched factors."
    );
  const aligned = (matrix) => matrix.map((row) => mapping.map((j, k) => row[j] * signs[k]));
  return {
    replicate,
    pattern: aligned(result.rotation.pattern),
    structure: aligned(result.structure),
    phi: mapping.map(
      (i, a) => mapping.map((j, b) => result.rotation.phi[i][j] * signs[a] * signs[b])
    ),
    communalities: result.communalities,
    uniquenesses: result.uniquenesses,
    congruence,
    rmsr: result.rmsr
  };
}
function percentile(values, p) {
  if (!values.length) return null;
  const sorted = values.slice().sort((a, b) => a - b), q = p * (sorted.length - 1), lo = Math.floor(q);
  return sorted[lo] + (sorted[Math.ceil(q)] - sorted[lo]) * (q - lo);
}
function distribution(values, confidence = 0.95) {
  if (!values.length) return { mean: null, sd: null, lower: null, upper: null };
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return {
    mean,
    sd: values.length > 1 ? Math.sqrt(
      values.reduce((s, v) => s + (v - mean) ** 2, 0) / (values.length - 1)
    ) : null,
    lower: percentile(values, (1 - confidence) / 2),
    upper: percentile(values, (1 + confidence) / 2)
  };
}
var primary = (row) => row.reduce((best, v, i) => Math.abs(v) > Math.abs(row[best]) ? i : best, 0);
function summarizeStability(reference, replicas, failures, samples, options) {
  const p = reference.rotation.pattern.length, k = reference.rotation.phi.length;
  const matrix = (field, rows, cols) => Array.from(
    { length: rows },
    (_, i) => Array.from(
      { length: cols },
      (_2, j) => distribution(
        replicas.map((r) => r[field][i][j]),
        options.confidence
      )
    )
  );
  return {
    options: structuredClone(options),
    requested: options.replicates,
    completed: replicas.length,
    replicas,
    failures,
    samples,
    pattern: matrix("pattern", p, k),
    structure: matrix("structure", p, k),
    phi: matrix("phi", k, k),
    communalities: Array.from(
      { length: p },
      (_, i) => distribution(
        replicas.map((r) => r.communalities[i]),
        options.confidence
      )
    ),
    uniquenesses: Array.from(
      { length: p },
      (_, i) => distribution(
        replicas.map((r) => r.uniquenesses[i]),
        options.confidence
      )
    ),
    primaryAgreement: Array.from(
      { length: p },
      (_, i) => replicas.length ? replicas.filter(
        (r) => primary(r.pattern[i]) === primary(reference.rotation.pattern[i])
      ).length / replicas.length : null
    ),
    crossLoadingFrequency: Array.from(
      { length: p },
      (_, i) => replicas.length ? replicas.filter(
        (r) => r.pattern[i].filter(
          (v) => Math.abs(v) >= options.crossLoadingThreshold
        ).length > 1
      ).length / replicas.length : null
    ),
    provisional: failures.length > 0 || replicas.length !== options.replicates
  };
}
function validateStability(options) {
  if (!Number.isInteger(options.replicates) || options.replicates < 2 || options.replicates > 1e3 || !Number.isSafeInteger(options.seed) || !(options.confidence > 0 && options.confidence < 1) || !(options.crossLoadingThreshold >= 0))
    throw new EfaError(
      "stability-settings",
      "Use 2\u20131000 replicates, an integer seed, a confidence level between 0 and 1, and a nonnegative loading threshold."
    );
}

// src/lib/efa/imputation-analysis.ts
function imputationWorkingSet(source, options) {
  let maximum = 0;
  for (let target = 0; target < source.items.length; target++) {
    if (source.counts[target].reduce((a, b) => a + b, 0) === source.nRows) continue;
    const d = options.predictors[target].reduce((sum, j) => sum + (options.predictorEncoding === "rank" ? 1 : source.items[j].categories.length - 1), 0), k = source.items[target].categories.length;
    maximum = Math.max(maximum, 8 * d * (3 * source.nRows + 4 * d * k));
  }
  return maximum + 2 * (source.codes.byteLength + source.observed.byteLength) + 128 * source.items.length ** 2;
}
function betweenImputation(values) {
  if (!values.length) return { mean: null, sd: null, min: null, max: null };
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return {
    mean,
    sd: values.length > 1 ? Math.sqrt(
      values.reduce((s, v) => s + (v - mean) ** 2, 0) / (values.length - 1)
    ) : null,
    min: Math.min(...values),
    max: Math.max(...values)
  };
}
function missingPositions(source) {
  const positions = [];
  for (let i = 0; i < source.observed.length; i++)
    if (!source.observed[i]) positions.push(i);
  return positions;
}
function summarizeImputations(source, options, chains) {
  const fits = chains.flatMap((c) => c.fit ? [c.fit] : []).sort((a, b) => a.imputation - b.imputation), failures = chains.flatMap((c) => c.failure ? [c.failure] : []).sort((a, b) => a.imputation - b.imputation);
  const ids = [
    ...fits.map((f) => f.imputation),
    ...failures.map((f) => f.imputation)
  ];
  if (ids.length !== options.imputations || new Set(ids).size !== ids.length || ids.some((i) => i < 0 || i >= options.imputations))
    throw new EfaError(
      "incomplete-imputation",
      "Every requested imputation must have one fit or recorded failure."
    );
  const reference = fits[0]?.result, aligned = fits.map((f) => alignReplica(reference, f.result, f.imputation));
  const p = source.items.length, k = reference?.rotation.phi.length ?? 0;
  const matrix = (field, rows, cols) => Array.from(
    { length: rows },
    (_, i) => Array.from(
      { length: cols },
      (_2, j) => betweenImputation(aligned.map((r) => r[field][i][j]))
    )
  );
  return {
    options: structuredClone({
      ...options,
      predictorEncoding: options.predictorEncoding ?? "ordered-polynomial"
    }),
    requested: options.imputations,
    completed: fits.length,
    fittingRows: source.rows.slice(),
    originalRowCount: source.originalRowCount,
    missingPositions: missingPositions(source),
    fits,
    aligned,
    failures,
    trace: chains.flatMap((c) => c.trace).sort(
      (a, b) => a.imputation - b.imputation || a.iteration - b.iteration || a.item - b.item
    ),
    pattern: matrix("pattern", p, k),
    structure: matrix("structure", p, k),
    phi: matrix("phi", k, k),
    communalities: Array.from(
      { length: p },
      (_, i) => betweenImputation(aligned.map((r) => r.communalities[i]))
    ),
    uniquenesses: Array.from(
      { length: p },
      (_, i) => betweenImputation(aligned.map((r) => r.uniquenesses[i]))
    ),
    provisional: failures.length > 0,
    provenance: {
      method: "Separate ordinal polr / binary logreg conditional imputations; MINRES fitted independently to each completed dataset",
      inputSha256: source.fingerprint,
      alignment: "Signs and factor permutation only, anchored to first successful imputation",
      uncertainty: "Descriptive between-imputation dispersion only; no within-imputation variance or Rubin-pooled confidence intervals"
    }
  };
}

// src/lib/efa/service.ts
var WorkerClient = class {
  constructor(factory) {
    this.counter = 0;
    this.pending = /* @__PURE__ */ new Map();
    this.worker = factory();
    this.worker.onmessage = (event) => {
      const { id, progress, error, value } = event.data;
      const p = this.pending.get(id);
      if (!p) return;
      if (progress) {
        p.progress(progress);
        return;
      }
      this.pending.delete(id);
      if (error)
        p.reject(new EfaError(error.code, error.message, error.diagnostics));
      else p.resolve(value);
    };
    this.worker.onerror = (event) => {
      for (const p of this.pending.values())
        p.reject(new Error(event.message || "Worker failed."));
      this.pending.clear();
    };
  }
  request(request, progress = () => {
  }) {
    return new Promise((resolve, reject) => {
      const id = ++this.counter;
      this.pending.set(id, {
        resolve: (v) => resolve(v),
        reject,
        progress
      });
      this.worker.postMessage({ ...request, id });
    });
  }
  terminate() {
    this.worker.terminate();
    for (const p of this.pending.values())
      p.reject(new EfaError("cancelled", "Analysis cancelled."));
    this.pending.clear();
  }
};
var EfaService = class {
  constructor(workerFactory = () => new Worker(new URL("./efa.worker.ts", import.meta.url)), concurrency = Math.max(
    1,
    Math.min(
      4,
      typeof navigator === "undefined" ? 1 : navigator.hardwareConcurrency || 1
    )
  )) {
    this.workerFactory = workerFactory;
    this.concurrency = concurrency;
    this.jobs = /* @__PURE__ */ new Map();
    this.listeners = /* @__PURE__ */ new Set();
    this.cache = /* @__PURE__ */ new WeakMap();
    this.revisionIds = /* @__PURE__ */ new WeakMap();
    this.subscribe = (listener) => {
      this.listeners.add(listener);
      return () => {
        this.listeners.delete(listener);
      };
    };
    this.concurrency = Math.max(
      1,
      Math.min(
        4,
        typeof navigator === "undefined" ? 4 : navigator.hardwareConcurrency || 1,
        Math.floor(concurrency) || 1
      )
    );
  }
  emit() {
    this.listeners.forEach((fn) => fn());
  }
  getJob(id) {
    return this.jobs.get(id);
  }
  listJobs() {
    return [...this.jobs.values()];
  }
  revision(table) {
    let id = this.revisionIds.get(table);
    if (!id) {
      id = crypto.randomUUID();
      this.revisionIds.set(table, id);
    }
    return id;
  }
  cancelAll() {
    for (const job of this.jobs.values())
      if (job.status === "running") job.cancel();
  }
  launch(task) {
    this.cancelAll();
    const workers = [], id = crypto.randomUUID();
    const job = {
      id,
      status: "running",
      progress: { stage: "Preparing", completed: 0, total: 1 },
      promise: Promise.resolve(void 0),
      cancel: () => {
        if (job.status !== "running") return;
        job.status = "cancelled";
        workers.forEach((w) => w.terminate());
        this.emit();
      }
    };
    this.jobs.set(id, job);
    this.emit();
    const progress = (p) => {
      if (job.status === "running") {
        job.progress = p;
        this.emit();
      }
    };
    job.promise = task(workers, progress, () => job.status === "running").then((result) => {
      if (job.status !== "running")
        throw new EfaError("cancelled", "Analysis cancelled.");
      job.result = result;
      job.status = "completed";
      job.progress = { stage: "Completed", completed: 1, total: 1 };
      return result;
    }).catch((error) => {
      if (job.status !== "cancelled") {
        job.status = "failed";
        job.error = error instanceof Error ? error.message : String(error);
      }
      throw error;
    }).finally(() => {
      workers.forEach((w) => w.terminate());
      this.emit();
    });
    void job.promise.catch(() => {
    });
    for (const [key, value] of this.jobs)
      if (this.jobs.size > 20 && value.status !== "running" && key !== id)
        this.jobs.delete(key);
    return job;
  }
  client(workers) {
    const client = new WorkerClient(this.workerFactory);
    workers.push(client);
    return client;
  }
  async batches(workers, first, data, count, request, label, progress, live, workerLimit = this.concurrency) {
    const clients = [first], results = Array(count);
    for (let i = 1; i < Math.min(workerLimit, count); i++) {
      if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
      const client = this.client(workers);
      await client.request({ op: "initialize", data });
      clients.push(client);
    }
    let next = 0, completed = 0;
    await Promise.all(
      clients.map(async (client) => {
        while (next < count && live()) {
          const index = next++;
          let reported = 0;
          results[index] = await client.request(request(index), (p) => {
            const now = performance.now();
            if (now - reported > 250 || p.completed === p.total) {
              reported = now;
              progress({
                stage: `${label} ${index + 1}: ${p.stage} (${p.completed}/${p.total})`,
                completed,
                total: count
              });
            }
          });
          progress({ stage: label, completed: ++completed, total: count });
        }
      })
    );
    if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
    return results;
  }
  impute(table, spec, rows, options) {
    const snapshot = structuredClone(spec), membership = rows.slice(), settings = structuredClone(options);
    validateMiceOptions(settings, snapshot.items.length);
    if (snapshot.missing !== "pairwise")
      throw new EfaError(
        "mice-population",
        "MICE keeps incomplete respondents. Choose the pairwise/eligible population before starting imputation; complete-case deletion would remove its targets."
      );
    return this.launch(async (workers, progress, live) => {
      const first = this.client(workers), data = await first.request({
        op: "prepare",
        table: {
          columns: snapshot.items.map((x) => x.column),
          data: Object.fromEntries(
            snapshot.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec: snapshot,
        rows: membership
      });
      const estimatedBytes = imputationWorkingSet(data, settings), workerLimit = Math.min(this.concurrency, settings.imputations, Math.max(1, Math.floor(1024 ** 3 / Math.max(1, estimatedBytes))));
      const results = await this.batches(
        workers,
        first,
        data,
        settings.imputations,
        (index) => ({
          op: "imputation",
          spec: snapshot,
          options: settings,
          index
        }),
        "MICE imputation",
        progress,
        live,
        workerLimit
      );
      const analysis = summarizeImputations(data, settings, results);
      analysis.provenance.execution = { workers: workerLimit, estimatedWorkingSetBytesPerWorker: estimatedBytes, note: "Concurrency reduced for expanded predictor designs using an approximate 1 GiB combined working-set budget, with at least one worker. This is a scheduling estimate, not measured peak memory or a cap on a single model." };
      return analysis;
    });
  }
  stability(table, run, options) {
    const spec = structuredClone(run.spec), membership = run.result.fittingRows.slice(), reference = structuredClone({ rotation: run.result.rotation }), settings = structuredClone(options), fingerprint = run.result.provenance.inputSha256;
    validateStability(settings);
    return this.launch(async (workers, progress, live) => {
      const first = this.client(workers), data = await first.request({
        op: "prepare",
        table: {
          columns: spec.items.map((x) => x.column),
          data: Object.fromEntries(
            spec.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec,
        rows: membership
      });
      if (!fingerprint || fingerprint !== data.fingerprint)
        throw new EfaError(
          "changed-data",
          "The fitted responses changed. Refit before evaluating resampling stability."
        );
      const results = await this.batches(
        workers,
        first,
        data,
        settings.replicates,
        (index) => ({
          op: "stability",
          spec,
          reference,
          options: settings,
          index
        }),
        "Stability replicate",
        progress,
        live
      );
      return summarizeStability(
        reference,
        results.flatMap((r) => r.replica ? [r.replica] : []),
        results.flatMap((r) => r.failure ? [r.failure] : []),
        results.map((r) => r.indices),
        settings
      );
    });
  }
  preview(table, spec, rows) {
    const snapshot = structuredClone(spec), membership = rows.slice();
    return this.launch(async (workers) => {
      const worker = this.client(workers);
      const data = await worker.request({
        op: "prepare",
        table: {
          columns: snapshot.items.map((x) => x.column),
          data: Object.fromEntries(
            snapshot.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec: snapshot,
        rows: membership
      });
      return { nRows: data.nRows, counts: data.counts };
    });
  }
  fit(table, spec, rows, reuse, minimumPairN = 0) {
    const snapshot = structuredClone(spec), membership = rows.slice();
    const key = JSON.stringify({
      items: snapshot.items,
      missing: snapshot.missing,
      rows: membership
    });
    const selected = {
      columns: snapshot.items.map((x) => x.column),
      data: Object.fromEntries(
        snapshot.items.map((x) => [x.column, table.data[x.column]])
      ),
      nRows: table.nRows
    };
    return this.launch(async (workers, progress, live) => {
      const first = this.client(workers), entries = this.cache.get(table) ?? [], cached = entries.find((e) => e.key === key);
      const data = cached ? cached.data : await first.request({
        op: "prepare",
        table: selected,
        spec: snapshot,
        rows: membership
      });
      if (cached) await first.request({ op: "initialize", data });
      let correlation = cached?.correlation;
      if (!correlation) {
        const subset = entries.find(
          (entry) => JSON.stringify(entry.data.rows) === JSON.stringify(data.rows) && data.items.every(
            (item) => entry.data.items.some(
              (previous) => JSON.stringify(previous) === JSON.stringify(item)
            )
          )
        );
        if (subset) {
          const oldIndices = data.items.map(
            (item) => subset.data.items.findIndex(
              (previous) => JSON.stringify(previous) === JSON.stringify(item)
            )
          ), newIndices = new Map(oldIndices.map((v, i) => [v, i]));
          const pairs = [];
          for (const pair of subset.correlation.pairs) {
            const a = newIndices.get(pair.i), b = newIndices.get(pair.j);
            if (a === void 0 || b === void 0) continue;
            pairs.push(
              a < b ? { ...pair, i: a, j: b } : {
                ...pair,
                i: b,
                j: a,
                thresholdsX: pair.thresholdsY,
                thresholdsY: pair.thresholdsX,
                observedCategoriesX: pair.observedCategoriesY,
                observedCategoriesY: pair.observedCategoriesX
              }
            );
          }
          correlation = assembleCorrelations(
            data,
            pairs.sort((a, b) => a.i - b.i || a.j - b.j)
          );
          progress({
            stage: "Reused unchanged item pairs",
            completed: pairs.length,
            total: pairs.length
          });
        }
      }
      if (!correlation) {
        const pairs = [];
        for (let i = 0; i < data.items.length - 1; i++)
          for (let j = i + 1; j < data.items.length; j++) pairs.push([i, j]);
        const clients = [first];
        for (let n = 1; n < Math.min(this.concurrency, Math.ceil(pairs.length / 64)); n++) {
          const worker = this.client(workers);
          await worker.request({ op: "initialize", data });
          clients.push(worker);
        }
        let next = 0, done = 0;
        const estimates = [];
        await Promise.all(
          clients.map(async (client) => {
            while (next < pairs.length && live()) {
              const batch = pairs.slice(next, next + 64);
              next += batch.length;
              const result = await client.request({
                op: "pairs",
                pairs: batch
              });
              estimates.push(...result);
              done += result.length;
              progress({
                stage: "Correlations",
                completed: done,
                total: pairs.length
              });
            }
          })
        );
        if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
        estimates.sort((a, b) => a.i - b.i || a.j - b.j);
        correlation = assembleCorrelations(data, estimates);
        this.cache.set(
          table,
          [
            { key, data, correlation },
            ...entries.filter((e) => e.key !== key)
          ].slice(0, 2)
        );
      }
      if (!cached)
        this.cache.set(
          table,
          [
            { key, data, correlation },
            ...entries.filter((e) => e.key !== key)
          ].slice(0, 2)
        );
      let extraction;
      if (data.rows.length < minimumPairN || correlation.pairs.some((pair) => pair.n < minimumPairN))
        throw new EfaError(
          "privacy",
          "This fit includes item pairs below the private aggregate floor. Widen the sample or revise the selected items."
        );
      if (reuse && data.fingerprint && reuse.result.provenance.inputSha256 === data.fingerprint && reuse.spec.nFactors === snapshot.nFactors && JSON.stringify({
        items: reuse.spec.items,
        missing: reuse.spec.missing,
        rows: reuse.eligibleRows
      }) === key)
        extraction = reuse.result.extraction;
      if (reuse && !extraction)
        throw new EfaError(
          "rotation",
          "The fitted inputs changed. Create a refit before comparing rotations."
        );
      return first.request(
        { op: "fit", correlation, spec: snapshot, extraction },
        progress
      );
    });
  }
  scores(table, run) {
    const spec = structuredClone(run.spec), rows = run.result.fittingRows.slice(), result = run.result;
    return this.launch(async (workers) => {
      const worker = this.client(workers);
      await worker.request({
        op: "prepare",
        table: {
          columns: spec.items.map((x) => x.column),
          data: Object.fromEntries(
            spec.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec,
        rows
      });
      return worker.request({ op: "score", result });
    });
  }
  parallel(table, spec, rows, replicates = 100, minimumPairN = 0) {
    validateReplicates(replicates);
    const snapshot = structuredClone(spec), membership = rows.slice();
    return this.launch(async (workers, progress, live) => {
      const worker = this.client(workers);
      const data = await worker.request({
        op: "prepare",
        table: {
          columns: snapshot.items.map((x) => x.column),
          data: Object.fromEntries(
            snapshot.items.map((x) => [x.column, table.data[x.column]])
          ),
          nRows: table.nRows
        },
        spec: snapshot,
        rows: membership
      });
      const observed = await worker.request(
        { op: "parallel-observed", minimumPairN },
        progress
      );
      const clients = [worker];
      for (let i = 1; i < Math.min(this.concurrency, replicates); i++) {
        const next2 = this.client(workers);
        await next2.request({ op: "initialize", data });
        clients.push(next2);
      }
      let next = 0, completed = 0;
      const results = Array(replicates);
      const failures = [];
      progress({ stage: "Parallel analysis", completed: 0, total: replicates });
      await Promise.all(
        clients.map(async (client) => {
          while (next < replicates && live()) {
            const index = next++;
            let reported = 0;
            try {
              results[index] = await client.request(
                { op: "parallel-replicate", seed: snapshot.seed + index },
                (p) => {
                  const now = performance.now();
                  if (now - reported > 250 || p.completed === p.total) {
                    reported = now;
                    progress({
                      stage: `Parallel analysis \xB7 replicate ${index + 1}: ${p.stage} (${p.completed}/${p.total}) \xB7 ${failures.length} failed`,
                      completed,
                      total: replicates
                    });
                  }
                }
              );
            } catch (error) {
              if (!live()) throw error;
              failures.push({
                replicate: index,
                error: error instanceof Error ? error.message : String(error)
              });
            }
            progress({
              stage: `Parallel analysis \xB7 ${failures.length} failed`,
              completed: ++completed,
              total: replicates
            });
          }
        })
      );
      if (!live()) throw new EfaError("cancelled", "Analysis cancelled.");
      return summarizeParallel(
        observed,
        results.filter((x) => !!x),
        failures.sort((a, b) => a.replicate - b.replicate),
        snapshot.seed,
        replicates
      );
    });
  }
};

// scripts/efa-reference/benchmark-data.ts
function benchmarkData(n = 2e4, p = 500) {
  const random = mulberry32(8801), normal = () => Math.sqrt(-2 * Math.log(Math.max(1e-12, random()))) * Math.cos(2 * Math.PI * random());
  const columns = Array.from({ length: p }, (_, i) => `Q${i + 1}`), data = Object.fromEntries(
    columns.map((c) => [c, Array(n)])
  );
  for (let i = 0; i < n; i++) {
    const common = normal(), f = Array.from({ length: 5 }, () => 0.45 * common + 0.89 * normal());
    for (let j = 0; j < p; j++) {
      const z = 0.65 * f[j % 5] + 0.76 * normal();
      data[columns[j]][i] = z < -1 ? 1 : z < -0.3 ? 2 : z < 0.3 ? 3 : z < 1 ? 4 : 5;
    }
  }
  const spec = {
    items: columns.map((column) => ({
      column,
      categories: [1, 2, 3, 4, 5],
      reverse: false
    })),
    nFactors: 5,
    rotation: "oblimin",
    missing: "pairwise",
    seed: 8801,
    label: "qualification",
    sample: { partition: "all" }
  };
  return { table: { columns, data, nRows: n }, spec };
}

// scripts/efa-reference/parallel-benchmark.ts
var workerFailures = [];
var service = new EfaService(() => {
  const worker = new Worker("/efa-qualification/worker.js"), seeds = /* @__PURE__ */ new Map(), post = worker.postMessage.bind(worker);
  worker.postMessage = (message) => {
    if (message.op === "parallel-replicate")
      seeds.set(message.id, message.seed);
    post(message);
  };
  worker.addEventListener("message", (event) => {
    if (event.data.error)
      workerFailures.push({
        seed: seeds.get(event.data.id),
        code: event.data.error.code,
        message: event.data.error.message
      });
  });
  return worker;
});
var heartbeat = 0;
setInterval(
  () => document.querySelector("#heartbeat").textContent = String(++heartbeat),
  100
);
service.subscribe(() => {
  const job = service.listJobs().at(-1);
  if (job)
    document.querySelector("#stage").textContent = JSON.stringify({
      id: job.id,
      status: job.status,
      ...job.progress,
      workerFailures
    });
});
document.querySelector("#cancel").onclick = () => {
  const start = performance.now();
  service.cancelAll();
  document.querySelector("#cancelTime").textContent = String(
    performance.now() - start
  );
};
document.querySelector("#run").onclick = async () => {
  document.querySelector("#output").textContent = "running";
  workerFailures.length = 0;
  const params = new URLSearchParams(location.search), p = Number(params.get("items") ?? 500), n = Number(params.get("rows") ?? 2e4), replicates = Number(params.get("replicates") ?? 100);
  const { table, spec } = benchmarkData(n, p), start = performance.now();
  try {
    const result = await service.parallel(
      table,
      spec,
      Array.from({ length: n }, (_, i) => i),
      replicates
    ).promise;
    document.querySelector("#output").textContent = JSON.stringify({
      status: result.failures.length ? "completed-with-failures" : "passed",
      dimensions: { items: p, respondents: n },
      elapsedMs: performance.now() - start,
      heartbeat,
      browser: navigator.userAgent,
      hardwareConcurrency: navigator.hardwareConcurrency,
      recordedAt: (/* @__PURE__ */ new Date()).toISOString(),
      result,
      workerFailures
    });
  } catch (error) {
    document.querySelector("#output").textContent = JSON.stringify({
      status: "failed",
      elapsedMs: performance.now() - start,
      error: String(error)
    });
  }
};
